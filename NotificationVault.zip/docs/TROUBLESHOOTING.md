# Troubleshooting

## The build fails on GitHub
| Symptom | Fix |
|---|---|
| "No settings.gradle.kts and no .zip found" | Upload `NotificationVault.zip` to the **root** of the repo (not inside a folder). |
| Several zips in the repo | Delete old zips, or always upload with the same name so it is replaced. |
| Workflow doesn't run at all | The workflow must be at exactly `.github/workflows/build.yml` on the default branch. |
| Gradle / dependency download errors | Re-run the job (Actions → run → *Re-run jobs*). Usually a temporary network issue. |
| Compilation error | Open the failed step, copy the first `e:` line, and fix or report it. |

## Nothing is being captured
1. Home card says **Notification access is off** → tap *Grant access*, enable Notification Vault.
2. Card says **Waiting for the system** → access is on but Android hasn't bound the service. Toggle access off and on, or reboot.
3. Card says **Capture paused** → tap *Resume capture* (Settings → Capture → master switch).
4. Check Settings → Capture → *Apps*: the app may have capture turned off.
5. Check *Excluded keywords*: a keyword might match.
6. Ongoing notifications (music, downloads, navigation) are skipped by default.

## Capture stops after a while (Xiaomi, Huawei, Oppo, Vivo, Samsung …)
Some manufacturers kill background services aggressively.
- Settings → Capture → **Battery optimization** → set Notification Vault to *Unrestricted / Don't optimize*.
- Enable *Autostart* for the app if your phone has that setting.
- Lock the app in the recent-apps screen if supported.
- See https://dontkillmyapp.com for device-specific steps.

## A message shows "New message" or no text
The sending app chose not to include content in the notification (often a privacy setting in that app, e.g. WhatsApp → Notifications → *Show preview*), or Android redacted sensitive content (e.g. one-time codes on Android 15). Notification Vault can only archive what the notification contains.

## Photos / voice notes are missing
Only notification **text** is archived. Media isn't part of notification text and isn't stored.

## App lock doesn't appear
App lock requires a screen lock or biometric enrolled on the device. If the device's lock is removed, the app opens without the prompt (it cannot authenticate).

## "This file isn't a valid backup"
Restore accepts files created by *Create backup* (`.json` or encrypted `.nvbak`). Exports (JSON/CSV/TXT from *Export*) are human-readable copies and can't be restored.

## The archive was reset
If the Android Keystore key is lost (rare: e.g. some OS updates or data restored onto another device), the encrypted database can't be opened and a new empty one is created. Keep backups.

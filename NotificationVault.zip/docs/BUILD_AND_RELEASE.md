# Build & release

## Debug builds
Every push runs `.github/workflows/build.yml`, which produces `NotificationVault-debug-N.apk`
(application id `com.aymman.notificationvault.debug`, so it can sit next to a release install).

## Signed release for Google Play
1. Create an upload keystore once (Android Studio → *Generate Signed Bundle*, or):
   ```bash
   keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 4096 -validity 10000
   ```
2. Base64-encode it: `base64 -w0 upload.jks > upload.b64` (on a phone, Termux works).
3. In the GitHub repo → *Settings → Secrets and variables → Actions*, add:
   - `KEYSTORE_BASE64` – contents of `upload.b64`
   - `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
4. Push again. The workflow additionally builds `app-release.aab` (artifact *NotificationVault-release-aab*),
   with `versionCode` = the workflow run number.
5. Never commit the keystore. Keep a safe copy — losing it means you can't update the app (unless Play App Signing is enabled).

## Play Store notes
- Notification Listener apps receive extra review. In the Play Console *App content* section declare the use of
  notification access and describe it exactly as in `PRIVACY_POLICY.md` (archive notification text locally, user-initiated).
- Data safety form: data is **not collected** (it never leaves the device unless the user exports/shares it) and
  **not shared**; it's encrypted on device; users can request deletion in-app.
- Host the privacy policy at a public URL.

## Versioning
`versionName` is in `app/build.gradle.kts`. `versionCode` comes from `NV_VERSION_CODE` (CI run number) or defaults to 1.

## Schema changes
Room schemas are exported to `app/schemas`. When changing entities: bump `AppDatabase.VERSION`, add a `Migration`
to `AppDatabase.MIGRATIONS`, and extend `MigrationTest`. Destructive migration is intentionally disabled.

# Manual testing guide (real devices)

Test on at least: one Pixel/Android One (stock), one Samsung, and one aggressive-battery OEM (Xiaomi/Oppo/Huawei). Cover Android 8, 12 and 14/15 if possible.

## 1. Onboarding & access
- [ ] Fresh install shows onboarding (4 info pages + access page). *Skip* jumps to the access page.
- [ ] *Grant access* opens the Notification Access screen (the app-specific page on Android 11+).
- [ ] Enable access, go back: page shows "Access granted", button reads *Open my vault*.
- [ ] *Set up later* also lands on Home, which then shows "Notification access is off" with *Grant access*.

## 2. Capture
- [ ] Send yourself a WhatsApp / Telegram / SMS message → appears in Home *Recent* within a second.
- [ ] Send 3 messages in the same chat → exactly 3 records (no duplicates from re-posts).
- [ ] Group chat: sender name is the member, title is the group.
- [ ] Email (Gmail) → expanded text visible in Detail.
- [ ] Dismiss the notification → record stays; Detail shows *Removed …*.
- [ ] Sender deletes the message (WhatsApp *Delete for everyone*) → archived text still readable; app makes no "deleted" claim.
- [ ] Music playback / file download → not captured (default), captured when *Skip ongoing* is off.
- [ ] Notification Vault's own notifications are never captured.
- [ ] Reboot the phone, send a message → still captured (listener rebinds).
- [ ] Settings → Capture → turn an app off → its new notifications are ignored; old ones remain.
- [ ] Add excluded keyword `code`, receive "Your code is 1234" → not captured.
- [ ] Pause capture → nothing captured; Home shows *Capture paused*; *Resume* works.

## 2b. Photos & PIN
- [ ] Telegram / Gmail picture notification → detail shows the image; list row shows the photo icon.
- [ ] WhatsApp: link folder, auto-download on, receive a photo → within ~1 min the "📷 Photo" record shows the photo ("from the WhatsApp folder").
- [ ] Sender deletes the WhatsApp photo after it was saved → still visible in the vault.
- [ ] Two photos in a row → both saved, each linked once; same file never imported twice.
- [ ] Delete the record → image files removed (Storage screen count drops).
- [ ] Image viewer: pinch-zoom, double-tap, Save writes a viewable file.
- [ ] Set PIN → reopen after auto-lock period → keypad shown; 5 wrong → 30 s pause with countdown; correct PIN unlocks.
- [ ] Fingerprint option: prompt appears, "Use PIN" returns to keypad.
- [ ] Arabic-Indic digits typed in the PIN dialog are accepted.
- [ ] Turn off / change PIN requires the current PIN.

## 3. Browsing
- [ ] Home stats match reality (send N notifications → *Today* increases by N).
- [ ] Quick filter chips open Inbox filtered by type.
- [ ] Apps list shows real icons, counts, unread badges, preview, relative time; sort & search work.
- [ ] App archive: conversation chips filter correctly; *Mark all read*; per-app settings sheet works.
- [ ] Long-press to multi-select → read/unread, pin, bookmark, share (confirm > 10), export, delete (confirm).
- [ ] Detail: copy (Android 13+ shows system clipboard UI), share opens the Sharesheet, category assignment, *Open app* only on tap.

## 4. Search
- [ ] Arabic and English text both searchable; partial words match.
- [ ] Filters: app, type, date presets, custom range, unread, pinned, bookmarked, sender, category, sort.
- [ ] Characters `%` and `_` are searched literally.
- [ ] Works in airplane mode.

## 5. Privacy & security
- [ ] App lock on → leaving the app > 30 s and returning asks for biometrics/PIN.
- [ ] Private mode on → recent-apps thumbnail is blank; screenshots blocked.
- [ ] `adb logcat | grep NV.` never prints notification text.
- [ ] `adb shell run-as com.aymman.notificationvault.debug ls databases` shows the DB; copying it out and opening with plain sqlite3 fails (encrypted).

## 6. Storage, export, backup
- [ ] Retention 7 days → *Run cleanup now* removes older unpinned records; pinned/bookmarked kept.
- [ ] Delete older than … shows a count and confirmation.
- [ ] Export JSON/CSV/TXT to Downloads; CSV opens correctly in Sheets/Excel (Arabic intact).
- [ ] Backup without password → restore on a fresh install → all records back; restoring twice adds 0.
- [ ] Backup with password → wrong password rejected; right password restores.

## 7. UI
- [ ] Light/dark/system theme; dynamic color on Android 12+.
- [ ] Arabic locale: full RTL layout, all text translated.
- [ ] Large font size (Settings → Display → Font size max) — no clipped controls.
- [ ] Tablet / landscape: layouts remain usable.
- [ ] TalkBack: tabs, buttons and icons announce meaningful labels.

# Privacy Policy — Notification Vault

_Last updated: 2026-10-23. Replace the contact line before publishing._

Notification Vault ("the app") is an on-device archive of notifications. This policy describes exactly what the current version does.

## What the app accesses
The app reads notifications only after you enable **Notification Access** for it in Android settings. You can revoke this at any time in the same place.

## What is stored
For each captured notification: the text it displayed (title, message text, expanded text, sub-text), the sender and conversation names when the notification provides them, the posting app's package name and label, the notification category, and timestamps (when it was posted and when it was archived, and when it left the notification shade).

The app does **not** store images, audio, video, files or other attachments, contact lists, or any data from inside other apps. It cannot recover content that never appeared in a notification.

## Where it is stored and how it is protected
- Only on your device, in a database encrypted with SQLCipher (AES-256).
- The database key is randomly generated on the device and wrapped by a non-exportable key in the Android Keystore.
- App data is excluded from Android cloud backup and device-to-device transfer.
- Notification content is not written to system logs.
- Optional app lock (biometrics or device credential) and private mode (hides content from the recent-apps screen and blocks screenshots).

## Sharing
- The app has **no internet permission**, no account system, and contains no analytics, crash-reporting or advertising SDKs.
- Data leaves the device only when **you** explicitly share records, export them (JSON/CSV/text) or create a backup, to a destination you choose. Exports and unencrypted backups are readable files; encrypted backups are protected by the password you set, which the app does not store and cannot recover.

## Retention and deletion
You choose how long records are kept (default: forever), per app or globally. Pinned and bookmarked records are never removed automatically. You can delete individual records, all records for an app, or the entire archive at any time. Uninstalling the app deletes all of its data.

## Children
The app is not directed at children.

## Contact
_Your name / email here._

# Notification Vault

A private, on-device archive of the notifications you receive on Android. It captures notification text the moment it arrives, keeps it after the notification is dismissed (or after the sender deletes the original message), and lets you browse it by app, search it, pin it and export it.

- **Kotlin · Jetpack Compose (Material 3) · MVVM · Hilt · Room + SQLCipher · DataStore · Coroutines/Flow**
- minSdk 26 (Android 8.0), target/compile SDK 35
- English + Arabic UI (RTL supported), light/dark theme, optional dynamic color
- No INTERNET permission, no analytics, no ads

## Build from your phone (GitHub Actions)

1. Create a repository on GitHub (private is fine).
2. **Add the workflow**: on GitHub tap **Add file → Create new file**, name it exactly
   `.github/workflows/build.yml`, paste the contents of `build.yml` and commit.
3. **Upload the project**: **Add file → Upload files**, choose `NotificationVault.zip`, commit to `main`.
   Keep the zip at the root of the repo and keep the same file name when you upload a new version.
4. Open the **Actions** tab and wait for *Build Android APK* (about 6–10 minutes the first time).
5. Open **Releases** → `build-N` → download `NotificationVault-debug-N.apk` and install it.
   (Android will ask you to allow installs from your browser or files app.)

The workflow unpacks the zip, builds the debug APK, publishes it as a pre-release, then runs the unit tests and shows their result in the run summary.

## Build on a computer

Open the folder in Android Studio (Ladybug or newer) and run the `app` configuration, or:

```bash
./gradlew assembleDebug          # APK in app/build/outputs/apk/debug/
./gradlew testDebugUnitTest      # JVM unit tests
./gradlew connectedDebugAndroidTest   # instrumentation tests (device/emulator required)
```

Requirements: JDK 17, Android SDK 35.

## First run

1. Walk through onboarding and tap **Grant access**.
2. In Android's *Notification access* list, enable **Notification Vault** (Android shows a warning — expected).
3. Return to the app. The home card should show **Capturing notifications**.

Only notifications that arrive **after** access is granted can be archived.

## Project layout

```
app/src/main/java/com/aymman/notificationvault/
  domain/            Pure Kotlin: parser, dedup, kind classifier, retention, export/backup formats & crypto
  data/db            Room entities, DAOs, database, parameterised search query builder
  data/repo          VaultRepository – single source of truth
  data/prefs         DataStore settings
  data/security      SQLCipher passphrase wrapped by an Android Keystore key
  data/backup        Export / backup / restore via Storage Access Framework
  service/           NotificationListenerService, extractor, listener status
  ui/                Compose screens (home, inbox, apps, app archive, detail, search, saved,
                     settings: privacy/capture/storage/backup/about, onboarding, lock)
  di/                Hilt module
```

A single `app` module with clear package boundaries was chosen over many Gradle modules: it keeps the build simple enough to run reliably from a phone while preserving separation of concerns.

## How capture works

- Every posted notification is reduced to text fields only (no PendingIntents, bitmaps or raw Bundles).
- **MessagingStyle** notifications (WhatsApp, Telegram, Signal, SMS …) re-post the whole visible conversation each time. Each message becomes its own record, keyed by `(package, conversation, sender, message time, text)`, so re-posts never duplicate and new messages are always captured.
- Other notifications are keyed by `(package, notification key, content)`: identical updates are ignored, changed content is kept.
- Ongoing/progress notifications and content-less group summaries are skipped by default (configurable).
- Removal from the shade only sets `removedAt`; records are never deleted by the system.
- The app never claims a message was deleted — it can't know that reliably.

See [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md), [docs/MANUAL_TESTING.md](docs/MANUAL_TESTING.md),
[docs/BUILD_AND_RELEASE.md](docs/BUILD_AND_RELEASE.md) and [PRIVACY_POLICY.md](PRIVACY_POLICY.md).

---

## بالعربي — البناء من الهاتف

1. أنشئ مستودعاً جديداً على GitHub.
2. اضغط **Add file → Create new file** واكتب الاسم بالضبط `.github/workflows/build.yml` والصق محتوى ملف `build.yml` ثم Commit.
3. اضغط **Add file → Upload files** وارفع `NotificationVault.zip` ثم Commit.
4. افتح تبويب **Actions** وانتظر انتهاء البناء.
5. افتح **Releases** ونزّل ملف الـ APK وثبّته على هاتفك.

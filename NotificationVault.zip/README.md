# Notification Vault

A private, on-device archive of the notifications you receive on Android. It captures notification text the moment it arrives, keeps it after the notification is dismissed (or after the sender deletes the original message), and lets you browse it by app, search it, pin it and export it.

- **Kotlin · Jetpack Compose (Material 3) · MVVM · Hilt · Room + SQLCipher · DataStore · Coroutines/Flow**
- minSdk 26 (Android 8.0), target/compile SDK 35
- English + Arabic UI (RTL supported), light/dark theme, optional dynamic color
- No INTERNET permission, no analytics, no ads
- Saves picture previews from notifications and, optionally, received WhatsApp photos (encrypted)
- Optional app-specific PIN (separate from the phone lock) with lock-out, fingerprint option and auto-lock

## Build from your phone (GitHub Actions)

1. Create a repository on GitHub (private is fine).
2. **Add the workflow**: on GitHub tap **Add file → Create new file**, name it exactly
   `.github/workflows/build.yml`, paste the contents of `build.yml` and commit.
3. **Upload the project**: **Add file → Upload files**, choose `NotificationVault.zip`, commit to `main`.
   Keep the zip at the root of the repo and keep the same file name when you upload a new version.
4. Open the **Actions** tab and wait for *Build Android APK* (about 6–10 minutes the first time).
5. Open **Releases** → `build-N` → download `NotificationVault-debug-N.apk` and install it.
   (Android will ask you to allow installs from your browser or files app.)

The workflow unpacks the zip, builds the debug APK, publishes it as a pre-release, then runs the unit tests and shows their result in the run summary.

## Build on a computer

Open the folder in Android Studio (Ladybug or newer) and run the `app` configuration, or:

```bash
./gradlew assembleDebug          # APK in app/build/outputs/apk/debug/
./gradlew testDebugUnitTest      # JVM unit tests
./gradlew connectedDebugAndroidTest   # instrumentation tests (device/emulator required)
```

Requirements: JDK 17, Android SDK 35.

## First run

1. Walk through onboarding and tap **Grant access**.
2. In Android's *Notification access* list, enable **Notification Vault** (Android shows a warning — expected).
3. Return to the app. The home card should show **Capturing notifications**.

Only notifications that arrive **after** access is granted can be archived.

## Photos (including WhatsApp)

- **Notification previews**: when a notification shows a picture (BigPicture style or a MessagingStyle image the
  sending app lets other apps read), an encrypted copy is saved with the record.
- **WhatsApp**: WhatsApp notifications normally don't include the photo. Turn on WhatsApp → Settings → Storage and data →
  Media auto-download → Photos, then in Notification Vault: Settings → Capture → *WhatsApp photos folder* and choose
  `Android/media/com.whatsapp/WhatsApp/Media` (the *Media* folder, so voice notes and videos work too). New files are copied into the vault shortly after each
  "📷 Photo" notification and linked to that message **by time** (WhatsApp file names don't say who sent them).
  A photo deleted before WhatsApp downloaded it can't be saved.
- Images are stored AES-256-GCM encrypted in app-private storage, deleted together with their records, and are
  **not** included in backups/exports (text only).

## Deleted messages

When WhatsApp (and apps that work the same way) replaces a message in its notification with
"This message was deleted", Notification Vault finds the archived message with the same conversation,
sender and message time, marks it 🗑️ *Deleted by sender*, and (optionally) posts an alert showing what
it said. Nothing is inferred from a notification simply disappearing. If the original was never
captured, the alert says so. Filter: Inbox → 🗑️ Deleted. The conversation can be opened as chat bubbles.

## Daily summary, statistics, grouping

- Daily summary notification around a chosen evening hour (inexact alarm, no exact-alarm permission).
- Statistics screen (Home → chart icon): per day, per hour, top apps, top senders — computed locally.
- Repetitive non-message notifications from the same app are collapsed into one expandable row.

## App PIN

Settings → Privacy & security → *App PIN*: 4–8 digits, stored only as a salted PBKDF2 hash. After 5 wrong tries entry
pauses for 30 s, doubling up to 15 min. Optional fingerprint/face unlock; auto-lock after 0 s / 30 s / 1 min / 5 min.
A forgotten PIN can't be recovered — clearing the app's data (which erases the archive) is the only reset.

## Project layout

```
app/src/main/java/com/aymman/notificationvault/
  domain/            Pure Kotlin: parser, dedup, kind classifier, retention, export/backup formats & crypto
  data/db            Room entities, DAOs, database, parameterised search query builder
  data/repo          VaultRepository – single source of truth
  data/prefs         DataStore settings
  data/security      SQLCipher passphrase wrapped by an Android Keystore key
  data/backup        Export / backup / restore via Storage Access Framework
  service/           NotificationListenerService, extractor, listener status
  ui/                Compose screens (home, inbox, apps, app archive, detail, search, saved,
                     settings: privacy/capture/storage/backup/about, onboarding, lock)
  di/                Hilt module
```

A single `app` module with clear package boundaries was chosen over many Gradle modules: it keeps the build simple enough to run reliably from a phone while preserving separation of concerns.

## How capture works

- Every posted notification is reduced to text fields only (no PendingIntents, bitmaps or raw Bundles).
- **MessagingStyle** notifications (WhatsApp, Telegram, Signal, SMS …) re-post the whole visible conversation each time. Each message becomes its own record, keyed by `(package, conversation, sender, message time, text)`, so re-posts never duplicate and new messages are always captured.
- Other notifications are keyed by `(package, notification key, content)`: identical updates are ignored, changed content is kept.
- Ongoing/progress notifications and content-less group summaries are skipped by default (configurable).
- Removal from the shade only sets `removedAt`; records are never deleted by the system.
- The app never claims a message was deleted — it can't know that reliably.

See [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md), [docs/MANUAL_TESTING.md](docs/MANUAL_TESTING.md),
[docs/BUILD_AND_RELEASE.md](docs/BUILD_AND_RELEASE.md) and [PRIVACY_POLICY.md](PRIVACY_POLICY.md).

---

## بالعربي — البناء من الهاتف

1. أنشئ مستودعاً جديداً على GitHub.
2. اضغط **Add file → Create new file** واكتب الاسم بالضبط `.github/workflows/build.yml` والصق محتوى ملف `build.yml` ثم Commit.
3. اضغط **Add file → Upload files** وارفع `NotificationVault.zip` ثم Commit.
4. افتح تبويب **Actions** وانتظر انتهاء البناء.
5. افتح **Releases** ونزّل ملف الـ APK وثبّته على هاتفك.

# SQLCipher uses JNI; keep its classes.
-keep class net.zetetic.database.** { *; }
-keep class net.zetetic.database.sqlcipher.** { *; }

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.aymman.notificationvault.**$$serializer { *; }
-keepclassmembers class com.aymman.notificationvault.** {
    *** Companion;
}
-keepclasseswithmembers class com.aymman.notificationvault.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontwarn net.zetetic.**

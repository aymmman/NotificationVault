package com.aymman.notificationvault.data

import com.aymman.notificationvault.data.db.QueryBuilder
import com.aymman.notificationvault.domain.model.NotificationKind
import com.aymman.notificationvault.domain.model.ReadFilter
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.domain.model.SortOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QueryBuilderTest {

    @Test
    fun emptyFiltersHaveNoWhereClause() {
        val b = QueryBuilder.build(SearchFilters())
        assertFalse(b.sql.contains("WHERE"))
        assertTrue(b.sql.contains("ORDER BY n.receivedAt DESC"))
        assertTrue(b.args.isEmpty())
    }

    @Test
    fun eachSearchTermBindsSixLikeArguments_andNeverInlinesUserText() {
        val b = QueryBuilder.build(SearchFilters(query = "hello world'; DROP TABLE"))
        assertFalse(b.sql.contains("hello"))
        assertFalse(b.sql.contains("DROP"))
        assertEquals(4 * 6, b.args.size)
        assertEquals("%hello%", b.args.first())
    }

    @Test
    fun likeWildcardsAreEscaped() {
        assertEquals("50\\%\\_off\\\\", QueryBuilder.escapeLike("50%_off\\"))
    }

    @Test
    fun filtersAreCombinedWithAnd() {
        val b = QueryBuilder.build(
            SearchFilters(
                packageName = "com.whatsapp",
                kind = NotificationKind.MESSAGE,
                read = ReadFilter.UNREAD,
                pinnedOnly = true,
                fromMillis = 10,
                toMillis = 20,
                sender = "Sara",
                conversationId = "c1",
                sort = SortOrder.OLDEST,
            ),
            hideMuted = true,
            limit = 50,
        )
        assertTrue(b.sql.contains("n.packageName = ?"))
        assertTrue(b.sql.contains("n.kind = ?"))
        assertTrue(b.sql.contains("n.isRead = 0"))
        assertTrue(b.sql.contains("n.isPinned = 1"))
        assertTrue(b.sql.contains("n.senderName = ?"))
        assertTrue(b.sql.contains("n.conversationId = ?"))
        assertTrue(b.sql.contains("a.muted"))
        assertTrue(b.sql.contains("ORDER BY n.receivedAt ASC"))
        assertTrue(b.sql.endsWith("LIMIT 50"))
        assertEquals(listOf<Any>("com.whatsapp", "MESSAGE", "Sara", "c1", 10L, 20L), b.args)
    }

    @Test
    fun pinnedAndBookmarkedTogetherMeansEither() {
        val b = QueryBuilder.build(SearchFilters(pinnedOnly = true, bookmarkedOnly = true))
        assertTrue(b.sql.contains("(n.isPinned = 1 OR n.isBookmarked = 1)"))
    }
}

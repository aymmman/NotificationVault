package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.model.NotificationKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

class KindClassifierTest {
    @Test
    fun categoryWins() {
        assertEquals(NotificationKind.EMAIL, KindClassifier.classify("com.whatsapp", "email", false))
        assertEquals(NotificationKind.CALL, KindClassifier.classify("x", "missed_call", false))
        assertEquals(NotificationKind.SOCIAL, KindClassifier.classify("x", "social", false))
        assertEquals(NotificationKind.MESSAGE, KindClassifier.classify("x", "msg", false))
    }

    @Test
    fun packageFallbacks() {
        assertEquals(NotificationKind.MESSAGE, KindClassifier.classify("org.telegram.messenger", null, false))
        assertEquals(NotificationKind.SOCIAL, KindClassifier.classify("com.instagram.android", null, false))
        assertEquals(NotificationKind.EMAIL, KindClassifier.classify("com.google.android.gm", null, false))
        assertEquals(NotificationKind.CALL, KindClassifier.classify("com.google.android.dialer", null, false))
        assertEquals(NotificationKind.OTHER, KindClassifier.classify("com.unknown.app", null, false))
    }

    @Test
    fun messagingStyleMeansMessage() {
        assertEquals(NotificationKind.MESSAGE, KindClassifier.classify("com.instagram.android", null, true))
    }
}

class CaptureFilterTest {
    @Test
    fun parseKeywords_handlesCommasNewlinesAndArabicComma() {
        assertEquals(listOf("otp", "رمز", "code"), CaptureFilter.parseKeywords(" otp ,رمز،\ncode,, otp"))
    }
}

class RetentionPolicyTest {
    private val now = 1_800_000_000_000L
    private val day = TimeUnit.DAYS.toMillis(1)

    @Test
    fun zeroMeansForever() {
        assertNull(RetentionPolicy.cutoffMillis(now, 0))
        assertFalse(RetentionPolicy.isExpired(0L, pinned = false, bookmarked = false, now = now, days = 0))
    }

    @Test
    fun oldUnprotectedRecordsExpire() {
        assertEquals(now - 30 * day, RetentionPolicy.cutoffMillis(now, 30))
        assertTrue(RetentionPolicy.isExpired(now - 31 * day, pinned = false, bookmarked = false, now = now, days = 30))
        assertFalse(RetentionPolicy.isExpired(now - 29 * day, pinned = false, bookmarked = false, now = now, days = 30))
    }

    @Test
    fun pinnedAndBookmarkedNeverExpire() {
        assertFalse(RetentionPolicy.isExpired(now - 400 * day, pinned = true, bookmarked = false, now = now, days = 30))
        assertFalse(RetentionPolicy.isExpired(now - 400 * day, pinned = false, bookmarked = true, now = now, days = 30))
    }

    @Test
    fun appOverrideWins() {
        assertEquals(7, RetentionPolicy.effectiveDays(30, 7))
        assertEquals(30, RetentionPolicy.effectiveDays(30, null))
        assertEquals(0, RetentionPolicy.effectiveDays(30, 0))
    }
}

package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.media.PhotoMatcher
import com.aymman.notificationvault.domain.security.PinPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhotoMatcherTest {
    private val t0 = 1_800_000_000_000L

    @Test
    fun matchesEachPhotoToTheClosestFileAfterIt() {
        val photos = listOf(PhotoMatcher.Photo(1, t0), PhotoMatcher.Photo(2, t0 + 60_000))
        val files = listOf(
            PhotoMatcher.File("a", t0 + 3_000),
            PhotoMatcher.File("b", t0 + 62_000),
            PhotoMatcher.File("old", t0 - 9 * 60_000),
        )
        assertEquals(listOf(1L to "a", 2L to "b"), PhotoMatcher.match(photos, files))
    }

    @Test
    fun neverMatchesOutsideTolerance() {
        val photos = listOf(PhotoMatcher.Photo(1, t0))
        val files = listOf(PhotoMatcher.File("far", t0 + PhotoMatcher.TOLERANCE_MS + 1))
        assertTrue(PhotoMatcher.match(photos, files).isEmpty())
    }

    @Test
    fun eachFileUsedOnce() {
        val photos = listOf(PhotoMatcher.Photo(1, t0), PhotoMatcher.Photo(2, t0 + 1_000))
        val files = listOf(PhotoMatcher.File("only", t0 + 2_000))
        val result = PhotoMatcher.match(photos, files)
        assertEquals(1, result.size)
        assertEquals("only", result.single().second)
    }

    @Test
    fun prefersFilesWrittenAfterTheMessage() {
        val photos = listOf(PhotoMatcher.Photo(1, t0))
        val files = listOf(PhotoMatcher.File("before", t0 - 120_000), PhotoMatcher.File("after", t0 + 150_000))
        assertEquals("after", PhotoMatcher.match(photos, files).single().second)
    }
}

class PinPolicyTest {
    @Test
    fun format() {
        assertTrue(PinPolicy.isValidFormat("1234"))
        assertTrue(PinPolicy.isValidFormat("12345678"))
        assertFalse(PinPolicy.isValidFormat("123"))
        assertFalse(PinPolicy.isValidFormat("123456789"))
        assertFalse(PinPolicy.isValidFormat("12a4"))
        assertFalse(PinPolicy.isValidFormat("١٢٣٤")) // must be normalised first
        assertEquals("1234", PinPolicy.normalize("١٢٣٤"))
        assertEquals("5678", PinPolicy.normalize("۵۶7-8"))
    }

    @Test
    fun hashMatchesOnlyTheRightPin() {
        val salt = PinPolicy.newSalt()
        val h = PinPolicy.hash("2468", salt, iterations = 1_000)
        assertTrue(PinPolicy.matches("2468", salt, h, iterations = 1_000))
        assertFalse(PinPolicy.matches("2469", salt, h, iterations = 1_000))
        assertFalse(PinPolicy.matches("2468", PinPolicy.newSalt(), h, iterations = 1_000))
    }

    @Test
    fun lockoutGrowsAndIsCapped() {
        assertEquals(0L, PinPolicy.lockoutMs(4))
        assertEquals(30_000L, PinPolicy.lockoutMs(5))
        assertEquals(60_000L, PinPolicy.lockoutMs(6))
        assertEquals(120_000L, PinPolicy.lockoutMs(7))
        assertEquals(15 * 60_000L, PinPolicy.lockoutMs(50))
    }
}

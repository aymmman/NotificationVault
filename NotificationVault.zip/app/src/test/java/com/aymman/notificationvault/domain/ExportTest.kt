package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.export.BackupApp
import com.aymman.notificationvault.domain.export.BackupCrypto
import com.aymman.notificationvault.domain.export.BackupNotification
import com.aymman.notificationvault.domain.export.BackupPayload
import com.aymman.notificationvault.domain.export.BackupValidator
import com.aymman.notificationvault.domain.export.CsvWriter
import com.aymman.notificationvault.domain.export.ExportFormatter
import com.aymman.notificationvault.domain.export.ExportRecord
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.TimeZone

class CsvWriterTest {
    @Test
    fun quotesAndEscapes() {
        assertEquals("\"he said \"\"hi\"\"\"", CsvWriter.escape("he said \"hi\""))
        assertEquals("\"\"", CsvWriter.escape(null))
        assertEquals("\"a,b\nc\"", CsvWriter.escape("a,b\nc"))
    }

    @Test
    fun neutralisesFormulaInjection() {
        assertEquals("\"'=SUM(A1)\"", CsvWriter.escape("=SUM(A1)"))
        assertEquals("\"'+1\"", CsvWriter.escape("+1"))
        assertEquals("\"'@cmd\"", CsvWriter.escape("@cmd"))
    }

    @Test
    fun startsWithBomAndUsesCrlf() {
        val out = CsvWriter.write(listOf("a", "b"), listOf(listOf("1", "2")))
        assertTrue(out.startsWith("﻿"))
        assertEquals("﻿\"a\",\"b\"\r\n\"1\",\"2\"\r\n", out)
    }
}

class ExportFormatterTest {
    private val utc = TimeZone.getTimeZone("UTC")
    private val record = ExportRecord(
        app = "WhatsApp", packageName = "com.whatsapp", title = "Sara", text = "Hello, \"world\"",
        sender = "Sara", conversation = "Sara", category = "msg", kind = "MESSAGE",
        receivedAt = 0L, originalTimestamp = 0L, pinned = true,
    )

    @Test
    fun csvHasHeaderAndOneRowPerRecord() {
        val csv = ExportFormatter.csv(listOf(record, record), utc)
        val lines = csv.removePrefix("﻿").trimEnd().split("\r\n")
        assertEquals(3, lines.size)
        assertTrue(lines[0].startsWith("\"received_at\""))
        assertTrue(lines[1].startsWith("\"1970-01-01 00:00:00\""))
        assertTrue(lines[1].contains("\"Hello, \"\"world\"\"\""))
        assertTrue(lines[1].endsWith("\"true\",\"false\""))
    }

    @Test
    fun textContainsAppSenderAndBody() {
        val txt = ExportFormatter.text(listOf(record), utc)
        assertTrue(txt.contains("[1970-01-01 00:00:00] WhatsApp"))
        assertTrue(txt.contains("Sara\n"))
        assertTrue(txt.contains("Hello, \"world\""))
        assertTrue(txt.startsWith("Notification Vault export — 1 record(s)"))
    }
}

class BackupCryptoTest {
    private val fastIterations = 1_000
    private val data = "{\"hello\":\"مرحبا\"}".toByteArray()

    @Test
    fun roundTrip() {
        val enc = BackupCrypto.encrypt(data, "s3cret".toCharArray(), fastIterations)
        assertTrue(BackupCrypto.isEncrypted(enc))
        assertFalse(enc.toString(Charsets.UTF_8).contains("hello"))
        assertArrayEquals(data, BackupCrypto.decrypt(enc, "s3cret".toCharArray(), fastIterations))
    }

    @Test
    fun wrongPasswordIsDetected() {
        val enc = BackupCrypto.encrypt(data, "right".toCharArray(), fastIterations)
        try {
            BackupCrypto.decrypt(enc, "wrong".toCharArray(), fastIterations)
            fail("expected WrongPasswordException")
        } catch (e: BackupCrypto.WrongPasswordException) {
            // expected
        }
    }

    @Test
    fun tamperingIsDetected() {
        val enc = BackupCrypto.encrypt(data, "pw".toCharArray(), fastIterations)
        enc[enc.size - 1] = (enc[enc.size - 1].toInt() xor 1).toByte()
        try {
            BackupCrypto.decrypt(enc, "pw".toCharArray(), fastIterations)
            fail("expected WrongPasswordException")
        } catch (e: BackupCrypto.WrongPasswordException) {
            // expected
        }
    }

    @Test
    fun saltMakesEachEncryptionDifferent() {
        val a = BackupCrypto.encrypt(data, "pw".toCharArray(), fastIterations)
        val b = BackupCrypto.encrypt(data, "pw".toCharArray(), fastIterations)
        assertFalse(a.contentEquals(b))
    }

    @Test
    fun plainJsonIsNotEncrypted() {
        assertFalse(BackupCrypto.isEncrypted("{\"format\":1}".toByteArray()))
    }
}

class BackupValidatorTest {
    private fun payload(version: Int = 1, format: String = "notification-vault-backup", key: String = "k") = BackupPayload(
        format = format,
        version = version,
        createdAt = 1,
        apps = listOf(BackupApp("p", "P", 1, 1)),
        notifications = listOf(
            BackupNotification(dedupKey = key, packageName = "p", notificationKey = "n", kind = "OTHER", receivedAt = 1, originalTimestamp = 1),
        ),
    )

    @Test
    fun acceptsValid() = assertEquals(BackupValidator.Result.Ok, BackupValidator.validate(payload()))

    @Test
    fun rejectsWrongFormatNewerVersionAndMalformedRecords() {
        assertTrue(BackupValidator.validate(payload(format = "other")) is BackupValidator.Result.Invalid)
        assertTrue(BackupValidator.validate(payload(version = 99)) is BackupValidator.Result.Invalid)
        assertTrue(BackupValidator.validate(payload(key = "")) is BackupValidator.Result.Invalid)
    }
}

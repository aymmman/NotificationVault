package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.model.CaptureOptions
import com.aymman.notificationvault.domain.model.NotificationKind
import com.aymman.notificationvault.domain.model.RawMessage
import com.aymman.notificationvault.domain.model.RawNotification
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationParserTest {

    private fun whatsapp(vararg messages: RawMessage, group: Boolean = false) = RawNotification(
        packageName = "com.whatsapp",
        key = "0|com.whatsapp|1|chat@s.whatsapp.net|10123",
        postTime = 1_700_000_000_000,
        title = "Sara",
        text = messages.lastOrNull()?.text,
        conversationTitle = if (group) "Family" else null,
        isGroupConversation = group,
        shortcutId = "chat@s.whatsapp.net",
        category = "msg",
        messages = messages.toList(),
    )

    @Test
    fun messagingStyle_eachMessageBecomesARecord() {
        val raw = whatsapp(
            RawMessage("Hi", 1_000, "Sara"),
            RawMessage("Are you there?", 2_000, "Sara"),
        )
        val records = NotificationParser.parse(raw)
        assertEquals(2, records.size)
        assertEquals(listOf("Hi", "Are you there?"), records.map { it.text })
        assertTrue(records.all { it.isFromMessagingStyle })
        assertTrue(records.all { it.kind == NotificationKind.MESSAGE })
        assertEquals("Sara", records[0].senderName)
        assertEquals(1_000L, records[0].originalTimestamp)
        assertEquals("chat@s.whatsapp.net", records[0].conversationId)
    }

    @Test
    fun messagingStyle_repostDoesNotCreateNewKeys_newMessageDoes() {
        val first = NotificationParser.parse(whatsapp(RawMessage("Hi", 1_000, "Sara")))
        val second = NotificationParser.parse(
            whatsapp(RawMessage("Hi", 1_000, "Sara"), RawMessage("Call me", 3_000, "Sara")),
        )
        val firstKeys = first.map { it.dedupKey }.toSet()
        val newKeys = second.map { it.dedupKey }.filterNot { it in firstKeys }
        assertEquals(1, newKeys.size)
        assertEquals("Call me", second.first { it.dedupKey == newKeys.single() }.text)
    }

    @Test
    fun messagingStyle_identicalMessagesInOnePostAreDeduplicated() {
        val raw = whatsapp(RawMessage("ok", 5_000, "Sara"), RawMessage("ok", 5_000, "Sara"))
        assertEquals(1, NotificationParser.parse(raw).size)
    }

    @Test
    fun messagingStyle_groupUsesConversationTitleAndMessageSender() {
        val raw = whatsapp(RawMessage("Dinner at 8", 1_000, "Omar"), group = true)
        val r = NotificationParser.parse(raw).single()
        assertEquals("Omar", r.senderName)
        assertEquals("Family", r.title)
        assertEquals("Family", r.conversationTitle)
    }

    @Test
    fun messagingStyle_blankMessagesAreSkipped() {
        val raw = whatsapp(RawMessage("   ", 1_000, "Sara"), RawMessage(null, 2_000, "Sara"), RawMessage("real", 3_000, "Sara"))
        assertEquals(listOf("real"), NotificationParser.parse(raw).map { it.text })
    }

    @Test
    fun single_identicalUpdateKeepsKey_changedContentGetsNewKey() {
        val base = RawNotification(packageName = "com.example.news", key = "k1", postTime = 10, title = "Headline", text = "Story A")
        val a = NotificationParser.parse(base).single()
        val again = NotificationParser.parse(base.copy(postTime = 20)).single()
        val changed = NotificationParser.parse(base.copy(text = "Story B")).single()
        assertEquals(a.dedupKey, again.dedupKey)
        assertNotEquals(a.dedupKey, changed.dedupKey)
    }

    @Test
    fun single_bigTextIsKeptAsExpandedText() {
        val raw = RawNotification(
            packageName = "com.google.android.gm", key = "k", postTime = 1,
            title = "Boss", text = "Quarterly report", bigText = "Quarterly report\nPlease review by Friday",
        )
        val r = NotificationParser.parse(raw).single()
        assertEquals("Quarterly report", r.text)
        assertEquals("Quarterly report\nPlease review by Friday", r.bigText)
        assertEquals(NotificationKind.EMAIL, r.kind)
        assertEquals("Boss", r.senderName)
    }

    @Test
    fun single_inboxLinesUsedWhenNoBigText() {
        val raw = RawNotification(packageName = "x.y", key = "k", postTime = 1, title = "3 updates", textLines = listOf("a", "b", "c"))
        val r = NotificationParser.parse(raw).single()
        assertEquals("a\nb\nc", r.text)
        assertNull(r.bigText)
    }

    @Test
    fun emptyNotificationIsSkipped() {
        assertTrue(NotificationParser.parse(RawNotification(packageName = "x.y", key = "k", postTime = 1)).isEmpty())
    }

    @Test
    fun groupSummaryWithoutMessagesIsSkippedByDefault_butCanBeKept() {
        val raw = RawNotification(packageName = "x.y", key = "k", postTime = 1, title = "5 new messages", isGroupSummary = true)
        assertTrue(NotificationParser.parse(raw).isEmpty())
        assertEquals(1, NotificationParser.parse(raw, CaptureOptions(skipGroupSummaries = false)).size)
    }

    @Test
    fun ongoingAndProgressAreSkippedByDefault() {
        val music = RawNotification(packageName = "com.spotify.music", key = "k", postTime = 1, title = "Song", isOngoing = true)
        val download = RawNotification(packageName = "x.y", key = "d", postTime = 1, title = "Downloading", hasProgress = true)
        assertTrue(NotificationParser.parse(music).isEmpty())
        assertTrue(NotificationParser.parse(download).isEmpty())
        assertEquals(1, NotificationParser.parse(music, CaptureOptions(skipOngoing = false)).size)
    }

    @Test
    fun systemNoiseFilteredOnlyWhenEnabled() {
        val raw = RawNotification(packageName = "com.android.systemui", key = "k", postTime = 1, title = "USB debugging")
        assertTrue(NotificationParser.parse(raw).isEmpty())
        assertEquals(1, NotificationParser.parse(raw, CaptureOptions(filterSystemNoise = false)).size)
    }

    @Test
    fun excludedKeywordsBlockCapture_caseInsensitive() {
        val raw = RawNotification(packageName = "com.bank", key = "k", postTime = 1, title = "Bank", text = "Your OTP is 1234")
        assertTrue(NotificationParser.parse(raw, CaptureOptions(excludedKeywords = listOf("otp"))).isEmpty())
        assertEquals(1, NotificationParser.parse(raw, CaptureOptions(excludedKeywords = listOf("password"))).size)
    }

    @Test
    fun controlCharactersRemovedAndTextTruncated() {
        val long = "a".repeat(NotificationParser.MAX_TEXT_LENGTH + 500)
        val raw = RawNotification(packageName = "x.y", key = "k", postTime = 1, title = "T\u0000itle\u0007", text = long)
        val r = NotificationParser.parse(raw).single()
        assertEquals("Title", r.title)
        assertEquals(NotificationParser.MAX_TEXT_LENGTH, r.text!!.length)
    }

    @Test
    fun arabicTextIsPreserved() {
        val raw = whatsapp(RawMessage("مرحبا، كيف حالك؟", 1_000, "سارة"))
        val r = NotificationParser.parse(raw).single()
        assertEquals("مرحبا، كيف حالك؟", r.text)
        assertEquals("سارة", r.senderName)
    }

    @Test
    fun blankPackageIsRejected() {
        assertTrue(NotificationParser.parse(RawNotification(packageName = "", key = "k", postTime = 1, title = "x")).isEmpty())
    }

    @Test
    fun sha256IsStableAndSeparatorAware() {
        assertEquals(NotificationParser.sha256("a", "b"), NotificationParser.sha256("a", "b"))
        assertNotEquals(NotificationParser.sha256("ab", ""), NotificationParser.sha256("a", "b"))
        assertEquals(64, NotificationParser.sha256("x").length)
    }
}

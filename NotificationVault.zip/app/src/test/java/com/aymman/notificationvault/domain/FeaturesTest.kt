package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.media.MediaKind
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class DeletionDetectorTest {
    @Test
    fun recognisesNotices() {
        assertTrue(DeletionDetector.isDeletionNotice("This message was deleted"))
        assertTrue(DeletionDetector.isDeletionNotice("🚫 This message was deleted"))
        assertTrue(DeletionDetector.isDeletionNotice("تم حذف هذه الرسالة"))
        assertTrue(DeletionDetector.isDeletionNotice("Ce message a été supprimé"))
    }

    @Test
    fun ignoresNormalTextAndLongMessages() {
        assertFalse(DeletionDetector.isDeletionNotice(null))
        assertFalse(DeletionDetector.isDeletionNotice("Can you delete this message?"))
        assertFalse(DeletionDetector.isDeletionNotice("x".repeat(60) + " this message was deleted"))
    }
}

class GroupingTest {
    private fun keys(vararg k: String?) = k.toList()

    @Test
    fun collapsesRunsOfThreeOrMore() {
        val runs = Grouping.runs(keys("ig", "ig", "ig", null, "fb", "fb"), keyOf = { it })
        assertEquals(4, runs.size)
        assertTrue(runs[0] is Run.Group)
        assertEquals(3, (runs[0] as Run.Group).items.size)
        assertTrue(runs.drop(1).all { it is Run.Single })
    }

    @Test
    fun nullKeysNeverGroup() {
        val runs = Grouping.runs(keys(null, null, null, null), keyOf = { it })
        assertEquals(4, runs.size)
        assertTrue(runs.all { it is Run.Single })
    }

    @Test
    fun preservesOrderAndAllItems() {
        val items = keys("a", "a", "a", "b", "a", "a", "a", "a")
        val flat = Grouping.runs(items, keyOf = { it }).flatMap {
            when (it) {
                is Run.Single -> listOf(it.item)
                is Run.Group -> it.items
            }
        }
        assertEquals(items, flat)
    }
}

class StatsCalculatorTest {
    private val utc = ZoneOffset.UTC
    private val day = LocalDate.of(2026, 10, 23)
    private fun at(d: LocalDate, h: Int) = d.atTime(h, 15).toInstant(utc).toEpochMilli()

    @Test
    fun hoursAndPeak() {
        val ts = listOf(at(day, 9), at(day, 9), at(day, 21))
        val h = StatsCalculator.byHour(ts, utc)
        assertEquals(2, h[9])
        assertEquals(1, h[21])
        assertEquals(9, StatsCalculator.peakHour(h))
        assertEquals(-1, StatsCalculator.peakHour(IntArray(24)))
    }

    @Test
    fun daysIncludeEmptyDaysInOrder() {
        val ts = listOf(at(day, 1), at(day.minusDays(2), 1), at(day.minusDays(10), 1))
        val d = StatsCalculator.byDay(ts, days = 3, today = day, zone = utc)
        assertEquals(listOf(day.minusDays(2), day.minusDays(1), day), d.map { it.first })
        assertArrayEquals(byteArrayOf(1, 0, 1), d.map { it.second.toByte() }.toByteArray())
    }
}

class MediaKindTest {
    @Test
    fun fromTextAndMime() {
        assertEquals(MediaKind.IMAGE, MediaKind.ofText("📷 Photo"))
        assertEquals(MediaKind.VOICE, MediaKind.ofText("🎤 Voice message (0:12)"))
        assertEquals(MediaKind.VIDEO, MediaKind.ofText("🎥 Video"))
        assertEquals(null, MediaKind.ofText("hello"))
        assertEquals(MediaKind.VOICE, MediaKind.ofMime("audio/ogg"))
        assertEquals(MediaKind.VOICE, MediaKind.ofMime("application/ogg"))
        assertEquals(MediaKind.VIDEO, MediaKind.ofMime("video/mp4"))
        assertEquals(MediaKind.IMAGE, MediaKind.ofMime("image/webp"))
    }
}

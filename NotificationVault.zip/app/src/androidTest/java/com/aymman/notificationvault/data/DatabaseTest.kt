package com.aymman.notificationvault.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.aymman.notificationvault.data.db.AppDatabase
import com.aymman.notificationvault.data.db.MonitoredAppEntity
import com.aymman.notificationvault.data.prefs.AppSettings
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.RawMessage
import com.aymman.notificationvault.domain.model.RawNotification
import com.aymman.notificationvault.domain.model.ReadFilter
import com.aymman.notificationvault.domain.model.SearchFilters
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.TimeUnit

/**
 * Exercises the real Room schema, DAOs and repository against an in-memory database.
 * (Encryption is covered by the production factory; it doesn't change SQL behaviour.)
 */
@RunWith(AndroidJUnit4::class)
class DatabaseTest {

    private lateinit var db: AppDatabase
    private lateinit var repo: VaultRepository
    private var now = 1_800_000_000_000L
    private val settings = AppSettings(onboardingDone = true)

    @Before
    fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries().build()
        repo = VaultRepository(db, ownPackage = "com.aymman.notificationvault", attachmentStore = null, clock = { now })
    }

    @After
    fun tearDown() = db.close()

    private fun chat(vararg msgs: RawMessage) = RawNotification(
        packageName = "com.whatsapp", key = "wa-key", postTime = now, title = "Sara",
        shortcutId = "sara@chat", category = "msg", messages = msgs.toList(),
    )

    @Test
    fun capture_insertsAndDeduplicatesReposts() = runTest {
        assertEquals(1, repo.capture(chat(RawMessage("Hi", 1, "Sara")), "WhatsApp", settings).inserted)
        assertEquals(1, repo.capture(chat(RawMessage("Hi", 1, "Sara"), RawMessage("Call me", 2, "Sara")), "WhatsApp", settings).inserted)
        assertEquals(0, repo.capture(chat(RawMessage("Hi", 1, "Sara"), RawMessage("Call me", 2, "Sara")), "WhatsApp", settings).inserted)
        assertEquals(2, repo.observeTotal().first())
        assertEquals(1, repo.observeConversationCount().first())
        val app = db.appDao().get("com.whatsapp")
        assertNotNull(app)
        assertEquals("WhatsApp", app!!.appLabel)
    }

    @Test
    fun capture_respectsMasterSwitchOwnPackageAndPerAppToggle() = runTest {
        val n = RawNotification(packageName = "com.example", key = "k", postTime = now, title = "T", text = "x")
        assertEquals(0, repo.capture(n, "Ex", settings.copy(captureEnabled = false)).inserted)
        assertEquals(0, repo.capture(n.copy(packageName = "com.aymman.notificationvault"), "Me", settings).inserted)
        assertEquals(1, repo.capture(n, "Ex", settings).inserted)
        repo.setAppCaptureEnabled("com.example", false)
        assertEquals(0, repo.capture(n.copy(text = "new text"), "Ex", settings).inserted)
    }

    @Test
    fun capture_appliesKeywordRules() = runTest {
        repo.addKeywordRule("OTP")
        val n = RawNotification(packageName = "com.bank", key = "k", postTime = now, title = "Bank", text = "Your otp is 1234")
        assertEquals(0, repo.capture(n, "Bank", settings).inserted)
    }

    @Test
    fun removal_marksButNeverDeletes() = runTest {
        repo.capture(chat(RawMessage("Hi", 1, "Sara")), "WhatsApp", settings)
        repo.onRemoved("wa-key")
        val rows = repo.observeRows(SearchFilters()).first()
        assertEquals(1, rows.size)
        assertNotNull(rows.single().n.removedAt)
    }

    @Test
    fun search_matchesTextSenderAndAppLabel() = runTest {
        repo.capture(chat(RawMessage("Meet at the café", 1, "Sara")), "WhatsApp", settings)
        repo.capture(RawNotification(packageName = "com.google.android.gm", key = "g", postTime = now, title = "Boss", text = "Report"), "Gmail", settings)
        assertEquals(1, repo.observeRows(SearchFilters(query = "café")).first().size)
        assertEquals(1, repo.observeRows(SearchFilters(query = "sara")).first().size)
        assertEquals(1, repo.observeRows(SearchFilters(query = "gmail")).first().size)
        assertEquals(0, repo.observeRows(SearchFilters(query = "100%")).first().size)
        assertEquals(2, repo.observeRows(SearchFilters(read = ReadFilter.UNREAD)).first().size)
    }

    @Test
    fun actions_readPinBookmarkDelete() = runTest {
        repo.capture(chat(RawMessage("a", 1, "Sara"), RawMessage("b", 2, "Sara")), "WhatsApp", settings)
        val ids = repo.observeRows(SearchFilters()).first().map { it.n.id }
        repo.setRead(ids, true)
        assertEquals(0, repo.observeUnread().first())
        repo.setPinned(listOf(ids[0]), true)
        repo.setBookmarked(listOf(ids[1]), true)
        assertEquals(2, repo.observeSavedCount().first())
        assertEquals(1, repo.delete(listOf(ids[0])))
        assertEquals(1, repo.observeTotal().first())
    }

    @Test
    fun retention_keepsPinnedAndHonoursPerAppOverride() = runTest {
        val day = TimeUnit.DAYS.toMillis(1)
        now -= 40 * day
        repo.capture(RawNotification(packageName = "a.app", key = "1", postTime = now, title = "old"), "A", settings)
        repo.capture(RawNotification(packageName = "a.app", key = "2", postTime = now, title = "old pinned"), "A", settings)
        repo.capture(RawNotification(packageName = "b.app", key = "3", postTime = now, title = "old b"), "B", settings)
        now += 40 * day
        repo.capture(RawNotification(packageName = "a.app", key = "4", postTime = now, title = "new"), "A", settings)
        val pinned = repo.observeRows(SearchFilters(query = "pinned")).first().single().n.id
        repo.setPinned(listOf(pinned), true)
        repo.setAppRetention("b.app", 0) // keep b.app forever

        val deleted = repo.applyRetention(globalDays = 30)
        assertEquals(1, deleted)
        val titles = repo.observeRows(SearchFilters()).first().map { it.n.title }.toSet()
        assertEquals(setOf("old pinned", "old b", "new"), titles)
    }

    @Test
    fun appSummaries_countUnreadAndPreview() = runTest {
        repo.capture(chat(RawMessage("first", 1, "Sara"), RawMessage("second", 2, "Sara")), "WhatsApp", settings)
        val s = repo.observeAppSummaries().first().single()
        assertEquals(2, s.total)
        assertEquals(2, s.unread)
        assertTrue(s.preview == "first" || s.preview == "second")
    }

    @Test
    fun imageMessage_isMarkedAndAttachmentLinks() = runTest {
        val r = repo.capture(chat(RawMessage(null, 5, "Sara", hasImage = true)), "WhatsApp", settings)
        assertEquals(1, r.inserted)
        assertEquals("📷", r.records.single().text)
        assertEquals(0, r.records.single().messageIndex)
        val photos = repo.photoMessagesWithoutImage(listOf("com.whatsapp"), since = 0)
        assertEquals(1, photos.size)
        val id = repo.idForDedupKey(r.records.single().dedupKey)!!
        val saved = com.aymman.notificationvault.data.media.AttachmentStore.Saved("f.enc", "image/jpeg", 10, 10, 100)
        assertTrue(repo.addAttachment(id, saved, "WHATSAPP_FOLDER", "doc-1"))
        // Same source document can't be imported twice.
        assertFalse(repo.addAttachment(id, saved.copy(fileName = "g.enc"), "WHATSAPP_FOLDER", "doc-1"))
        assertEquals(1, repo.observeRows(SearchFilters()).first().single().attachmentCount)
        assertTrue(repo.photoMessagesWithoutImage(listOf("com.whatsapp"), since = 0).isEmpty())
        // Deleting the record removes its attachment rows.
        repo.delete(listOf(id))
        assertEquals(0, repo.observeAttachmentCount().first())
    }

    @Test
    fun deletionNotice_marksTheOriginalMessage() = runTest {
        repo.capture(chat(RawMessage("secret plan", 10_000, "Sara"), RawMessage("other", 20_000, "Sara")), "WhatsApp", settings)
        val r = repo.capture(
            chat(RawMessage("This message was deleted", 10_000, "Sara"), RawMessage("other", 20_000, "Sara")),
            "WhatsApp",
            settings,
        )
        assertEquals(1, r.deletions.size)
        assertEquals("secret plan", r.deletions.single().original?.text)
        val deleted = repo.observeRows(SearchFilters(deletedOnly = true)).first()
        assertEquals(listOf("secret plan"), deleted.map { it.n.text })
        // The notice itself is hidden from normal lists.
        assertTrue(repo.observeRows(SearchFilters()).first().none { it.n.isDeletionNotice })
        assertEquals(1, repo.observeDeletedCount().first())
    }

    @Test
    fun deletionNotice_withoutCapturedOriginal_reportsNull() = runTest {
        val r = repo.capture(chat(RawMessage("This message was deleted", 99_000, "Sara")), "WhatsApp", settings)
        assertEquals(1, r.deletions.size)
        assertEquals(null, r.deletions.single().original)
    }

    @Test
    fun deletingAppCascadesToItsRecords() = runTest {
        repo.capture(chat(RawMessage("x", 1, "Sara")), "WhatsApp", settings)
        db.appDao().upsert(MonitoredAppEntity("other", "Other", 0, 0))
        db.openHelper.writableDatabase.execSQL("DELETE FROM apps WHERE packageName = 'com.whatsapp'")
        assertEquals(0, repo.observeTotal().first())
    }
}

package com.aymman.notificationvault.ui

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.aymman.notificationvault.R
import com.aymman.notificationvault.ui.common.CaptureState
import com.aymman.notificationvault.ui.common.CaptureStatusCard
import com.aymman.notificationvault.ui.common.SelectionState
import com.aymman.notificationvault.ui.onboarding.OnboardingScreen
import com.aymman.notificationvault.ui.theme.NotificationVaultTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UiTest {

    @get:Rule
    val compose = createComposeRule()

    private fun str(id: Int) = InstrumentationRegistry.getInstrumentation().targetContext.getString(id)

    @Test
    fun onboarding_walksThroughPagesAndFinishesWhenAccessGranted() {
        var finished = false
        compose.setContent {
            NotificationVaultTheme { OnboardingScreen(isAccessGranted = { true }, onFinish = { finished = true }) }
        }
        compose.onNodeWithText(str(R.string.onb_welcome_title)).assertIsDisplayed()
        compose.onNodeWithText(str(R.string.action_get_started)).performClick()
        compose.onNodeWithText(str(R.string.onb_how_title)).assertIsDisplayed()
        compose.onNodeWithText(str(R.string.action_skip)).performClick()
        compose.waitForIdle()
        compose.onNodeWithText(str(R.string.onb_access_granted)).assertIsDisplayed()
        compose.onNodeWithText(str(R.string.onb_finish)).performClick()
        assertTrue(finished)
    }

    @Test
    fun onboarding_withoutAccessOffersLater() {
        var finished = false
        compose.setContent {
            NotificationVaultTheme { OnboardingScreen(isAccessGranted = { false }, onFinish = { finished = true }) }
        }
        compose.onNodeWithText(str(R.string.action_skip)).performClick()
        compose.waitForIdle()
        compose.onNodeWithText(str(R.string.onb_access_title)).assertIsDisplayed()
        compose.onNodeWithText(str(R.string.onb_later)).performClick()
        assertTrue(finished)
    }

    @Test
    fun statusCard_showsFixActionWhenAccessMissing() {
        var opened = 0
        compose.setContent {
            NotificationVaultTheme { CaptureStatusCard(CaptureState.NO_ACCESS, onOpenAccess = { opened++ }, onResume = {}) }
        }
        compose.onNodeWithText(str(R.string.status_off)).assertIsDisplayed()
        compose.onNodeWithText(str(R.string.capture_open_access)).performClick()
        assertEquals(1, opened)
    }

    @Test
    fun statusCard_pausedOffersResume() {
        var resumed = false
        compose.setContent {
            NotificationVaultTheme { CaptureStatusCard(CaptureState.PAUSED, onOpenAccess = {}, onResume = { resumed = true }) }
        }
        compose.onNodeWithText(str(R.string.action_resume)).performClick()
        assertTrue(resumed)
    }

    @Test
    fun selectionState_toggleRetainClear() {
        val s = SelectionState()
        assertFalse(s.active)
        s.toggle(1); s.toggle(2); s.toggle(1)
        assertEquals(setOf(2L), s.selected)
        s.set(listOf(2L, 3L, 4L))
        s.retain(setOf(3L, 4L))
        assertEquals(setOf(3L, 4L), s.selected)
        s.clear()
        assertFalse(s.active)
    }
}

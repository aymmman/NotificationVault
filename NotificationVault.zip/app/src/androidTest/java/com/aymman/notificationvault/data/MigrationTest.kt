package com.aymman.notificationvault.data

import androidx.room.testing.MigrationTestHelper
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.aymman.notificationvault.data.db.AppDatabase
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Validates the exported schema (app/schemas). When a new version is added, extend this test with
 * helper.runMigrationsAndValidate(DB, newVersion, true, *AppDatabase.MIGRATIONS).
 */
@RunWith(AndroidJUnit4::class)
class MigrationTest {

    @get:Rule
    val helper = MigrationTestHelper(InstrumentationRegistry.getInstrumentation(), AppDatabase::class.java)

    @Test
    fun version1SchemaCreatesAndAcceptsRows() {
        helper.createDatabase(DB, 1).use { db ->
            db.execSQL("INSERT INTO apps (packageName, appLabel, firstSeenAt, lastSeenAt) VALUES ('p', 'P', 1, 1)")
            db.execSQL(
                "INSERT INTO notifications (dedupKey, packageName, notificationKey, kind, receivedAt, originalTimestamp) " +
                    "VALUES ('k', 'p', 'n', 'OTHER', 1, 1)",
            )
            db.query("SELECT isRead, isPinned FROM notifications").use { c ->
                c.moveToFirst()
                assertEquals(0, c.getInt(0))
                assertEquals(0, c.getInt(1))
            }
        }
    }

    private companion object {
        const val DB = "migration-test"
    }
}

package com.aymman.notificationvault.ui.chat

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.domain.model.SortOrder
import com.aymman.notificationvault.ui.common.AppIcon
import com.aymman.notificationvault.ui.common.BackTopBar
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.Formatters
import com.aymman.notificationvault.ui.common.SectionHeader
import com.aymman.notificationvault.ui.common.body
import com.aymman.notificationvault.ui.common.dayHeader
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    repository: VaultRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    val packageName: String = checkNotNull(savedState.get<String>("pkg"))
    val conversationId: String = checkNotNull(savedState.get<String>("conv"))
    val deletedOnly = MutableStateFlow(false)

    private val all = repository.observeRows(
        SearchFilters(packageName = packageName, conversationId = conversationId, sort = SortOrder.OLDEST),
        limit = 5_000,
    )

    val messages: StateFlow<List<NotificationRow>?> = combine(all, deletedOnly) { rows, onlyDeleted ->
        if (onlyDeleted) rows.filter { it.n.deletedAt != null } else rows
    }.map<List<NotificationRow>, List<NotificationRow>?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

/**
 * The archived messages of one conversation shown as chat bubbles, oldest at the top.
 * Deleted messages are highlighted; tapping a bubble opens its full record.
 */
@Composable
fun ChatScreen(onBack: () -> Unit, onOpenDetail: (Long) -> Unit, vm: ChatViewModel = hiltViewModel()) {
    val rows by vm.messages.collectAsStateWithLifecycle()
    val onlyDeleted by vm.deletedOnly.collectAsStateWithLifecycle()
    val list = rows
    val title = list?.lastOrNull()?.let { it.n.conversationTitle ?: it.n.senderName } ?: vm.conversationId
    val listState = rememberLazyListState()
    LaunchedEffect(list?.size) {
        if (!list.isNullOrEmpty()) listState.scrollToItem(list.size - 1 + list.groupBy { Formatters.localDate(it.n.receivedAt) }.size)
    }

    Scaffold(topBar = { BackTopBar(title, onBack) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(vm.packageName, list?.firstOrNull()?.appLabel, size = 24.dp)
                Spacer(Modifier.size(8.dp))
                Text(
                    stringResource(R.string.chat_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                FilterChip(
                    selected = onlyDeleted,
                    onClick = { vm.deletedOnly.value = !onlyDeleted },
                    label = { Text("🗑️ " + stringResource(R.string.filter_deleted)) },
                )
            }
            when {
                list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                list.isEmpty() -> EmptyState(stringResource(R.string.inbox_empty_title), stringResource(R.string.inbox_empty_body))
                else -> LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    val groupConversation = list.mapNotNull { it.n.senderName }.distinct().size > 1
                    list.groupBy { Formatters.localDate(it.n.receivedAt) }.forEach { (day, dayRows) ->
                        item(key = "d_$day") {
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { SectionHeader(dayHeader(day)) }
                        }
                        items(dayRows, key = { it.n.id }) { row ->
                            Bubble(row, showSender = groupConversation, onClick = { onOpenDetail(row.n.id) })
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(row: NotificationRow, showSender: Boolean, onClick: () -> Unit) {
    val deleted = row.n.deletedAt != null
    val bg = if (deleted) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceContainerHigh
    val fg = if (deleted) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurface
    Box(Modifier.fillMaxWidth()) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .background(bg, RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 18.dp))
                .combinedClickable(onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            if (showSender && row.n.senderName != null) {
                Text(
                    row.n.senderName,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (row.attachmentCount > 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Image, null, tint = fg, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.size(4.dp))
                    Text(stringResource(R.string.chat_has_media, row.attachmentCount), style = MaterialTheme.typography.labelSmall, color = fg)
                }
            }
            Text(row.body(), style = MaterialTheme.typography.bodyLarge, color = fg)
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (deleted) {
                    Text(
                        "🗑️ " + stringResource(R.string.label_deleted_by_sender) + "  ",
                        style = MaterialTheme.typography.labelSmall,
                        color = fg,
                    )
                }
                Text(
                    Formatters.time(row.n.originalTimestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = fg.copy(alpha = 0.7f),
                )
            }
        }
    }
}

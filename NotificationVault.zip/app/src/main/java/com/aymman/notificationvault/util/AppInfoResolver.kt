package com.aymman.notificationvault.util

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.util.concurrent.ConcurrentHashMap

/**
 * Resolves app names and icons through PackageManager. Results are cached in memory only.
 * Icons may be unavailable (uninstalled apps, package-visibility limits) — callers show a fallback.
 */
class AppInfoResolver(private val context: Context) {

    private val labels = ConcurrentHashMap<String, String>()
    private val icons = object : LruCache<String, ImageBitmap>(ICON_CACHE_BYTES) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }
    private val missingIcons = ConcurrentHashMap.newKeySet<String>()

    fun label(packageName: String): String = labels.getOrPut(packageName) {
        try {
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(info).toString().ifBlank { packageName }
        } catch (e: PackageManager.NameNotFoundException) {
            packageName
        } catch (e: RuntimeException) {
            packageName
        }
    }

    /** Blocking — call from a background dispatcher. */
    fun icon(packageName: String, sizePx: Int): ImageBitmap? {
        icons.get(packageName)?.let { return it }
        if (packageName in missingIcons) return null
        return try {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bmp = drawable.toBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).asImageBitmap()
            icons.put(packageName, bmp)
            bmp
        } catch (e: PackageManager.NameNotFoundException) {
            missingIcons.add(packageName); null
        } catch (e: RuntimeException) {
            missingIcons.add(packageName); null
        }
    }

    fun isInstalled(packageName: String): Boolean = try {
        context.packageManager.getPackageInfo(packageName, 0); true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    fun launchIntent(packageName: String) = context.packageManager.getLaunchIntentForPackage(packageName)

    companion object {
        private const val ICON_CACHE_BYTES = 8 * 1024 * 1024
    }
}

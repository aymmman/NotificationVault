package com.aymman.notificationvault.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.LabelCount
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.StatsCalculator
import com.aymman.notificationvault.ui.common.BackTopBar
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.SectionHeader
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import javax.inject.Inject

data class StatsState(
    val days: Int,
    val total: Int,
    val deleted: Int,
    val perDay: List<Pair<LocalDate, Int>>,
    val perHour: IntArray,
    val peakHour: Int,
    val topApps: List<LabelCount>,
    val topSenders: List<LabelCount>,
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class StatsViewModel @Inject constructor(private val repository: VaultRepository) : ViewModel() {
    val range = MutableStateFlow(7)

    val state: StateFlow<StatsState?> = range.flatMapLatest { days ->
        flow<StatsState?> {
            emit(null)
            val since = LocalDate.now().minusDays((days - 1).toLong()).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val ts = repository.timestampsSince(since)
            val byHour = StatsCalculator.byHour(ts)
            emit(
                StatsState(
                    days = days,
                    total = ts.size,
                    deleted = repository.countDeletedSince(since),
                    perDay = StatsCalculator.byDay(ts, days),
                    perHour = byHour,
                    peakHour = StatsCalculator.peakHour(byHour),
                    topApps = repository.topApps(since, 8),
                    topSenders = repository.topSenders(since, 8),
                ),
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(onBack: () -> Unit, vm: StatsViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val range by vm.range.collectAsStateWithLifecycle()

    Scaffold(topBar = { BackTopBar(stringResource(R.string.stats_title), onBack) }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        ) {
            val ranges = listOf(7 to R.string.stats_7d, 30 to R.string.stats_30d, 90 to R.string.stats_90d)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                ranges.forEachIndexed { i, (d, label) ->
                    SegmentedButton(
                        selected = range == d,
                        onClick = { vm.range.value = d },
                        shape = SegmentedButtonDefaults.itemShape(index = i, count = ranges.size),
                    ) { Text(stringResource(label)) }
                }
            }
            val s = state
            when {
                s == null -> Box(Modifier.fillMaxWidth().padding(48.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                s.total == 0 -> EmptyState(stringResource(R.string.stats_empty_title), stringResource(R.string.stats_empty_body))
                else -> StatsContent(s)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun StatsContent(s: StatsState) {
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        NumberTile("%,d".format(s.total), stringResource(R.string.stats_total), Modifier.weight(1f))
        NumberTile("%,d".format(s.total / s.days), stringResource(R.string.stats_per_day), Modifier.weight(1f))
        NumberTile("%,d".format(s.deleted), stringResource(R.string.stats_deleted), Modifier.weight(1f))
    }

    SectionHeader(stringResource(R.string.stats_by_day))
    val fmt = if (s.days <= 7) DateTimeFormatter.ofPattern("EEE") else DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)
    BarChart(
        values = s.perDay.map { it.second },
        labels = s.perDay.mapIndexed { i, (d, _) ->
            val step = (s.perDay.size / 6).coerceAtLeast(1)
            if (i % step == 0 || i == s.perDay.lastIndex) fmt.format(d) else ""
        },
    )

    SectionHeader(stringResource(R.string.stats_by_hour))
    BarChart(
        values = s.perHour.toList(),
        labels = (0..23).map { h -> if (h % 6 == 0) "%02d".format(h) else "" },
        highlight = s.peakHour,
    )
    if (s.peakHour >= 0) {
        Text(
            stringResource(R.string.stats_peak, "%02d:00".format(s.peakHour)),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    SectionHeader(stringResource(R.string.stats_top_apps))
    HorizontalBars(s.topApps)

    if (s.topSenders.isNotEmpty()) {
        SectionHeader(stringResource(R.string.stats_top_senders))
        HorizontalBars(s.topSenders)
    }
}

@Composable
private fun NumberTile(value: String, label: String, modifier: Modifier) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest, shape = MaterialTheme.shapes.large, modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Simple vertical bar chart drawn with Canvas (no chart library, nothing leaves the device). */
@Composable
private fun BarChart(values: List<Int>, labels: List<String>, highlight: Int = -1) {
    val barColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
    val peakColor = MaterialTheme.colorScheme.primary
    val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                if (values.isEmpty()) return@Canvas
                val slot = size.width / values.size
                val barW = (slot * 0.68f).coerceAtLeast(2f)
                values.forEachIndexed { i, v ->
                    val h = size.height * v / max
                    drawRoundRect(
                        color = if (i == highlight) peakColor else barColor,
                        topLeft = Offset(i * slot + (slot - barW) / 2, size.height - h),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 3, barW / 3),
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                labels.forEach { l ->
                    Text(
                        l,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Visible,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun HorizontalBars(items: List<LabelCount>) {
    val max = (items.maxOfOrNull { it.count } ?: 0).coerceAtLeast(1)
    Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items.forEach { item ->
                Column {
                    Row {
                        Text(item.label, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text("%,d".format(item.count), style = MaterialTheme.typography.labelLarge)
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier.fillMaxWidth().height(8.dp).clip(MaterialTheme.shapes.small)
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                    ) {
                        Box(
                            Modifier.fillMaxWidth(item.count.toFloat() / max).fillMaxHeight().clip(MaterialTheme.shapes.small)
                                .background(MaterialTheme.colorScheme.primary),
                        )
                    }
                }
            }
        }
    }
}

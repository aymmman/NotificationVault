package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.model.NotificationKind

/** Maps a notification to a quick-filter bucket using its category first, then known package names. */
object KindClassifier {

    private val messaging = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.telegram.messenger.web",
        "org.thoughtcrime.securesms", "com.facebook.orca", "com.facebook.mlite", "com.viber.voip",
        "jp.naver.line.android", "com.tencent.mm", "com.google.android.apps.messaging",
        "com.samsung.android.messaging", "com.android.mms", "com.skype.raider", "com.discord",
        "com.imo.android.imoim", "com.microsoft.teams", "com.Slack", "com.google.android.apps.dynamite",
        "com.botim.android", "im.vector.app",
    )
    private val social = setOf(
        "com.instagram.android", "com.facebook.katana", "com.facebook.lite", "com.twitter.android",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.snapchat.android",
        "com.linkedin.android", "com.reddit.frontpage", "com.pinterest", "com.instagram.barcelona",
        "com.google.android.youtube", "com.bereal.ft",
    )
    private val email = setOf(
        "com.google.android.gm", "com.microsoft.office.outlook", "com.yahoo.mobile.client.android.mail",
        "com.samsung.android.email.provider", "ch.protonmail.android", "com.readdle.spark",
        "me.bluemail.mail", "com.fsck.k9", "com.google.android.gm.lite",
    )
    private val calls = setOf(
        "com.google.android.dialer", "com.samsung.android.dialer", "com.android.dialer",
        "com.android.server.telecom", "com.android.incallui", "com.truecaller",
    )

    fun classify(packageName: String, category: String?, hasMessages: Boolean): NotificationKind {
        when (category) {
            "msg" -> return NotificationKind.MESSAGE
            "email" -> return NotificationKind.EMAIL
            "call", "missed_call" -> return NotificationKind.CALL
            "social" -> return NotificationKind.SOCIAL
        }
        return when {
            packageName in calls -> NotificationKind.CALL
            hasMessages || packageName in messaging -> NotificationKind.MESSAGE
            packageName in email -> NotificationKind.EMAIL
            packageName in social -> NotificationKind.SOCIAL
            else -> NotificationKind.OTHER
        }
    }
}

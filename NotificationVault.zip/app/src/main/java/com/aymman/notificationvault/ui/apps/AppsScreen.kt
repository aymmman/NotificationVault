package com.aymman.notificationvault.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.NotificationsOff
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.AppSummary
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.ui.common.AppIcon
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.Formatters
import com.aymman.notificationvault.ui.common.Pill
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class AppSort { RECENT, NAME, COUNT }

@HiltViewModel
class AppsViewModel @Inject constructor(private val repository: VaultRepository) : ViewModel() {
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(AppSort.RECENT)

    val apps: StateFlow<List<AppSummary>?> = combine(repository.observeAppSummaries(), query, sort) { list, q, s ->
        val filtered = if (q.isBlank()) list else list.filter {
            it.appLabel.contains(q.trim(), ignoreCase = true) || it.packageName.contains(q.trim(), ignoreCase = true)
        }
        val sorted = when (s) {
            AppSort.RECENT -> filtered.sortedByDescending { it.lastAt ?: 0L }
            AppSort.NAME -> filtered.sortedBy { it.appLabel.lowercase() }
            AppSort.COUNT -> filtered.sortedByDescending { it.total }
        }
        // Favorites always first, keeping the chosen order within each group.
        sorted.sortedByDescending { it.favorite }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setFavorite(pkg: String, v: Boolean) = viewModelScope.launch { repository.setAppFavorite(pkg, v) }
    fun setMuted(pkg: String, v: Boolean) = viewModelScope.launch { repository.setAppMuted(pkg, v) }
    fun setCapture(pkg: String, v: Boolean) = viewModelScope.launch { repository.setAppCaptureEnabled(pkg, v) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(onOpenApp: (String) -> Unit, vm: AppsViewModel = hiltViewModel()) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.apps_title)) },
                actions = { AppSortMenu(sort) { vm.sort.value = it } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { vm.query.value = it },
                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                placeholder = { Text(stringResource(R.string.apps_search_hint)) },
                singleLine = true,
                shape = CircleShape,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            )
            val list = apps
            when {
                list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                list.isEmpty() -> EmptyState(
                    stringResource(R.string.apps_empty_title),
                    stringResource(R.string.apps_empty_body),
                    icon = Icons.Outlined.Apps,
                )
                else -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp)) {
                    items(list, key = { it.packageName }) { app ->
                        AppRow(
                            app = app,
                            onClick = { onOpenApp(app.packageName) },
                            onFavorite = { vm.setFavorite(app.packageName, !app.favorite) },
                            onMute = { vm.setMuted(app.packageName, !app.muted) },
                            onCapture = { vm.setCapture(app.packageName, !app.captureEnabled) },
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun AppRow(app: AppSummary, onClick: () -> Unit, onFavorite: () -> Unit, onMute: () -> Unit, onCapture: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app.packageName, app.appLabel, size = 46.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        app.appLabel,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (app.favorite) {
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Filled.Star, null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(16.dp))
                    }
                    if (app.muted) {
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Outlined.VisibilityOff, stringResource(R.string.label_muted), tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                    }
                    if (!app.captureEnabled) {
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Outlined.NotificationsOff, stringResource(R.string.label_not_capturing), tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                    }
                }
                app.preview?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pill(stringResource(R.string.apps_count, app.total))
                    app.lastAt?.let {
                        Spacer(Modifier.width(8.dp))
                        Text(Formatters.relative(it).toString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (app.unread > 0) {
                Box(
                    Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.primary).padding(horizontal = 8.dp, vertical = 2.dp),
                ) {
                    Text(
                        if (app.unread > 999) "999+" else app.unread.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, stringResource(R.string.action_more)) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(if (app.favorite) R.string.app_unfavorite else R.string.app_favorite)) },
                        onClick = { menu = false; onFavorite() },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(if (app.muted) R.string.app_unmute else R.string.app_mute)) },
                        onClick = { menu = false; onMute() },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(if (app.captureEnabled) R.string.app_capture_off else R.string.app_capture_on)) },
                        onClick = { menu = false; onCapture() },
                    )
                }
            }
        }
    }
}

@Composable
private fun AppSortMenu(current: AppSort, onSelect: (AppSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.AutoMirrored.Filled.Sort, stringResource(R.string.action_sort)) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            listOf(
                AppSort.RECENT to R.string.apps_sort_recent,
                AppSort.NAME to R.string.apps_sort_name,
                AppSort.COUNT to R.string.apps_sort_count,
            ).forEach { (s, label) ->
                DropdownMenuItem(
                    text = { Text(stringResource(label)) },
                    leadingIcon = { RadioButton(selected = s == current, onClick = null) },
                    onClick = { open = false; onSelect(s) },
                )
            }
        }
    }
}

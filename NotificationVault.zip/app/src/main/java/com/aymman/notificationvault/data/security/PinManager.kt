package com.aymman.notificationvault.data.security

import android.content.Context
import android.util.Base64
import com.aymman.notificationvault.domain.security.PinPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * The app's own PIN, independent of the phone's screen lock. Only a salted PBKDF2 hash is stored
 * (app-private preferences, excluded from backups). There is deliberately no recovery: a forgotten
 * PIN can only be reset by clearing the app's data, which also erases the archive.
 */
class PinManager(context: Context) {

    private val prefs = context.getSharedPreferences("nv_pin", Context.MODE_PRIVATE)

    data class State(val enabled: Boolean, val biometric: Boolean)

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<State> = _state.asStateFlow()

    sealed interface VerifyResult {
        data object Ok : VerifyResult
        data class Wrong(val attemptsBeforeLockout: Int) : VerifyResult
        data class LockedOut(val untilMillis: Long) : VerifyResult
    }

    val isEnabled: Boolean get() = _state.value.enabled

    /** Wall-clock time until which entry is blocked, or 0. */
    fun lockedUntil(): Long = prefs.getLong(K_LOCK_UNTIL, 0L).takeIf { it > System.currentTimeMillis() } ?: 0L

    suspend fun setPin(pin: String) = withContext(Dispatchers.Default) {
        require(PinPolicy.isValidFormat(pin))
        val salt = PinPolicy.newSalt()
        val hash = PinPolicy.hash(pin, salt)
        prefs.edit()
            .putString(K_SALT, b64(salt))
            .putString(K_HASH, b64(hash))
            .putInt(K_FAILS, 0)
            .putLong(K_LOCK_UNTIL, 0L)
            .apply()
        _state.value = readState()
    }

    suspend fun verify(pin: String): VerifyResult = withContext(Dispatchers.Default) {
        val now = System.currentTimeMillis()
        val until = prefs.getLong(K_LOCK_UNTIL, 0L)
        if (until > now) return@withContext VerifyResult.LockedOut(until)
        val salt = prefs.getString(K_SALT, null)?.let { unb64(it) }
        val hash = prefs.getString(K_HASH, null)?.let { unb64(it) }
        if (salt == null || hash == null) return@withContext VerifyResult.Ok
        if (PinPolicy.matches(pin, salt, hash)) {
            prefs.edit().putInt(K_FAILS, 0).putLong(K_LOCK_UNTIL, 0L).apply()
            VerifyResult.Ok
        } else {
            val fails = prefs.getInt(K_FAILS, 0) + 1
            val lock = PinPolicy.lockoutMs(fails)
            prefs.edit().putInt(K_FAILS, fails).putLong(K_LOCK_UNTIL, if (lock > 0) now + lock else 0L).apply()
            if (lock > 0) VerifyResult.LockedOut(now + lock) else VerifyResult.Wrong(PinPolicy.FREE_ATTEMPTS - fails)
        }
    }

    fun disable() {
        prefs.edit().clear().apply()
        _state.value = readState()
    }

    fun setBiometric(enabled: Boolean) {
        prefs.edit().putBoolean(K_BIO, enabled).apply()
        _state.value = readState()
    }

    private fun readState() = State(
        enabled = prefs.getString(K_HASH, null) != null,
        biometric = prefs.getBoolean(K_BIO, false),
    )

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    private companion object {
        const val K_SALT = "salt"
        const val K_HASH = "hash"
        const val K_FAILS = "fails"
        const val K_LOCK_UNTIL = "lock_until"
        const val K_BIO = "biometric"
    }
}

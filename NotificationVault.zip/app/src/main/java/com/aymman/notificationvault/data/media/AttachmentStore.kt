package com.aymman.notificationvault.data.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Saves images as AES-256-GCM encrypted files in app-private storage (files/attachments).
 * The key lives in the Android Keystore and is never exported. File layout: iv (12 bytes) | ciphertext+tag.
 */
class AttachmentStore(context: Context) {

    private val dir = File(context.filesDir, "attachments").apply { mkdirs() }

    data class Saved(val fileName: String, val mimeType: String, val width: Int, val height: Int, val sizeBytes: Long)

    /** Encrypts and saves image bytes. Returns null when the data isn't a decodable image or is too large. */
    fun saveImage(bytes: ByteArray, mimeHint: String?): Saved? {
        if (bytes.isEmpty() || bytes.size > MAX_BYTES) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val mime = bounds.outMimeType ?: mimeHint ?: "image/jpeg"
        val name = UUID.randomUUID().toString() + ".enc"
        File(dir, name).writeBytes(encrypt(bytes))
        return Saved(name, mime, bounds.outWidth, bounds.outHeight, bytes.size.toLong())
    }

    /** Compresses a bitmap (scaled down to [MAX_DIMENSION]) and saves it. */
    fun saveBitmap(bitmap: Bitmap): Saved? {
        if (bitmap.width <= 0 || bitmap.height <= 0) return null
        val scale = minOf(1f, MAX_DIMENSION.toFloat() / maxOf(bitmap.width, bitmap.height))
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
        } else bitmap
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
        return saveImage(out.toByteArray(), "image/jpeg")
    }

    /** Decrypts a saved file. */
    fun load(fileName: String): ByteArray? {
        val f = File(dir, safeName(fileName))
        if (!f.exists()) return null
        return try {
            decrypt(f.readBytes())
        } catch (e: Exception) {
            null
        }
    }

    /** Decodes a saved image, sampled down so its longest side is about [maxPx]. */
    fun loadBitmap(fileName: String, maxPx: Int): Bitmap? {
        val bytes = load(fileName) ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxPx) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    fun delete(fileName: String) {
        File(dir, safeName(fileName)).delete()
    }

    /** Deletes files that no longer belong to any database row (e.g. after records were deleted). */
    fun sweep(valid: Collection<String>): Int {
        val keep = valid.toHashSet()
        var removed = 0
        dir.listFiles()?.forEach { f ->
            if (f.name !in keep && f.delete()) removed++
        }
        return removed
    }

    fun totalBytesOnDisk(): Long = dir.listFiles()?.sumOf { it.length() } ?: 0L

    private fun safeName(name: String) = File(name).name

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        return c.iv + c.doFinal(plain)
    }

    private fun decrypt(data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, data, 0, 12))
        return c.doFinal(data, 12, data.size - 12)
    }

    companion object {
        private const val ALIAS = "notification_vault_media_key"
        const val MAX_BYTES = 25 * 1024 * 1024
        const val MAX_DIMENSION = 2048
    }
}

package com.aymman.notificationvault.domain.model

/** High-level bucket used by the dashboard quick filters. Stored as its [name] in the database. */
enum class NotificationKind { MESSAGE, SOCIAL, EMAIL, CALL, OTHER }

/** One message extracted from a MessagingStyle notification. */
data class RawMessage(
    val text: String?,
    val timestamp: Long,
    val senderName: String?,
    /** The message carries an image (MessagingStyle data URI with an image MIME type). */
    val hasImage: Boolean = false,
)

/**
 * Plain-Kotlin snapshot of the safe, textual parts of a StatusBarNotification.
 * Built on the Android side by NotificationExtractor; everything after that is pure and unit-testable.
 * No raw Notification objects, PendingIntents, bitmaps or Bundles are kept.
 */
data class RawNotification(
    val packageName: String,
    val key: String,
    val postTime: Long,
    val whenTime: Long = 0L,
    val title: String? = null,
    val text: String? = null,
    val bigText: String? = null,
    val subText: String? = null,
    val textLines: List<String> = emptyList(),
    val conversationTitle: String? = null,
    val isGroupConversation: Boolean = false,
    val shortcutId: String? = null,
    val category: String? = null,
    val isGroupSummary: Boolean = false,
    val isOngoing: Boolean = false,
    val hasProgress: Boolean = false,
    val messages: List<RawMessage> = emptyList(),
)

/** A record ready to be written to the archive. */
data class CapturedRecord(
    val dedupKey: String,
    val packageName: String,
    val notificationKey: String,
    val title: String?,
    val text: String?,
    val bigText: String?,
    val subText: String?,
    val senderName: String?,
    val conversationId: String?,
    val conversationTitle: String?,
    val category: String?,
    val kind: NotificationKind,
    val originalTimestamp: Long,
    val isFromMessagingStyle: Boolean,
    /** Index into RawNotification.messages this record came from (null for non-message records). */
    val messageIndex: Int? = null,
)

/** Settings that influence what the parser and filters accept. */
data class CaptureOptions(
    val skipOngoing: Boolean = true,
    val skipGroupSummaries: Boolean = true,
    val filterSystemNoise: Boolean = true,
    val excludedKeywords: List<String> = emptyList(),
)

enum class SortOrder { NEWEST, OLDEST, APP, SENDER }

enum class ReadFilter { ALL, UNREAD, READ }

data class SearchFilters(
    val query: String = "",
    val packageName: String? = null,
    val kind: NotificationKind? = null,
    val category: String? = null,
    val userCategory: String? = null,
    val fromMillis: Long? = null,
    val toMillis: Long? = null,
    val read: ReadFilter = ReadFilter.ALL,
    val pinnedOnly: Boolean = false,
    val bookmarkedOnly: Boolean = false,
    val sender: String? = null,
    val conversationId: String? = null,
    val sort: SortOrder = SortOrder.NEWEST,
)

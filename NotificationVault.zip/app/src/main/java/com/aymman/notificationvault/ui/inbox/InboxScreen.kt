package com.aymman.notificationvault.ui.inbox

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.domain.model.NotificationKind
import com.aymman.notificationvault.domain.model.ReadFilter
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.domain.model.SortOrder
import com.aymman.notificationvault.ui.common.ArchiveList
import com.aymman.notificationvault.ui.common.BaseArchiveViewModel
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.KindChips
import com.aymman.notificationvault.ui.common.SelectionActions
import com.aymman.notificationvault.ui.common.SelectionTopBar
import com.aymman.notificationvault.ui.common.rememberSelection
import com.aymman.notificationvault.ui.common.resolve
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class InboxViewModel @Inject constructor(
    repository: VaultRepository,
    backupManager: BackupManager,
    settings: SettingsRepository,
    savedState: SavedStateHandle,
) : BaseArchiveViewModel(repository, backupManager) {

    val groupSimilar: StateFlow<Boolean> = settings.settings.map { it.groupSimilar }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    private val _filters = MutableStateFlow(
        SearchFilters(
            kind = savedState.get<String>("kind")?.let { k -> NotificationKind.entries.firstOrNull { it.name == k } },
            read = if (savedState.get<Boolean>("unread") == true) ReadFilter.UNREAD else ReadFilter.ALL,
            deletedOnly = savedState.get<Boolean>("deleted") == true,
        ),
    )
    val filters: StateFlow<SearchFilters> = _filters.asStateFlow()

    val rows: StateFlow<List<NotificationRow>?> = _filters
        .flatMapLatest { repository.observeRows(it, hideMuted = true) }
        .map<List<NotificationRow>, List<NotificationRow>?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setKind(kind: NotificationKind?) = _filters.update { it.copy(kind = kind) }
    fun setUnreadOnly(v: Boolean) = _filters.update { it.copy(read = if (v) ReadFilter.UNREAD else ReadFilter.ALL) }
    fun setSort(sort: SortOrder) = _filters.update { it.copy(sort = sort) }
    fun setDeletedOnly(v: Boolean) = _filters.update { it.copy(deletedOnly = v) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    onOpenDetail: (Long) -> Unit,
    onOpenSearch: () -> Unit,
    vm: InboxViewModel = hiltViewModel(),
) {
    val rows by vm.rows.collectAsStateWithLifecycle()
    val filters by vm.filters.collectAsStateWithLifecycle()
    val groupSimilar by vm.groupSimilar.collectAsStateWithLifecycle()
    val selection = rememberSelection()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it.resolve(context)) } }
    LaunchedEffect(rows) { rows?.let { list -> selection.retain(list.map { it.n.id }.toSet()) } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selection.active) {
                SelectionTopBar(selection.selected.size, onClear = selection::clear) {
                    SelectionActions(rows.orEmpty(), selection, vm)
                }
            } else {
                TopAppBar(
                    title = { Text(stringResource(R.string.inbox_title)) },
                    actions = {
                        IconButton(onClick = onOpenSearch) { Icon(Icons.Outlined.Search, stringResource(R.string.action_search)) }
                        SortMenu(filters.sort, vm::setSort)
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(
                    selected = filters.read == ReadFilter.UNREAD,
                    onClick = { vm.setUnreadOnly(filters.read != ReadFilter.UNREAD) },
                    label = { Text(stringResource(R.string.filter_unread_only)) },
                )
                Spacer(Modifier.width(8.dp))
                FilterChip(
                    selected = filters.deletedOnly,
                    onClick = { vm.setDeletedOnly(!filters.deletedOnly) },
                    label = { Text("🗑️ " + stringResource(R.string.filter_deleted)) },
                )
            }
            KindChips(
                selected = filters.kind,
                onSelect = vm::setKind,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            )
            val list = rows
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                ArchiveList(
                    rows = list,
                    selection = selection,
                    showApp = true,
                    byDay = filters.sort == SortOrder.NEWEST || filters.sort == SortOrder.OLDEST,
                    groupSimilar = groupSimilar && !filters.deletedOnly,
                    onOpen = onOpenDetail,
                    empty = {
                        EmptyState(stringResource(R.string.inbox_empty_title), stringResource(R.string.inbox_empty_body))
                    },
                )
            }
        }
    }
}

@Composable
fun SortMenu(current: SortOrder, onSelect: (SortOrder) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = stringResource(R.string.action_sort))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            listOf(
                SortOrder.NEWEST to R.string.sort_newest,
                SortOrder.OLDEST to R.string.sort_oldest,
                SortOrder.APP to R.string.sort_app,
                SortOrder.SENDER to R.string.sort_sender,
            ).forEach { (order, label) ->
                DropdownMenuItem(
                    text = { Text(stringResource(label)) },
                    leadingIcon = { RadioButton(selected = order == current, onClick = null) },
                    onClick = { open = false; onSelect(order) },
                )
            }
        }
    }
}

package com.aymman.notificationvault.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Process-wide view of the listener's health, used for the status indicator and diagnostics. */
class ListenerStatus(private val context: Context) {

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val _lastCaptureAt = MutableStateFlow<Long?>(null)
    val lastCaptureAt: StateFlow<Long?> = _lastCaptureAt.asStateFlow()

    fun setConnected(value: Boolean) {
        _connected.value = value
    }

    fun onCaptured() {
        _lastCaptureAt.value = System.currentTimeMillis()
    }

    /** True when the user has granted Notification Access to this app in system settings. */
    fun isAccessGranted(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    companion object {
        /** Opens the most specific Notification Access screen the device supports. */
        fun openAccessSettings(context: Context) {
            val candidates = buildList {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    add(
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                            Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                            VaultListenerService.componentName(context).flattenToString(),
                        ),
                    )
                }
                add(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                add(Intent(Settings.ACTION_SETTINGS))
            }
            startFirst(context, candidates)
        }

        fun openBatterySettings(context: Context) =
            startFirst(context, listOf(batterySettingsIntent(), appDetailsIntent(context)))

        fun openAppDetails(context: Context) = startFirst(context, listOf(appDetailsIntent(context)))

        private fun startFirst(context: Context, intents: List<Intent>) {
            for (intent in intents) {
                try {
                    if (context !is android.app.Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return
                } catch (e: android.content.ActivityNotFoundException) {
                    // try next
                } catch (e: SecurityException) {
                    // try next
                }
            }
        }

        fun batterySettingsIntent(): Intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

        fun appDetailsIntent(context: Context): Intent =
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", context.packageName, null))
    }
}

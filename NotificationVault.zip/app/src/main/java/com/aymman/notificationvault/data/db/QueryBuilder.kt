package com.aymman.notificationvault.data.db

import androidx.sqlite.db.SimpleSQLiteQuery
import com.aymman.notificationvault.domain.model.ReadFilter
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.domain.model.SortOrder

/**
 * Builds parameterised SQL for the list and search screens. User text is only ever bound as an
 * argument (never concatenated), and LIKE wildcards in the query are escaped.
 */
object QueryBuilder {

    const val DEFAULT_LIMIT = 1500

    data class Built(val sql: String, val args: List<Any>)

    fun build(filters: SearchFilters, hideMuted: Boolean = false, limit: Int = DEFAULT_LIMIT): Built {
        val where = ArrayList<String>()
        val args = ArrayList<Any>()

        val terms = filters.query.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.take(8)
        for (term in terms) {
            val like = "%" + escapeLike(term) + "%"
            where += "(n.title LIKE ? ESCAPE '\\' OR n.text LIKE ? ESCAPE '\\' OR n.bigText LIKE ? ESCAPE '\\' " +
                "OR n.senderName LIKE ? ESCAPE '\\' OR n.conversationTitle LIKE ? ESCAPE '\\' " +
                "OR a.appLabel LIKE ? ESCAPE '\\')"
            repeat(6) { args += like }
        }
        filters.packageName?.let { where += "n.packageName = ?"; args += it }
        filters.kind?.let { where += "n.kind = ?"; args += it.name }
        filters.category?.let { where += "n.category = ?"; args += it }
        filters.userCategory?.let { where += "n.userCategory = ?"; args += it }
        filters.sender?.let { where += "n.senderName = ?"; args += it }
        filters.conversationId?.let { where += "n.conversationId = ?"; args += it }
        filters.fromMillis?.let { where += "n.receivedAt >= ?"; args += it }
        filters.toMillis?.let { where += "n.receivedAt <= ?"; args += it }
        when (filters.read) {
            ReadFilter.UNREAD -> where += "n.isRead = 0"
            ReadFilter.READ -> where += "n.isRead = 1"
            ReadFilter.ALL -> Unit
        }
        if (filters.pinnedOnly && filters.bookmarkedOnly) {
            where += "(n.isPinned = 1 OR n.isBookmarked = 1)"
        } else {
            if (filters.pinnedOnly) where += "n.isPinned = 1"
            if (filters.bookmarkedOnly) where += "n.isBookmarked = 1"
        }
        if (hideMuted) where += "(a.muted IS NULL OR a.muted = 0)"

        val order = when (filters.sort) {
            SortOrder.NEWEST -> "n.receivedAt DESC"
            SortOrder.OLDEST -> "n.receivedAt ASC"
            SortOrder.APP -> "a.appLabel COLLATE NOCASE ASC, n.receivedAt DESC"
            SortOrder.SENDER -> "(n.senderName IS NULL) ASC, n.senderName COLLATE NOCASE ASC, n.receivedAt DESC"
        }

        val sql = buildString {
            append("SELECT n.*, a.appLabel AS appLabel, ")
            append("(SELECT COUNT(*) FROM attachments t WHERE t.notificationId = n.id) AS attachmentCount ")
            append("FROM notifications n ")
            append("LEFT JOIN apps a ON a.packageName = n.packageName")
            if (where.isNotEmpty()) append(" WHERE ").append(where.joinToString(" AND "))
            append(" ORDER BY ").append(order)
            append(" LIMIT ").append(limit.coerceIn(1, 10_000))
        }
        return Built(sql, args)
    }

    fun toQuery(built: Built) = SimpleSQLiteQuery(built.sql, built.args.toTypedArray())

    fun escapeLike(s: String): String =
        s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
}

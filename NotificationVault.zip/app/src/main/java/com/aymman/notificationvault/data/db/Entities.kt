package com.aymman.notificationvault.data.db

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** An app that has posted at least one notification since capture started. */
@Entity(tableName = "apps")
data class MonitoredAppEntity(
    @PrimaryKey val packageName: String,
    val appLabel: String,
    val firstSeenAt: Long,
    val lastSeenAt: Long,
    /** false = new notifications from this app are not captured (exclusion list). */
    @ColumnInfo(defaultValue = "1") val captureEnabled: Boolean = true,
    /** Pinned to the top of the app list. */
    @ColumnInfo(defaultValue = "0") val favorite: Boolean = false,
    /** Still captured, but hidden from the dashboard timeline and "All" feed. */
    @ColumnInfo(defaultValue = "0") val muted: Boolean = false,
    /** Per-app retention override in days (0 = forever). null = use global setting. */
    val retentionDays: Int? = null,
)

/** One archived piece of notification content. */
@Entity(
    tableName = "notifications",
    foreignKeys = [
        ForeignKey(
            entity = MonitoredAppEntity::class,
            parentColumns = ["packageName"],
            childColumns = ["packageName"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["dedupKey"], unique = true),
        Index(value = ["packageName", "receivedAt"]),
        Index(value = ["receivedAt"]),
        Index(value = ["notificationKey"]),
        Index(value = ["kind"]),
        Index(value = ["isRead"]),
        Index(value = ["packageName", "conversationId"]),
    ],
)
data class ArchivedNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dedupKey: String,
    val packageName: String,
    /** StatusBarNotification key, used only to mark the record when the notification is removed. */
    val notificationKey: String,
    val title: String?,
    val text: String?,
    val bigText: String?,
    val subText: String?,
    val senderName: String?,
    val conversationId: String?,
    val conversationTitle: String?,
    val category: String?,
    val kind: String,
    val userCategory: String? = null,
    /** When Notification Vault archived it. */
    val receivedAt: Long,
    /** The time reported by the notification / message itself. */
    val originalTimestamp: Long,
    /** When the notification left the shade (dismissed, cancelled, replaced). Never deletes the record. */
    val removedAt: Long? = null,
    @ColumnInfo(defaultValue = "0") val isRead: Boolean = false,
    @ColumnInfo(defaultValue = "0") val isPinned: Boolean = false,
    @ColumnInfo(defaultValue = "0") val isBookmarked: Boolean = false,
    @ColumnInfo(defaultValue = "0") val isFromMessagingStyle: Boolean = false,
    /** Set when the app later showed its "this message was deleted" notice for this exact message. */
    val deletedAt: Long? = null,
    /** This record IS such a notice (kept for completeness, hidden from normal lists). */
    @ColumnInfo(defaultValue = "0") val isDeletionNotice: Boolean = false,
)

/** Conversations seen in MessagingStyle notifications (only when a stable identifier exists). */
@Entity(
    tableName = "conversations",
    foreignKeys = [
        ForeignKey(
            entity = MonitoredAppEntity::class,
            parentColumns = ["packageName"],
            childColumns = ["packageName"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["packageName", "conversationKey"], unique = true)],
)
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val conversationKey: String,
    val title: String?,
    val lastMessageAt: Long,
)

/** User capture rules (currently keyword exclusions). */
@Entity(tableName = "capture_rules", indices = [Index(value = ["type", "value"], unique = true)])
data class CaptureRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val value: String,
    @ColumnInfo(defaultValue = "1") val enabled: Boolean = true,
    val createdAt: Long,
) {
    companion object {
        const val TYPE_KEYWORD = "KEYWORD"
    }
}

/** Log of exports, backups and restores (metadata only — never content). */
@Entity(tableName = "backup_history")
data class BackupRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val type: String,
    val itemCount: Int,
    val encrypted: Boolean,
    val displayName: String?,
)

/**
 * An image saved with a notification, stored as an encrypted file in app-private storage.
 * [source] is NOTIFICATION (the picture the notification itself carried) or WHATSAPP_FOLDER
 * (copied from the WhatsApp media folder the user granted access to). [originalName] holds the
 * source document id for folder imports so the same file is never imported twice.
 */
@Entity(
    tableName = "attachments",
    foreignKeys = [
        ForeignKey(
            entity = ArchivedNotificationEntity::class,
            parentColumns = ["id"],
            childColumns = ["notificationId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["notificationId"]),
        Index(value = ["source", "originalName"], unique = true),
    ],
)
data class AttachmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val notificationId: Long,
    val mimeType: String,
    val fileName: String,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val source: String,
    val originalName: String?,
    val createdAt: Long,
) {
    companion object {
        const val SOURCE_NOTIFICATION = "NOTIFICATION"
        const val SOURCE_WHATSAPP_FOLDER = "WHATSAPP_FOLDER"
    }
}

/** Row used by list screens: a notification plus its app label and number of saved images. */
data class NotificationRow(
    @Embedded val n: ArchivedNotificationEntity,
    val appLabel: String?,
    val attachmentCount: Int = 0,
)

data class AppSummary(
    val packageName: String,
    val appLabel: String,
    val favorite: Boolean,
    val muted: Boolean,
    val captureEnabled: Boolean,
    val retentionDays: Int?,
    val total: Int,
    val unread: Int,
    val lastAt: Long?,
    val preview: String?,
)

data class ConversationCount(
    val conversationId: String,
    val title: String?,
    val count: Int,
    val lastAt: Long,
)

data class KindCount(val kind: String, val count: Int)

data class LabelCount(val label: String, val count: Int)

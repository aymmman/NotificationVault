package com.aymman.notificationvault.data.media

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import com.aymman.notificationvault.data.db.AttachmentEntity
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.media.PhotoMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Copies received WhatsApp photos from the folder the user granted (Storage Access Framework) into
 * the encrypted vault, and links each one to the WhatsApp "📷 Photo" record that arrived at about the
 * same time. Requires WhatsApp's media auto-download to be on; a photo deleted before it was
 * downloaded can't be recovered.
 */
class WhatsAppImporter(
    private val context: Context,
    private val repository: VaultRepository,
    private val store: AttachmentStore,
    private val settings: SettingsRepository,
) {
    private val lock = Mutex()

    data class Status(val folderReadable: Boolean, val imported: Int)

    suspend fun importRecent(windowMs: Long = TimeUnit.MINUTES.toMillis(30)): Status = lock.withLock {
        withContext(Dispatchers.IO) {
            val treeUri = settings.current().whatsAppFolderUri?.let(Uri::parse) ?: return@withContext Status(false, 0)
            val now = System.currentTimeMillis()
            val since = now - windowMs

            val records = repository.photoMessagesWithoutImage(PACKAGES, since)
            val files = try {
                listImages(treeUri, since - PhotoMatcher.TOLERANCE_MS)
            } catch (e: Exception) {
                Log.w(TAG, "WhatsApp folder not readable: ${e.javaClass.simpleName}")
                return@withContext Status(false, 0)
            }
            if (records.isEmpty() || files.isEmpty()) return@withContext Status(true, 0)

            val already = repository.importedOriginalNames(AttachmentEntity.SOURCE_WHATSAPP_FOLDER)
            val fresh = files.filter { it.id !in already }
            val pairs = PhotoMatcher.match(
                photos = records.map { PhotoMatcher.Photo(it.id, it.originalTimestamp) },
                files = fresh.map { PhotoMatcher.File(it.id, it.lastModified) },
            )
            var imported = 0
            for ((recordId, fileId) in pairs) {
                val f = fresh.first { it.id == fileId }
                val bytes = readBytes(f.uri) ?: continue
                val saved = store.saveImage(bytes, f.mime) ?: continue
                if (repository.addAttachment(recordId, saved, AttachmentEntity.SOURCE_WHATSAPP_FOLDER, f.id)) imported++
            }
            Status(true, imported)
        }
    }

    /** True when the stored folder permission is still valid. */
    fun isFolderAccessible(uriString: String?): Boolean {
        if (uriString == null) return false
        val uri = Uri.parse(uriString)
        return context.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
    }

    private data class Doc(val id: String, val uri: Uri, val name: String, val mime: String, val lastModified: Long, val isDir: Boolean)

    private fun children(tree: Uri, parentDocId: String): List<Doc> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        val out = ArrayList<Doc>()
        context.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                val modified = if (c.isNull(3)) 0L else c.getLong(3)
                out += Doc(
                    id = id,
                    uri = DocumentsContract.buildDocumentUriUsingTree(tree, id),
                    name = name,
                    mime = mime,
                    lastModified = modified,
                    isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                )
            }
        }
        return out
    }

    /**
     * Finds the "WhatsApp Images" directory inside the granted tree (the user may have picked it
     * directly, or a parent such as WhatsApp/Media) and lists received images modified after [since].
     * The "Sent" and "Private" sub-folders are ignored.
     */
    private fun listImages(tree: Uri, since: Long): List<Doc> {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val imagesDirId = findImagesDir(tree, rootId, depth = 0) ?: rootId
        return children(tree, imagesDirId)
            .filter { !it.isDir && it.mime.startsWith("image/") && it.lastModified >= since }
            .sortedBy { it.lastModified }
    }

    private fun findImagesDir(tree: Uri, docId: String, depth: Int): String? {
        if (IMAGE_DIR_NAMES.any { docId.endsWith(it) }) return docId
        if (depth >= 3) return null
        val dirs = children(tree, docId).filter { it.isDir }
        dirs.firstOrNull { it.name in IMAGE_DIR_NAMES }?.let { return it.id }
        for (d in dirs.filter { it.name in WALK_NAMES }) {
            findImagesDir(tree, d.id, depth + 1)?.let { return it }
        }
        return null
    }

    private fun readBytes(uri: Uri): ByteArray? = try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val bytes = input.readBytes()
            if (bytes.size > AttachmentStore.MAX_BYTES) null else bytes
        }
    } catch (e: Exception) {
        null
    }

    companion object {
        private const val TAG = "NV.WhatsApp"
        val PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")
        private val IMAGE_DIR_NAMES = setOf("WhatsApp Images", "WhatsApp Business Images")
        private val WALK_NAMES = setOf("WhatsApp", "WhatsApp Business", "Media", "com.whatsapp", "com.whatsapp.w4b")

        /** Folder to open the system picker at (Android 11+ location of WhatsApp media). */
        val INITIAL_FOLDER: Uri = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            "primary:Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images",
        )
    }
}

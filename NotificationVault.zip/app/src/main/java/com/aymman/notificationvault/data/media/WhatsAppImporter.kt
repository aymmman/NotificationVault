package com.aymman.notificationvault.data.media

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import com.aymman.notificationvault.data.db.AttachmentEntity
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.media.MediaKind
import com.aymman.notificationvault.domain.media.PhotoMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Copies received WhatsApp photos, voice notes and videos from the folder the user granted (Storage
 * Access Framework) into the encrypted vault, and links each file to the WhatsApp "📷 / 🎤 / 🎥" record
 * that arrived at about the same time. Requires WhatsApp's media auto-download; a file deleted before
 * WhatsApp downloaded it can't be saved. Read-only: nothing in the WhatsApp folder is changed.
 */
class WhatsAppImporter(
    private val context: Context,
    private val repository: VaultRepository,
    private val store: AttachmentStore,
    private val settings: SettingsRepository,
) {
    private val lock = Mutex()

    data class Status(val folderReadable: Boolean, val imported: Int)

    suspend fun importRecent(windowMs: Long = TimeUnit.MINUTES.toMillis(30)): Status = lock.withLock {
        withContext(Dispatchers.IO) {
            val s = settings.current()
            val treeUri = s.whatsAppFolderUri?.let(Uri::parse) ?: return@withContext Status(false, 0)
            val since = System.currentTimeMillis() - windowMs
            val kinds = if (s.saveWhatsAppMedia) MediaKind.entries else listOf(MediaKind.IMAGE)
            val already = repository.importedOriginalNames(AttachmentEntity.SOURCE_WHATSAPP_FOLDER)

            val rootId = try {
                DocumentsContract.getTreeDocumentId(treeUri)
            } catch (e: Exception) {
                return@withContext Status(false, 0)
            }
            var readable = false
            var imported = 0
            for (kind in kinds) {
                try {
                    val records = kind.markers
                        .flatMap { repository.mediaMessagesWithoutAttachment(PACKAGES, it, since) }
                        .distinctBy { it.id }
                    if (records.isEmpty()) {
                        readable = true
                        continue
                    }
                    val dirId = findDir(treeUri, rootId, kind.folderNames, depth = 0) ?: continue
                    readable = true
                    val files = listMedia(treeUri, dirId, kind, since - PhotoMatcher.TOLERANCE_MS).filter { it.id !in already }
                    val pairs = PhotoMatcher.match(
                        photos = records.map { PhotoMatcher.Photo(it.id, it.originalTimestamp) },
                        files = files.map { PhotoMatcher.File(it.id, it.lastModified) },
                    )
                    for ((recordId, fileId) in pairs) {
                        val f = files.first { it.id == fileId }
                        val saved = copy(f, kind) ?: continue
                        if (repository.addAttachment(recordId, saved, AttachmentEntity.SOURCE_WHATSAPP_FOLDER, f.id)) imported++
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "WhatsApp ${kind.name} import failed: ${e.javaClass.simpleName}")
                }
            }
            Status(readable, imported)
        }
    }

    /** True when the stored folder permission is still valid. */
    fun isFolderAccessible(uriString: String?): Boolean {
        if (uriString == null) return false
        val uri = Uri.parse(uriString)
        return context.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
    }

    private data class Doc(val id: String, val uri: Uri, val name: String, val mime: String, val lastModified: Long, val isDir: Boolean)

    private fun copy(f: Doc, kind: MediaKind): AttachmentStore.Saved? {
        val cr = context.contentResolver
        return when (kind) {
            MediaKind.IMAGE -> cr.openInputStream(f.uri)?.use { input ->
                val bytes = input.readBytes()
                if (bytes.size > AttachmentStore.MAX_BYTES) null else store.saveImage(bytes, f.mime)
            }
            else -> cr.openInputStream(f.uri)?.use { input ->
                store.saveStream(input, f.mime.ifBlank { if (kind == MediaKind.VOICE) "audio/ogg" else "video/mp4" })
            }
        }
    }

    private fun children(tree: Uri, parentDocId: String): List<Doc> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        val out = ArrayList<Doc>()
        context.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val mime = c.getString(2) ?: ""
                out += Doc(
                    id = id,
                    uri = DocumentsContract.buildDocumentUriUsingTree(tree, id),
                    name = c.getString(1) ?: "",
                    mime = mime,
                    lastModified = if (c.isNull(3)) 0L else c.getLong(3),
                    isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                )
            }
        }
        return out
    }

    /**
     * Received files modified after [since]. Voice notes live in weekly sub-folders, so recently
     * modified sub-folders are searched too. "Sent" and "Private" sub-folders are ignored.
     */
    private fun listMedia(tree: Uri, dirId: String, kind: MediaKind, since: Long): List<Doc> {
        val top = children(tree, dirId)
        val files = top.filter { !it.isDir }.toMutableList()
        if (kind == MediaKind.VOICE) {
            top.filter { it.isDir && it.name !in SKIP_DIRS && it.lastModified >= since }
                .sortedByDescending { it.lastModified }
                .take(3)
                .forEach { sub -> files += children(tree, sub.id).filter { !it.isDir } }
        }
        return files
            .filter { it.lastModified >= since && (MediaKind.ofMime(it.mime) == kind || mimeFromName(it.name) == kind) }
            .sortedBy { it.lastModified }
    }

    private fun mimeFromName(name: String): MediaKind? {
        val n = name.lowercase()
        return when {
            n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp") || n.endsWith(".png") -> MediaKind.IMAGE
            n.endsWith(".mp4") || n.endsWith(".3gp") -> MediaKind.VIDEO
            n.endsWith(".opus") || n.endsWith(".ogg") || n.endsWith(".m4a") || n.endsWith(".aac") -> MediaKind.VOICE
            else -> null
        }
    }

    /** Finds a folder named one of [names] inside the granted tree (the user may have picked it or a parent). */
    private fun findDir(tree: Uri, docId: String, names: Set<String>, depth: Int): String? {
        if (names.any { docId.endsWith("/$it") || docId.endsWith(":$it") || docId == it }) return docId
        if (depth >= 4) return null
        val dirs = children(tree, docId).filter { it.isDir }
        dirs.firstOrNull { it.name in names }?.let { return it.id }
        for (d in dirs.filter { it.name in WALK_NAMES }) {
            findDir(tree, d.id, names, depth + 1)?.let { return it }
        }
        return null
    }

    companion object {
        private const val TAG = "NV.WhatsApp"
        val PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")
        private val SKIP_DIRS = setOf("Sent", "Private")
        private val WALK_NAMES = setOf("WhatsApp", "WhatsApp Business", "Media", "com.whatsapp", "com.whatsapp.w4b")

        /** Folder to open the system picker at (Android 11+ location of WhatsApp media). */
        val INITIAL_FOLDER: Uri = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            "primary:Android/media/com.whatsapp/WhatsApp/Media",
        )
    }
}

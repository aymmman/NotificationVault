package com.aymman.notificationvault.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Provides the SQLCipher passphrase for the archive database.
 *
 * A random 256-bit passphrase is generated once, wrapped (AES-256-GCM) with a non-exportable key that
 * lives in the Android Keystore, and only the wrapped form is stored in app-private preferences.
 * The plain passphrase never touches disk.
 */
class DatabaseKeyManager(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** True when the stored key could not be unwrapped and a fresh, empty database had to be created. */
    var wasReset: Boolean = false
        private set

    @Synchronized
    fun getPassphrase(): ByteArray {
        val stored = prefs.getString(KEY_WRAPPED, null)
        if (stored != null) {
            try {
                return unwrap(stored)
            } catch (e: Exception) {
                // Keystore key missing/invalidated (e.g. data restored to another device).
                Log.w(TAG, "Database key could not be unwrapped; archive will be reset (${e.javaClass.simpleName})")
                context.deleteDatabase(com.aymman.notificationvault.data.db.AppDatabase.NAME)
                wasReset = true
            }
        }
        val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
        // Hex-encode so the passphrase never contains NUL bytes.
        val pass = raw.joinToString("") { "%02x".format(it) }.toByteArray(Charsets.US_ASCII)
        raw.fill(0)
        prefs.edit().putString(KEY_WRAPPED, wrap(pass)).apply()
        return pass
    }

    private fun keystoreKey(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return gen.generateKey()
    }

    private fun wrap(plain: ByteArray): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, keystoreKey())
        val ct = cipher.doFinal(plain)
        return Base64.encodeToString(cipher.iv + ct, Base64.NO_WRAP)
    }

    private fun unwrap(stored: String): ByteArray {
        val data = Base64.decode(stored, Base64.NO_WRAP)
        val iv = data.copyOfRange(0, 12)
        val ct = data.copyOfRange(12, data.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, keystoreKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ct)
    }

    companion object {
        private const val TAG = "NV.KeyManager"
        private const val PREFS = "nv_secure_keys"
        private const val KEY_WRAPPED = "db_pass_wrapped"
        private const val ALIAS = "notification_vault_db_key"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}

package com.aymman.notificationvault.domain.media

/**
 * Media types that can be copied from the WhatsApp media folder, with the emoji WhatsApp puts in the
 * notification text for each and the WhatsApp folder that holds received files of that type.
 */
enum class MediaKind(val markers: List<String>, val folderNames: Set<String>, val mimePrefix: String) {
    IMAGE(listOf("📷"), setOf("WhatsApp Images", "WhatsApp Business Images"), "image/"),
    VIDEO(listOf("🎥", "📹"), setOf("WhatsApp Video", "WhatsApp Business Video"), "video/"),
    VOICE(listOf("🎤"), setOf("WhatsApp Voice Notes", "WhatsApp Business Voice Notes"), "audio/");

    companion object {
        fun ofMime(mime: String?): MediaKind? = when {
            mime == null -> null
            mime.startsWith("image/") -> IMAGE
            mime.startsWith("video/") -> VIDEO
            mime.startsWith("audio/") || mime == "application/ogg" -> VOICE
            else -> null
        }

        /** Which media kind a notification text announces, if any. */
        fun ofText(text: String?): MediaKind? {
            if (text == null) return null
            return entries.firstOrNull { k -> k.markers.any { text.contains(it) } }
        }
    }
}

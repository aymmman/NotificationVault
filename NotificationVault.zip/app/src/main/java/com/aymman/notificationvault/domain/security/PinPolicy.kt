package com.aymman.notificationvault.domain.security

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Pure rules for the app PIN: format, hashing and lock-out after wrong attempts. */
object PinPolicy {

    const val MIN_LENGTH = 4
    const val MAX_LENGTH = 8
    const val FREE_ATTEMPTS = 5
    const val ITERATIONS = 120_000
    private const val BASE_LOCKOUT_MS = 30_000L
    private const val MAX_LOCKOUT_MS = 15 * 60_000L

    /** Converts Arabic-Indic / Persian digits to ASCII and drops anything that isn't a digit. */
    fun normalize(input: String): String = buildString {
        for (ch in input) {
            when (ch) {
                in '0'..'9' -> append(ch)
                in '\u0660'..'\u0669' -> append('0' + (ch - '\u0660'))
                in '\u06F0'..'\u06F9' -> append('0' + (ch - '\u06F0'))
            }
        }
    }

    fun isValidFormat(pin: String): Boolean = pin.length in MIN_LENGTH..MAX_LENGTH && pin.all { it in '0'..'9' }

    fun newSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

    fun hash(pin: String, salt: ByteArray, iterations: Int = ITERATIONS): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    /** Constant-time comparison. */
    fun matches(pin: String, salt: ByteArray, expected: ByteArray, iterations: Int = ITERATIONS): Boolean =
        MessageDigest.isEqual(hash(pin, salt, iterations), expected)

    /**
     * Lock-out after [failures] consecutive wrong PINs: none for the first [FREE_ATTEMPTS], then 30 s,
     * doubling for each further miss, capped at 15 minutes.
     */
    fun lockoutMs(failures: Int): Long {
        if (failures < FREE_ATTEMPTS) return 0L
        val steps = (failures - FREE_ATTEMPTS).coerceAtMost(10)
        return (BASE_LOCKOUT_MS shl steps).coerceAtMost(MAX_LOCKOUT_MS)
    }
}

package com.aymman.notificationvault

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aymman.notificationvault.data.prefs.ThemeMode
import com.aymman.notificationvault.ui.common.LocalAppInfo
import com.aymman.notificationvault.ui.lock.LockScreen
import com.aymman.notificationvault.ui.lock.PinLockScreen
import com.aymman.notificationvault.ui.navigation.VaultNavHost
import com.aymman.notificationvault.ui.onboarding.OnboardingScreen
import com.aymman.notificationvault.ui.theme.NotificationVaultTheme
import com.aymman.notificationvault.util.AppInfoResolver
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Single activity. Extends FragmentActivity because BiometricPrompt requires it.
 */
@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject lateinit var appInfo: AppInfoResolver

    private val vm: MainViewModel by viewModels()
    private var lockError by mutableStateOf<String?>(null)
    private var promptShowing = false

    /** Record to open after a tap on one of our alerts (consumed by the nav host). */
    private var openRecord by mutableStateOf<Long?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        readOpenRequest(intent)

        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            val unlocked by vm.unlocked.collectAsStateWithLifecycle()
            val pin by vm.pinManager.state.collectAsStateWithLifecycle()
            val s = settings

            NotificationVaultTheme(
                themeMode = s?.themeMode ?: ThemeMode.SYSTEM,
                dynamicColor = s?.dynamicColor ?: false,
            ) {
                LaunchedEffect(s?.privateMode) { applyPrivateMode(s?.privateMode == true) }
                CompositionLocalProvider(LocalAppInfo provides appInfo) {
                    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                        when {
                            s == null -> Unit // settings loading: draw only the background
                            pin.enabled && !unlocked -> PinLockScreen(
                                pinManager = vm.pinManager,
                                onUnlocked = { vm.onUnlocked() },
                                onBiometric = if (pin.biometric && canAuthenticate(BIOMETRIC_ONLY)) {
                                    { authenticate(biometricOnly = true) }
                                } else null,
                            )
                            s.biometricLock && !unlocked && canAuthenticate(AUTHENTICATORS) -> LockScreen(lockError) { authenticate(biometricOnly = false) }
                            !s.onboardingDone -> OnboardingScreen(
                                isAccessGranted = { vm.status.isAccessGranted() },
                                onFinish = { vm.completeOnboarding() },
                            )
                            else -> VaultNavHost(
                                openRecordId = openRecord,
                                onOpenConsumed = { openRecord = null },
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readOpenRequest(intent)
    }

    private fun readOpenRequest(intent: Intent?) {
        val id = intent?.getLongExtra(EXTRA_OPEN_RECORD, -1L) ?: -1L
        if (id > 0) openRecord = id
    }

    override fun onStart() {
        super.onStart()
        vm.onForeground()
    }

    override fun onStop() {
        // Ignore stops caused by our own biometric dialog.
        if (!promptShowing) vm.onBackground()
        super.onStop()
    }

    private fun applyPrivateMode(enabled: Boolean) {
        // FLAG_SECURE hides the content in the recent-apps switcher and blocks screenshots/recording.
        if (enabled) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    private fun canAuthenticate(authenticators: Int): Boolean =
        BiometricManager.from(this).canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS

    /**
     * Device lock mode: biometrics or the phone's screen lock.
     * PIN mode ([biometricOnly]): fingerprint/face only, with "Use PIN" as the way back to the keypad.
     */
    private fun authenticate(biometricOnly: Boolean) {
        if (promptShowing) return
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    promptShowing = false
                    lockError = null
                    vm.onUnlocked()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    promptShowing = false
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_CANCELED
                    ) {
                        lockError = errString.toString()
                    }
                }

                override fun onAuthenticationFailed() {
                    lockError = getString(R.string.lock_failed)
                }
            },
        )
        val builder = BiometricPrompt.PromptInfo.Builder().setTitle(getString(R.string.lock_prompt_title))
        if (biometricOnly) {
            builder.setAllowedAuthenticators(BIOMETRIC_ONLY).setNegativeButtonText(getString(R.string.pin_use_pin))
        } else {
            builder.setAllowedAuthenticators(AUTHENTICATORS)
        }
        val info = builder.build()
        promptShowing = true
        prompt.authenticate(info)
    }

    companion object {
        const val EXTRA_OPEN_RECORD = "open_record_id"
        private const val AUTHENTICATORS =
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        private const val BIOMETRIC_ONLY = BiometricManager.Authenticators.BIOMETRIC_WEAK
    }
}

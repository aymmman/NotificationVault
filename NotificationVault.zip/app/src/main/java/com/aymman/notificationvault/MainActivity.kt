package com.aymman.notificationvault

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aymman.notificationvault.data.prefs.ThemeMode
import com.aymman.notificationvault.ui.common.LocalAppInfo
import com.aymman.notificationvault.ui.lock.LockScreen
import com.aymman.notificationvault.ui.navigation.VaultNavHost
import com.aymman.notificationvault.ui.onboarding.OnboardingScreen
import com.aymman.notificationvault.ui.theme.NotificationVaultTheme
import com.aymman.notificationvault.util.AppInfoResolver
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Single activity. Extends FragmentActivity because BiometricPrompt requires it.
 */
@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject lateinit var appInfo: AppInfoResolver

    private val vm: MainViewModel by viewModels()
    private var lockError by mutableStateOf<String?>(null)
    private var promptShowing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            val unlocked by vm.unlocked.collectAsStateWithLifecycle()
            val s = settings

            NotificationVaultTheme(
                themeMode = s?.themeMode ?: ThemeMode.SYSTEM,
                dynamicColor = s?.dynamicColor ?: false,
            ) {
                LaunchedEffect(s?.privateMode) { applyPrivateMode(s?.privateMode == true) }
                CompositionLocalProvider(LocalAppInfo provides appInfo) {
                    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                        when {
                            s == null -> Unit // settings loading: draw only the background
                            s.biometricLock && !unlocked && canAuthenticate() -> LockScreen(lockError) { authenticate() }
                            !s.onboardingDone -> OnboardingScreen(
                                isAccessGranted = { vm.status.isAccessGranted() },
                                onFinish = { vm.completeOnboarding() },
                            )
                            else -> VaultNavHost()
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.onForeground()
    }

    override fun onStop() {
        // Ignore stops caused by our own biometric dialog.
        if (!promptShowing) vm.onBackground()
        super.onStop()
    }

    private fun applyPrivateMode(enabled: Boolean) {
        // FLAG_SECURE hides the content in the recent-apps switcher and blocks screenshots/recording.
        if (enabled) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    private fun canAuthenticate(): Boolean =
        BiometricManager.from(this).canAuthenticate(AUTHENTICATORS) == BiometricManager.BIOMETRIC_SUCCESS

    private fun authenticate() {
        if (promptShowing) return
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    promptShowing = false
                    lockError = null
                    vm.onUnlocked()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    promptShowing = false
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_CANCELED
                    ) {
                        lockError = errString.toString()
                    }
                }

                override fun onAuthenticationFailed() {
                    lockError = getString(R.string.lock_failed)
                }
            },
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.lock_prompt_title))
            .setAllowedAuthenticators(AUTHENTICATORS)
            .build()
        promptShowing = true
        prompt.authenticate(info)
    }

    companion object {
        private const val AUTHENTICATORS =
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    }
}

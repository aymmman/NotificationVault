package com.aymman.notificationvault.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.MarkEmailUnread
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.AppSummary
import com.aymman.notificationvault.domain.model.NotificationKind
import com.aymman.notificationvault.ui.common.AppIcon
import com.aymman.notificationvault.ui.common.CaptureState
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.KindChips
import com.aymman.notificationvault.ui.common.NotificationListItem
import com.aymman.notificationvault.ui.common.OnResume
import com.aymman.notificationvault.ui.common.SectionHeader
import com.aymman.notificationvault.ui.common.StatusPill
import com.aymman.notificationvault.ui.theme.LocalVaultExtras

@Composable
fun HomeScreen(
    onOpenSearch: () -> Unit,
    onOpenInbox: (kind: NotificationKind?, unreadOnly: Boolean) -> Unit,
    onOpenApp: (String) -> Unit,
    onOpenApps: () -> Unit,
    onOpenSaved: () -> Unit,
    onOpenDetail: (Long) -> Unit,
    onOpenAccess: () -> Unit,
    onOpenDeleted: () -> Unit = {},
    onOpenGallery: () -> Unit = {},
    onOpenStats: () -> Unit = {},
    vm: HomeViewModel = hiltViewModel(),
) {
    val deletedCount by vm.deletedCount.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val topApps by vm.topApps.collectAsStateWithLifecycle()
    val state by vm.captureState.collectAsStateWithLifecycle()
    OnResume { vm.refresh() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
    ) {
        item(key = "top") {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall)
                    Text(
                        stringResource(R.string.home_greeting),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onOpenGallery) {
                    Icon(Icons.Outlined.PhotoLibrary, contentDescription = stringResource(R.string.gallery_title))
                }
                IconButton(onClick = onOpenStats) {
                    Icon(Icons.Outlined.BarChart, contentDescription = stringResource(R.string.stats_title))
                }
                if (stats.unread > 0) {
                    IconButton(onClick = { vm.markAllRead() }) {
                        Icon(Icons.Filled.DoneAll, contentDescription = stringResource(R.string.action_mark_all_read))
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        item(key = "hero") {
            HeroCard(total = stats.total, state = state, onFix = {
                if (state == CaptureState.PAUSED) vm.resumeCapture() else onOpenAccess()
            })
            Spacer(Modifier.height(14.dp))
        }

        if (deletedCount > 0) {
            item(key = "deleted") {
                Surface(
                    onClick = onOpenDeleted,
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🗑️", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.home_deleted_title, deletedCount),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                            )
                            Text(
                                stringResource(R.string.home_deleted_body),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }

        item(key = "search") {
            Surface(
                onClick = onOpenSearch,
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(R.string.home_search_hint), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        item(key = "stats") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(Icons.Outlined.Today, stats.today, stringResource(R.string.stat_today), Modifier.weight(1f)) { onOpenInbox(null, false) }
                StatTile(Icons.Outlined.MarkEmailUnread, stats.unread, stringResource(R.string.stat_unread), Modifier.weight(1f)) { onOpenInbox(null, true) }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(Icons.Outlined.Apps, stats.monitoredApps, stringResource(R.string.stat_apps), Modifier.weight(1f), onOpenApps)
                StatTile(Icons.Outlined.BookmarkBorder, stats.saved, stringResource(R.string.stat_saved), Modifier.weight(1f), onOpenSaved)
            }
            if (stats.today > 0) {
                Spacer(Modifier.height(10.dp))
                Text(
                    stringResource(R.string.home_today_summary, stats.today, stats.todayApps),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }

        item(key = "chips") {
            Spacer(Modifier.height(8.dp))
            KindChips(selected = null, onSelect = { onOpenInbox(it, false) })
        }

        if (topApps.isNotEmpty()) {
            item(key = "apps_h") {
                SectionHeader(stringResource(R.string.home_frequent_apps)) {
                    TextButton(onClick = onOpenApps) { Text(stringResource(R.string.home_see_all)) }
                }
            }
            item(key = "apps") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(topApps, key = { it.packageName }) { app -> AppBubble(app) { onOpenApp(app.packageName) } }
                }
            }
        }

        item(key = "recent_h") {
            SectionHeader(stringResource(R.string.home_recent)) {
                TextButton(onClick = { onOpenInbox(null, false) }) { Text(stringResource(R.string.home_see_all)) }
            }
        }
        val rows = recent
        when {
            rows == null -> item(key = "loading") {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            }
            rows.isEmpty() -> item(key = "empty") {
                EmptyState(
                    title = stringResource(R.string.home_empty_title),
                    body = stringResource(R.string.home_empty_body),
                )
            }
            else -> items(rows, key = { it.n.id }) { row ->
                NotificationListItem(
                    row = row,
                    selected = false,
                    selectionMode = false,
                    showApp = true,
                    onClick = { onOpenDetail(row.n.id) },
                    onLongClick = { onOpenDetail(row.n.id) },
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun HeroCard(total: Int, state: CaptureState, onFix: () -> Unit) {
    val extras = LocalVaultExtras.current
    Box(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(extras.heroBrush)
            .padding(22.dp),
    ) {
        // Soft decorative circles
        Box(
            Modifier.align(Alignment.TopEnd).size(120.dp).padding(start = 40.dp, bottom = 40.dp)
                .clip(CircleShape).background(Color.White.copy(alpha = 0.06f)),
        )
        Column {
            StatusPill(state)
            Spacer(Modifier.height(18.dp))
            Text(
                text = "%,d".format(total),
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )
            Text(
                stringResource(R.string.home_total_archived),
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.85f),
            )
            if (state != CaptureState.ACTIVE) {
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onFix,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF4C1D95)),
                ) {
                    Text(stringResource(if (state == CaptureState.PAUSED) R.string.action_resume else R.string.action_grant_access))
                }
            }
        }
    }
}

@Composable
private fun StatTile(icon: ImageVector, value: Int, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        shape = MaterialTheme.shapes.large,
        modifier = modifier,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("%,d".format(value), style = MaterialTheme.typography.titleLarge)
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun AppBubble(app: AppSummary, onClick: () -> Unit) {
    Column(
        Modifier.width(76.dp).clip(MaterialTheme.shapes.medium).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            AppIcon(app.packageName, app.appLabel, size = 52.dp)
            if (app.unread > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                ) {
                    Text(
                        if (app.unread > 99) "99+" else app.unread.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            app.appLabel,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

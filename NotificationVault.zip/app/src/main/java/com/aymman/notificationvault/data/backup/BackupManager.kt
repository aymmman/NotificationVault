package com.aymman.notificationvault.data.backup

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.room.withTransaction
import com.aymman.notificationvault.data.db.AppDatabase
import com.aymman.notificationvault.data.db.ArchivedNotificationEntity
import com.aymman.notificationvault.data.db.BackupRecordEntity
import com.aymman.notificationvault.data.db.MonitoredAppEntity
import com.aymman.notificationvault.domain.export.BackupApp
import com.aymman.notificationvault.domain.export.BackupCrypto
import com.aymman.notificationvault.domain.export.BackupNotification
import com.aymman.notificationvault.domain.export.BackupPayload
import com.aymman.notificationvault.domain.export.BackupValidator
import com.aymman.notificationvault.domain.export.ExportFile
import com.aymman.notificationvault.domain.export.ExportFormat
import com.aymman.notificationvault.domain.export.ExportFormatter
import com.aymman.notificationvault.domain.export.ExportRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

/** Export, backup and restore through the Storage Access Framework (user picks every destination). */
class BackupManager(
    private val context: Context,
    private val db: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
        encodeDefaults = true
    }

    class RestoreResult(val inserted: Int, val skipped: Int)

    /** Writes the given records (or everything when [ids] is null). Returns the number exported. */
    suspend fun export(uri: Uri, format: ExportFormat, ids: List<Long>?): Int = withContext(Dispatchers.IO) {
        val dao = db.notificationDao()
        val items = if (ids == null) dao.getAll() else ids.chunked(500).flatMap { dao.getByIds(it) }
            .sortedByDescending { it.receivedAt }
        val labels = db.appDao().getAll().associate { it.packageName to it.appLabel }
        val records = items.map { it.toExport(labels[it.packageName] ?: it.packageName) }
        val content = when (format) {
            ExportFormat.JSON -> json.encodeToString(ExportFile.serializer(), ExportFile(clock(), records.size, records = records))
            ExportFormat.CSV -> ExportFormatter.csv(records)
            ExportFormat.TEXT -> ExportFormatter.text(records)
        }
        write(uri, content.toByteArray(Charsets.UTF_8))
        log("EXPORT_${format.name}", records.size, false, uri)
        records.size
    }

    /** Full archive backup. When [password] is non-empty the file is AES-256-GCM encrypted. */
    suspend fun backup(uri: Uri, password: CharArray?): Int = withContext(Dispatchers.IO) {
        val apps = db.appDao().getAll()
        val items = db.notificationDao().getAll()
        val payload = BackupPayload(
            createdAt = clock(),
            apps = apps.map {
                BackupApp(it.packageName, it.appLabel, it.firstSeenAt, it.lastSeenAt, it.captureEnabled, it.favorite, it.muted, it.retentionDays)
            },
            notifications = items.map { it.toBackup() },
        )
        var bytes = json.encodeToString(BackupPayload.serializer(), payload).toByteArray(Charsets.UTF_8)
        val encrypted = password != null && password.isNotEmpty()
        if (encrypted) bytes = BackupCrypto.encrypt(bytes, password!!)
        write(uri, bytes)
        log("BACKUP", items.size, encrypted, uri)
        items.size
    }

    /** Peeks at the file so the UI can ask for a password only when needed. */
    suspend fun isEncrypted(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { s ->
            val head = ByteArray(16)
            val n = s.read(head)
            n > 0 && BackupCrypto.isEncrypted(head.copyOf(n))
        } ?: false
    }

    /**
     * Restores a backup after validation. Existing records are kept; records already present
     * (same dedup key) are skipped, so restoring twice never duplicates anything.
     */
    suspend fun restore(uri: Uri, password: CharArray?): RestoreResult = withContext(Dispatchers.IO) {
        val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalArgumentException("Cannot read file")
        if (raw.size > MAX_BACKUP_BYTES) throw IllegalArgumentException("File is too large")
        val plain = if (BackupCrypto.isEncrypted(raw)) {
            if (password == null || password.isEmpty()) throw BackupCrypto.WrongPasswordException()
            BackupCrypto.decrypt(raw, password)
        } else raw
        val payload = try {
            json.decodeFromString(BackupPayload.serializer(), plain.toString(Charsets.UTF_8))
        } catch (e: Exception) {
            throw IllegalArgumentException("Not a valid Notification Vault backup")
        }
        when (val v = BackupValidator.validate(payload)) {
            is BackupValidator.Result.Invalid -> throw IllegalArgumentException(v.reason)
            BackupValidator.Result.Ok -> Unit
        }

        var inserted = 0
        db.withTransaction {
            val appDao = db.appDao()
            val known = appDao.getAll().map { it.packageName }.toMutableSet()
            payload.apps.forEach { a ->
                if (known.add(a.packageName)) {
                    appDao.insertIfAbsent(
                        MonitoredAppEntity(a.packageName, a.appLabel, a.firstSeenAt, a.lastSeenAt, a.captureEnabled, a.favorite, a.muted, a.retentionDays),
                    )
                }
            }
            payload.notifications.forEach { b ->
                if (known.add(b.packageName)) {
                    appDao.insertIfAbsent(MonitoredAppEntity(b.packageName, b.packageName, b.receivedAt, b.receivedAt))
                }
            }
            val ids = payload.notifications.chunked(500).flatMap { chunk ->
                db.notificationDao().insertAll(chunk.map { it.toEntity() })
            }
            inserted = ids.count { it != -1L }
        }
        log("RESTORE", inserted, BackupCrypto.isEncrypted(raw), uri)
        RestoreResult(inserted, payload.notifications.size - inserted)
    }

    private fun write(uri: Uri, bytes: ByteArray) {
        val out = context.contentResolver.openOutputStream(uri, "wt")
            ?: throw IllegalStateException("Cannot open destination")
        out.use { it.write(bytes) }
    }

    private suspend fun log(type: String, count: Int, encrypted: Boolean, uri: Uri) {
        db.backupDao().insert(BackupRecordEntity(createdAt = clock(), type = type, itemCount = count, encrypted = encrypted, displayName = displayName(uri)))
    }

    private fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    companion object {
        const val MAX_BACKUP_BYTES = 200L * 1024 * 1024

        fun ArchivedNotificationEntity.toExport(appLabel: String) = ExportRecord(
            app = appLabel,
            packageName = packageName,
            title = title,
            text = text,
            expandedText = bigText,
            sender = senderName,
            conversation = conversationTitle,
            category = category,
            kind = kind,
            userCategory = userCategory,
            receivedAt = receivedAt,
            originalTimestamp = originalTimestamp,
            pinned = isPinned,
            bookmarked = isBookmarked,
            deletedBySenderAt = deletedAt,
        )

        fun ArchivedNotificationEntity.toBackup() = BackupNotification(
            dedupKey = dedupKey,
            packageName = packageName,
            notificationKey = notificationKey,
            title = title,
            text = text,
            bigText = bigText,
            subText = subText,
            senderName = senderName,
            conversationId = conversationId,
            conversationTitle = conversationTitle,
            category = category,
            kind = kind,
            userCategory = userCategory,
            receivedAt = receivedAt,
            originalTimestamp = originalTimestamp,
            removedAt = removedAt,
            isRead = isRead,
            isPinned = isPinned,
            isBookmarked = isBookmarked,
            deletedAt = deletedAt,
            isDeletionNotice = isDeletionNotice,
        )

        fun BackupNotification.toEntity() = ArchivedNotificationEntity(
            dedupKey = dedupKey,
            packageName = packageName,
            notificationKey = notificationKey,
            title = title,
            text = text,
            bigText = bigText,
            subText = subText,
            senderName = senderName,
            conversationId = conversationId,
            conversationTitle = conversationTitle,
            category = category,
            kind = kind,
            userCategory = userCategory,
            receivedAt = receivedAt,
            originalTimestamp = originalTimestamp,
            removedAt = removedAt,
            isRead = isRead,
            isPinned = isPinned,
            isBookmarked = isBookmarked,
            deletedAt = deletedAt,
            isDeletionNotice = isDeletionNotice,
        )
    }
}

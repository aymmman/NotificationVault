package com.aymman.notificationvault

import android.app.Application
import com.aymman.notificationvault.notify.VaultNotifier
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VaultApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        VaultNotifier(this).createChannels()
    }
}

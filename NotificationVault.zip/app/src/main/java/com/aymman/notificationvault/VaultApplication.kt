package com.aymman.notificationvault

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VaultApplication : Application()

package com.aymman.notificationvault.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aymman.notificationvault.R
import com.aymman.notificationvault.ui.theme.LocalVaultExtras

enum class CaptureState { ACTIVE, PAUSED, NO_ACCESS, WAITING }

fun captureState(accessGranted: Boolean, connected: Boolean, captureEnabled: Boolean): CaptureState = when {
    !accessGranted -> CaptureState.NO_ACCESS
    !captureEnabled -> CaptureState.PAUSED
    !connected -> CaptureState.WAITING
    else -> CaptureState.ACTIVE
}

/** Compact status line used inside the hero card (light text on the gradient). */
@Composable
fun StatusPill(state: CaptureState) {
    val (dot, label) = when (state) {
        CaptureState.ACTIVE -> Color(0xFF4ADE80) to R.string.status_active
        CaptureState.PAUSED -> Color(0xFFFBBF24) to R.string.status_paused
        CaptureState.NO_ACCESS -> Color(0xFFF87171) to R.string.status_off
        CaptureState.WAITING -> Color(0xFFFBBF24) to R.string.status_waiting
    }
    Row(
        Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        androidx.compose.foundation.layout.Box(Modifier.size(8.dp).background(dot, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(label), color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}

/** Full status card with explanation and a fix action. */
@Composable
fun CaptureStatusCard(
    state: CaptureState,
    onOpenAccess: () -> Unit,
    onResume: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val extras = LocalVaultExtras.current
    val (icon, tint, title, body) = when (state) {
        CaptureState.ACTIVE -> Quad(Icons.Filled.CheckCircle, extras.success, R.string.status_active, R.string.status_active_desc)
        CaptureState.PAUSED -> Quad(Icons.Filled.PauseCircle, extras.warning, R.string.status_paused, R.string.status_paused_desc)
        CaptureState.NO_ACCESS -> Quad(Icons.Filled.ErrorOutline, MaterialTheme.colorScheme.error, R.string.status_off, R.string.status_off_desc)
        CaptureState.WAITING -> Quad(Icons.Filled.HourglassTop, extras.warning, R.string.status_waiting, R.string.status_waiting_desc)
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        shape = MaterialTheme.shapes.large,
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = tint)
                Spacer(Modifier.width(10.dp))
                Text(stringResource(title), style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(6.dp))
            Text(stringResource(body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            when (state) {
                CaptureState.NO_ACCESS, CaptureState.WAITING -> {
                    Spacer(Modifier.height(12.dp))
                    FilledTonalButton(onClick = onOpenAccess) { Text(stringResource(R.string.capture_open_access)) }
                }
                CaptureState.PAUSED -> {
                    Spacer(Modifier.height(12.dp))
                    FilledTonalButton(onClick = onResume) { Text(stringResource(R.string.action_resume)) }
                }
                CaptureState.ACTIVE -> Unit
            }
        }
    }
}

private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

package com.aymman.notificationvault.data.repo

import androidx.room.withTransaction
import com.aymman.notificationvault.data.db.AppDatabase
import com.aymman.notificationvault.data.db.AppSummary
import com.aymman.notificationvault.data.db.BackupRecordEntity
import com.aymman.notificationvault.data.db.ArchivedNotificationEntity
import com.aymman.notificationvault.data.db.CaptureRuleEntity
import com.aymman.notificationvault.data.db.ConversationCount
import com.aymman.notificationvault.data.db.ConversationEntity
import com.aymman.notificationvault.data.db.KindCount
import com.aymman.notificationvault.data.db.MonitoredAppEntity
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.db.QueryBuilder
import com.aymman.notificationvault.data.prefs.AppSettings
import com.aymman.notificationvault.domain.NotificationParser
import com.aymman.notificationvault.domain.RetentionPolicy
import com.aymman.notificationvault.domain.model.CaptureOptions
import com.aymman.notificationvault.domain.model.CapturedRecord
import com.aymman.notificationvault.domain.model.RawNotification
import com.aymman.notificationvault.domain.model.SearchFilters
import kotlinx.coroutines.flow.Flow

/** Single source of truth for the archive. All reads come from the encrypted local database. */
class VaultRepository(
    private val db: AppDatabase,
    private val ownPackage: String,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val notifications = db.notificationDao()
    private val apps = db.appDao()
    private val conversations = db.conversationDao()
    private val rules = db.captureRuleDao()

    @Volatile private var cachedKeywords: List<String>? = null

    // ------------------------------------------------------------------ capture

    /**
     * Archives a notification. Returns the number of NEW records written (duplicates are ignored).
     * Never throws for malformed input; database errors propagate to the caller, which logs them
     * without content.
     */
    suspend fun capture(raw: RawNotification, appLabel: String, settings: AppSettings): Int {
        if (!settings.captureEnabled) return 0
        if (raw.packageName == ownPackage || raw.packageName.startsWith("$ownPackage.")) return 0
        val existingApp = apps.get(raw.packageName)
        if (existingApp != null && !existingApp.captureEnabled) return 0

        val options = CaptureOptions(
            skipOngoing = settings.skipOngoing,
            skipGroupSummaries = settings.skipGroupSummaries,
            filterSystemNoise = settings.filterSystemNoise,
            excludedKeywords = keywords(),
        )
        val records = NotificationParser.parse(raw, options)
        if (records.isEmpty()) return 0

        val now = clock()
        var inserted = 0
        db.withTransaction {
            if (existingApp == null) {
                apps.insertIfAbsent(
                    MonitoredAppEntity(
                        packageName = raw.packageName,
                        appLabel = appLabel,
                        firstSeenAt = now,
                        lastSeenAt = now,
                    ),
                )
            } else {
                apps.touch(raw.packageName, appLabel, now)
            }
            for (rec in records) {
                if (notifications.insert(rec.toEntity(now)) != -1L) inserted++
                val convKey = rec.conversationId
                if (rec.isFromMessagingStyle && convKey != null) {
                    val id = conversations.insertIfAbsent(
                        ConversationEntity(
                            packageName = rec.packageName,
                            conversationKey = convKey,
                            title = rec.conversationTitle,
                            lastMessageAt = rec.originalTimestamp,
                        ),
                    )
                    if (id == -1L) conversations.touch(rec.packageName, convKey, rec.conversationTitle, rec.originalTimestamp)
                }
            }
        }
        return inserted
    }

    /** The notification left the shade. The archived record is kept; we only note when. */
    suspend fun onRemoved(notificationKey: String) {
        notifications.markRemoved(notificationKey, clock())
    }

    private suspend fun keywords(): List<String> =
        cachedKeywords ?: rules.getEnabled()
            .filter { it.type == CaptureRuleEntity.TYPE_KEYWORD }
            .map { it.value }
            .also { cachedKeywords = it }

    // ------------------------------------------------------------------ reads

    fun observeRows(filters: SearchFilters, hideMuted: Boolean = false, limit: Int = QueryBuilder.DEFAULT_LIMIT): Flow<List<NotificationRow>> =
        notifications.observeRows(QueryBuilder.toQuery(QueryBuilder.build(filters, hideMuted, limit)))

    fun observeRow(id: Long): Flow<NotificationRow?> = notifications.observeRow(id)
    fun observeTotal(): Flow<Int> = notifications.observeTotal()
    fun observeSince(since: Long): Flow<Int> = notifications.observeSince(since)
    fun observeUnread(): Flow<Int> = notifications.observeUnread()
    fun observeAppsSince(since: Long): Flow<Int> = notifications.observeAppsSince(since)
    fun observeSavedCount(): Flow<Int> = notifications.observeSavedCount()
    fun observeKindCounts(): Flow<List<KindCount>> = notifications.observeKindCounts()
    fun observeOldest(): Flow<Long?> = notifications.observeOldest()
    fun observeMonitoredCount(): Flow<Int> = apps.observeMonitoredCount()
    fun observeAppSummaries(): Flow<List<AppSummary>> = apps.observeSummaries()
    fun observeApp(pkg: String): Flow<MonitoredAppEntity?> = apps.observe(pkg)
    fun observeConversations(pkg: String): Flow<List<ConversationCount>> = notifications.observeConversations(pkg)
    fun observeSenders(pkg: String?): Flow<List<String>> = notifications.observeSenders(pkg)
    fun observeCategories(): Flow<List<String>> = notifications.observeCategories()
    fun observeRules(): Flow<List<CaptureRuleEntity>> = rules.observeAll()
    fun observeConversationCount(): Flow<Int> = conversations.observeCount()
    fun observeBackupHistory(): Flow<List<BackupRecordEntity>> = db.backupDao().observeRecent()

    suspend fun getByIds(ids: List<Long>): List<ArchivedNotificationEntity> =
        ids.chunked(500).flatMap { notifications.getByIds(it) }

    // ------------------------------------------------------------------ actions

    suspend fun setRead(ids: List<Long>, read: Boolean) = ids.chunked(500).forEach { notifications.setRead(it, read) }
    suspend fun markAppRead(pkg: String) = notifications.markAppRead(pkg)
    suspend fun markAllRead() = notifications.markAllRead()
    suspend fun setPinned(ids: List<Long>, pinned: Boolean) = ids.chunked(500).forEach { notifications.setPinned(it, pinned) }
    suspend fun setBookmarked(ids: List<Long>, value: Boolean) = ids.chunked(500).forEach { notifications.setBookmarked(it, value) }
    suspend fun setUserCategory(ids: List<Long>, category: String?) = ids.chunked(500).forEach { notifications.setUserCategory(it, category) }
    suspend fun clearUserCategory(category: String) = notifications.clearUserCategory(category)

    suspend fun delete(ids: List<Long>): Int = db.withTransaction { ids.chunked(500).sumOf { notifications.delete(it) } }
    suspend fun deleteForApp(pkg: String): Int = notifications.deleteForApp(pkg)
    suspend fun deleteAll(): Int = notifications.deleteAll()
    suspend fun deleteOlderThan(cutoff: Long): Int = notifications.deleteOlderThan(cutoff)
    suspend fun countOlderThan(cutoff: Long): Int = notifications.countOlderThan(cutoff)

    suspend fun setAppCaptureEnabled(pkg: String, enabled: Boolean) = apps.setCaptureEnabled(pkg, enabled)
    suspend fun setAppFavorite(pkg: String, fav: Boolean) = apps.setFavorite(pkg, fav)
    suspend fun setAppMuted(pkg: String, muted: Boolean) = apps.setMuted(pkg, muted)
    suspend fun setAppRetention(pkg: String, days: Int?) = apps.setRetention(pkg, days)

    suspend fun addKeywordRule(value: String): Boolean {
        val v = value.trim().take(100)
        if (v.isEmpty()) return false
        val id = rules.insert(CaptureRuleEntity(type = CaptureRuleEntity.TYPE_KEYWORD, value = v, createdAt = clock()))
        cachedKeywords = null
        return id != -1L
    }

    suspend fun deleteRule(id: Long) {
        rules.delete(id); cachedKeywords = null
    }

    suspend fun setRuleEnabled(id: Long, enabled: Boolean) {
        rules.setEnabled(id, enabled); cachedKeywords = null
    }

    // ------------------------------------------------------------------ retention

    /** Applies global and per-app retention. Pinned and bookmarked records are always kept. */
    suspend fun applyRetention(globalDays: Int): Int {
        val now = clock()
        val overrides = apps.getWithRetentionOverride()
        var deleted = 0
        db.withTransaction {
            for (app in overrides) {
                val days = RetentionPolicy.effectiveDays(globalDays, app.retentionDays)
                val cutoff = RetentionPolicy.cutoffMillis(now, days) ?: continue
                deleted += notifications.deleteExpiredForApp(app.packageName, cutoff)
            }
            RetentionPolicy.cutoffMillis(now, globalDays)?.let { cutoff ->
                deleted += notifications.deleteExpiredGlobal(cutoff, overrides.map { it.packageName })
            }
        }
        return deleted
    }

    private fun CapturedRecord.toEntity(now: Long) = ArchivedNotificationEntity(
        dedupKey = dedupKey,
        packageName = packageName,
        notificationKey = notificationKey,
        title = title,
        text = text,
        bigText = bigText,
        subText = subText,
        senderName = senderName,
        conversationId = conversationId,
        conversationTitle = conversationTitle,
        category = category,
        kind = kind.name,
        receivedAt = now,
        originalTimestamp = originalTimestamp,
        isFromMessagingStyle = isFromMessagingStyle,
    )
}

package com.aymman.notificationvault.domain.export

import kotlinx.serialization.Serializable

const val BACKUP_FORMAT = "notification-vault-backup"
const val BACKUP_VERSION = 1

/** Human-oriented export row (JSON/CSV/TXT). Contains no internal keys. */
@Serializable
data class ExportRecord(
    val app: String,
    val packageName: String,
    val title: String? = null,
    val text: String? = null,
    val expandedText: String? = null,
    val sender: String? = null,
    val conversation: String? = null,
    val category: String? = null,
    val kind: String,
    val userCategory: String? = null,
    val receivedAt: Long,
    val originalTimestamp: Long,
    val pinned: Boolean = false,
    val bookmarked: Boolean = false,
    val deletedBySenderAt: Long? = null,
)

@Serializable
data class ExportFile(
    val exportedAt: Long,
    val count: Int,
    val note: String = "Content archived from Android notifications by Notification Vault. " +
        "It reflects what the notification showed, not necessarily the original message.",
    val records: List<ExportRecord>,
)

@Serializable
data class BackupNotification(
    val dedupKey: String,
    val packageName: String,
    val notificationKey: String,
    val title: String? = null,
    val text: String? = null,
    val bigText: String? = null,
    val subText: String? = null,
    val senderName: String? = null,
    val conversationId: String? = null,
    val conversationTitle: String? = null,
    val category: String? = null,
    val kind: String,
    val userCategory: String? = null,
    val receivedAt: Long,
    val originalTimestamp: Long,
    val removedAt: Long? = null,
    val isRead: Boolean = false,
    val isPinned: Boolean = false,
    val isBookmarked: Boolean = false,
    val deletedAt: Long? = null,
    val isDeletionNotice: Boolean = false,
)

@Serializable
data class BackupApp(
    val packageName: String,
    val appLabel: String,
    val firstSeenAt: Long,
    val lastSeenAt: Long,
    val captureEnabled: Boolean = true,
    val favorite: Boolean = false,
    val muted: Boolean = false,
    val retentionDays: Int? = null,
)

@Serializable
data class BackupPayload(
    val format: String = BACKUP_FORMAT,
    val version: Int = BACKUP_VERSION,
    val createdAt: Long,
    val apps: List<BackupApp>,
    val notifications: List<BackupNotification>,
)

object BackupValidator {
    sealed interface Result {
        data object Ok : Result
        data class Invalid(val reason: String) : Result
    }

    fun validate(payload: BackupPayload): Result = when {
        payload.format != BACKUP_FORMAT -> Result.Invalid("Not a Notification Vault backup")
        payload.version > BACKUP_VERSION -> Result.Invalid("Backup was created by a newer app version")
        payload.version < 1 -> Result.Invalid("Unknown backup version")
        payload.notifications.any { it.dedupKey.isBlank() || it.packageName.isBlank() } ->
            Result.Invalid("Backup contains malformed records")
        else -> Result.Ok
    }
}

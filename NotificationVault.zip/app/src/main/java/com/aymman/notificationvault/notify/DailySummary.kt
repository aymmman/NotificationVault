package com.aymman.notificationvault.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/** Schedules the evening summary with an inexact daily alarm (no exact-alarm permission needed). */
object SummaryScheduler {

    fun schedule(context: Context, enabled: Boolean, hour: Int) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = pendingIntent(context)
        am.cancel(pi)
        if (!enabled) return
        val zone = ZoneId.systemDefault()
        var next = LocalDate.now(zone).atTime(hour.coerceIn(0, 23), 0)
        if (!next.isAfter(LocalDateTime.now(zone))) next = next.plusDays(1)
        val at = next.atZone(zone).toInstant().toEpochMilli()
        am.setInexactRepeating(AlarmManager.RTC, at, AlarmManager.INTERVAL_DAY, pi)
    }

    private fun pendingIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        0,
        Intent(context, DailySummaryReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )
}

@EntryPoint
@InstallIn(SingletonComponent::class)
interface SummaryEntryPoint {
    fun repository(): VaultRepository
    fun settings(): SettingsRepository
    fun notifier(): VaultNotifier
}

/** Builds the summary from the local database and posts it. Never touches the network. */
class DailySummaryReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val ep = EntryPointAccessors.fromApplication(context.applicationContext, SummaryEntryPoint::class.java)
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                if (!ep.settings().current().dailySummary) return@launch
                val since = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val repo = ep.repository()
                val total = repo.countSince(since)
                val deleted = repo.countDeletedSince(since)
                if (total == 0 && deleted == 0) return@launch
                val top = repo.topApps(since, 3).map { "${it.label} (${it.count})" }
                ep.notifier().dailySummary(total, deleted, top)
            } catch (e: Exception) {
                android.util.Log.w("NV.Summary", "Summary failed: ${e.javaClass.simpleName}")
            } finally {
                pending.finish()
            }
        }
    }
}

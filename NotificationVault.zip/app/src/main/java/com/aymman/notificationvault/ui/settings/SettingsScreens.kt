package com.aymman.notificationvault.ui.settings

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.BatteryAlert
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material.icons.outlined.Password
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Sync
import com.aymman.notificationvault.data.media.WhatsAppImporter
import com.aymman.notificationvault.data.security.PinManager
import com.aymman.notificationvault.domain.security.PinPolicy
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.InputChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aymman.notificationvault.BuildConfig
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.prefs.ThemeMode
import com.aymman.notificationvault.domain.RetentionPolicy
import com.aymman.notificationvault.domain.export.ExportFormat
import com.aymman.notificationvault.service.ListenerStatus
import com.aymman.notificationvault.ui.common.AppIcon
import com.aymman.notificationvault.ui.common.BackTopBar
import com.aymman.notificationvault.ui.common.CaptureStatusCard
import com.aymman.notificationvault.ui.common.ConfirmDialog
import com.aymman.notificationvault.ui.common.ExportFormatDialog
import com.aymman.notificationvault.ui.common.Formatters
import com.aymman.notificationvault.ui.common.InfoCard
import com.aymman.notificationvault.ui.common.OnResume
import com.aymman.notificationvault.ui.common.SectionHeader
import com.aymman.notificationvault.ui.common.SettingsCard
import com.aymman.notificationvault.ui.common.SettingsRow
import com.aymman.notificationvault.ui.common.SwitchRow
import com.aymman.notificationvault.ui.common.captureState
import com.aymman.notificationvault.ui.common.resolve
import kotlinx.coroutines.launch

// ------------------------------------------------------------------------------------------ shared

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScaffold(
    title: String,
    onBack: (() -> Unit)?,
    vm: SettingsViewModel,
    content: @Composable () -> Unit,
) {
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val busy by vm.busy.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it.resolve(context)) } }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (onBack != null) {
                BackTopBar(title, onBack)
            } else {
                TopAppBar(
                    title = { Text(title) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
            }
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            if (busy) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(stringResource(R.string.working), style = MaterialTheme.typography.bodySmall)
            }
            content()
            Spacer(Modifier.height(96.dp))
        }
    }
}

/** Chips for retention presets; when [allowInherit] there is also a "use global" option (null). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RetentionPicker(selectedDays: Int?, allowInherit: Boolean, onSelect: (Int?) -> Unit, modifier: Modifier = Modifier) {
    FlowRow(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (allowInherit) {
            FilterChip(selected = selectedDays == null, onClick = { onSelect(null) }, label = { Text(stringResource(R.string.retention_use_global)) })
        }
        RetentionPolicy.PRESET_DAYS.forEach { d ->
            FilterChip(selected = selectedDays == d, onClick = { onSelect(d) }, label = { Text(retentionLabel(d)) })
        }
    }
}

@Composable
fun retentionLabel(days: Int): String = when (days) {
    0 -> stringResource(R.string.retention_forever)
    365 -> stringResource(R.string.retention_year)
    else -> stringResource(R.string.retention_days, days)
}

// ------------------------------------------------------------------------------------------ hub

@Composable
fun SettingsHomeScreen(
    onPrivacy: () -> Unit,
    onCapture: () -> Unit,
    onStorage: () -> Unit,
    onBackup: () -> Unit,
    onAbout: () -> Unit,
    vm: SettingsViewModel = hiltViewModel(),
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val s = settings ?: return
    SettingsScaffold(stringResource(R.string.settings_title), null, vm) {
        SettingsCard {
            SettingsRow(stringResource(R.string.settings_capture), stringResource(R.string.settings_capture_desc), Icons.Outlined.NotificationsActive, onCapture)
            SettingsRow(stringResource(R.string.settings_privacy), stringResource(R.string.settings_privacy_desc), Icons.Outlined.Security, onPrivacy)
            SettingsRow(stringResource(R.string.settings_storage), stringResource(R.string.settings_storage_desc), Icons.Outlined.Storage, onStorage)
            SettingsRow(stringResource(R.string.settings_backup), stringResource(R.string.settings_backup_desc), Icons.Outlined.Backup, onBackup)
            SettingsRow(stringResource(R.string.settings_about), stringResource(R.string.settings_about_desc), Icons.Outlined.Info, onAbout)
        }
        SectionHeader(stringResource(R.string.settings_appearance))
        SettingsCard {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Palette, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                val modes = listOf(ThemeMode.SYSTEM to R.string.theme_system, ThemeMode.LIGHT to R.string.theme_light, ThemeMode.DARK to R.string.theme_dark)
                SingleChoiceSegmentedButtonRowCompat(modes.map { stringResource(it.second) }, modes.indexOfFirst { it.first == s.themeMode }) { i ->
                    vm.setTheme(modes[i].first)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                SwitchRow(stringResource(R.string.dynamic_color), stringResource(R.string.dynamic_color_desc), s.dynamicColor) { vm.setDynamicColor(it) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SingleChoiceSegmentedButtonRowCompat(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        labels.forEachIndexed { i, label ->
            SegmentedButton(
                selected = i == selected,
                onClick = { onSelect(i) },
                shape = SegmentedButtonDefaults.itemShape(index = i, count = labels.size),
            ) { Text(label) }
        }
    }
}

// ------------------------------------------------------------------------------------------ privacy

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PrivacySettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val pin by vm.pinState.collectAsStateWithLifecycle()
    val s = settings ?: return
    val context = LocalContext.current
    val canLock = remember {
        BiometricManager.from(context).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL,
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }
    val canFingerprint = remember {
        BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }
    var pinDialog by remember { mutableStateOf<PinDialogMode?>(null) }

    SettingsScaffold(stringResource(R.string.settings_privacy), onBack, vm) {
        SectionHeader(stringResource(R.string.pin_section))
        SettingsCard {
            SwitchRow(stringResource(R.string.pin_title), stringResource(R.string.pin_desc), pin.enabled) { on ->
                pinDialog = if (on) PinDialogMode.CREATE else PinDialogMode.DISABLE
            }
            if (pin.enabled) {
                SettingsRow(stringResource(R.string.pin_change), null, Icons.Outlined.Password, onClick = { pinDialog = PinDialogMode.CHANGE })
                SwitchRow(
                    stringResource(R.string.pin_fingerprint),
                    if (canFingerprint) stringResource(R.string.pin_fingerprint_desc) else stringResource(R.string.pin_fingerprint_unavailable),
                    pin.biometric && canFingerprint,
                    enabled = canFingerprint,
                ) { vm.setPinBiometric(it) }
            } else {
                SwitchRow(
                    stringResource(R.string.privacy_lock),
                    if (canLock) stringResource(R.string.privacy_lock_desc) else stringResource(R.string.privacy_lock_unavailable),
                    s.biometricLock && canLock,
                    enabled = canLock,
                ) { vm.setBiometric(it) }
            }
        }
        if (pin.enabled || s.biometricLock) {
            Text(
                stringResource(R.string.auto_lock),
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(top = 14.dp, bottom = 6.dp),
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to R.string.auto_lock_now, 30 to R.string.auto_lock_30s, 60 to R.string.auto_lock_1m, 300 to R.string.auto_lock_5m)
                    .forEach { (sec, label) ->
                        FilterChip(selected = s.autoLockSeconds == sec, onClick = { vm.setAutoLock(sec) }, label = { Text(stringResource(label)) })
                    }
            }
        }
        if (pin.enabled) {
            Spacer(Modifier.height(10.dp))
            InfoCard(stringResource(R.string.pin_forgot_note))
        }

        SectionHeader(stringResource(R.string.settings_privacy))
        SettingsCard {
            SwitchRow(stringResource(R.string.privacy_private_mode), stringResource(R.string.privacy_private_mode_desc), s.privateMode) { vm.setPrivateMode(it) }
            SettingsRow(stringResource(R.string.privacy_encryption), stringResource(R.string.privacy_encryption_desc), Icons.Outlined.Lock)
        }
        SectionHeader(stringResource(R.string.privacy_what_title))
        InfoCard(stringResource(R.string.privacy_what_body))
        SectionHeader(stringResource(R.string.privacy_where_title))
        InfoCard(stringResource(R.string.privacy_where_body))
        Spacer(Modifier.height(12.dp))
        InfoCard(stringResource(R.string.privacy_logs))
    }

    pinDialog?.let { mode ->
        PinDialog(mode = mode, vm = vm, onDone = { pinDialog = null })
    }
}

enum class PinDialogMode { CREATE, CHANGE, DISABLE }

/**
 * CREATE: new PIN + confirm. CHANGE: current PIN, then new PIN + confirm. DISABLE: current PIN.
 */
@Composable
private fun PinDialog(mode: PinDialogMode, vm: SettingsViewModel, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(if (mode == PinDialogMode.CREATE) 1 else 0) }
    var current by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val wrong = stringResource(R.string.pin_wrong)
    val mismatch = stringResource(R.string.pin_mismatch)
    val badFormat = stringResource(R.string.pin_format)
    val lockedText = stringResource(R.string.pin_try_later)

    val title = when (mode) {
        PinDialogMode.CREATE -> R.string.pin_create
        PinDialogMode.CHANGE -> R.string.pin_change
        PinDialogMode.DISABLE -> R.string.pin_turn_off
    }

    fun confirm() {
        error = null
        when (step) {
            0 -> {
                busy = true
                scope.launch {
                    when (vm.verifyPin(current)) {
                        PinManager.VerifyResult.Ok -> {
                            if (mode == PinDialogMode.DISABLE) { vm.disablePin(); onDone() } else step = 1
                        }
                        is PinManager.VerifyResult.Wrong -> error = wrong
                        is PinManager.VerifyResult.LockedOut -> error = lockedText
                    }
                    current = ""
                    busy = false
                }
            }
            1 -> if (PinPolicy.isValidFormat(first)) step = 2 else error = badFormat
            else -> if (first == second) { vm.setPin(first); onDone() } else { error = mismatch; second = "" }
        }
    }

    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(stringResource(title)) },
        text = {
            Column {
                val (label, value, setter) = when (step) {
                    0 -> Triple(R.string.pin_current, current) { v: String -> current = v }
                    1 -> Triple(R.string.pin_new, first) { v: String -> first = v }
                    else -> Triple(R.string.pin_confirm, second) { v: String -> second = v }
                }
                if (step == 1) {
                    Text(stringResource(R.string.pin_format), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = value,
                    onValueChange = { v -> setter(PinPolicy.normalize(v).take(PinPolicy.MAX_LENGTH)) },
                    label = { Text(stringResource(label)) },
                    singleLine = true,
                    isError = error != null,
                    supportingText = if (error != null) {
                        { Text(error.orEmpty()) }
                    } else null,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { confirm() }, enabled = !busy) { Text(stringResource(R.string.action_continue)) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text(stringResource(R.string.action_cancel)) } },
    )
}

// ------------------------------------------------------------------------------------------ capture

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CaptureSettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val rules by vm.rules.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val granted by vm.accessGranted.collectAsStateWithLifecycle()
    val connected by vm.connected.collectAsStateWithLifecycle()
    val lastCapture by vm.lastCaptureAt.collectAsStateWithLifecycle()
    val context = LocalContext.current
    OnResume { vm.refreshAccess() }
    val s = settings ?: return
    var keyword by remember { mutableStateOf("") }
    val waPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            vm.setWhatsAppFolder(uri.toString())
        }
    }

    SettingsScaffold(stringResource(R.string.settings_capture), onBack, vm) {
        CaptureStatusCard(
            state = captureState(granted, connected, s.captureEnabled),
            onOpenAccess = { ListenerStatus.openAccessSettings(context) },
            onResume = { vm.setCapture(true) },
        )
        Spacer(Modifier.height(12.dp))
        SettingsCard {
            SwitchRow(stringResource(R.string.capture_master), stringResource(R.string.capture_master_desc), s.captureEnabled) { vm.setCapture(it) }
            SettingsRow(
                stringResource(R.string.capture_access),
                stringResource(if (granted) R.string.capture_access_granted else R.string.capture_access_missing),
                onClick = { ListenerStatus.openAccessSettings(context) },
            )
        }

        SectionHeader(stringResource(R.string.capture_filters))
        SettingsCard {
            SwitchRow(stringResource(R.string.capture_skip_ongoing), stringResource(R.string.capture_skip_ongoing_desc), s.skipOngoing) { vm.setSkipOngoing(it) }
            SwitchRow(stringResource(R.string.capture_skip_summaries), stringResource(R.string.capture_skip_summaries_desc), s.skipGroupSummaries) { vm.setSkipSummaries(it) }
            SwitchRow(stringResource(R.string.capture_filter_system), stringResource(R.string.capture_filter_system_desc), s.filterSystemNoise) { vm.setFilterSystem(it) }
        }

        SectionHeader(stringResource(R.string.images_section))
        SettingsCard {
            SwitchRow(stringResource(R.string.images_save), stringResource(R.string.images_save_desc), s.saveImages) { vm.setSaveImages(it) }
            val waLinked = s.whatsAppFolderUri != null && vm.isWhatsAppFolderAccessible(s.whatsAppFolderUri)
            SettingsRow(
                stringResource(R.string.wa_folder),
                stringResource(if (waLinked) R.string.wa_folder_linked else R.string.wa_folder_not_linked),
                Icons.Outlined.PhotoLibrary,
                onClick = { waPicker.launch(WhatsAppImporter.INITIAL_FOLDER) },
            )
            if (waLinked) {
                SettingsRow(stringResource(R.string.wa_import_now), null, Icons.Outlined.Sync, onClick = { vm.importWhatsAppNow() })
                SettingsRow(stringResource(R.string.wa_unlink), null, Icons.Outlined.LinkOff, onClick = {
                    s.whatsAppFolderUri?.let { u ->
                        runCatching {
                            context.contentResolver.releasePersistableUriPermission(
                                android.net.Uri.parse(u),
                                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
                            )
                        }
                    }
                    vm.setWhatsAppFolder(null)
                })
            }
        }
        Spacer(Modifier.height(8.dp))
        InfoCard(stringResource(R.string.wa_folder_help))

        SectionHeader(stringResource(R.string.capture_keywords))
        InfoCard(stringResource(R.string.capture_keywords_desc))
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = keyword,
                onValueChange = { keyword = it.take(100) },
                placeholder = { Text(stringResource(R.string.capture_keyword_hint)) },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { vm.addKeyword(keyword); keyword = "" }, enabled = keyword.isNotBlank()) {
                Text(stringResource(R.string.action_add))
            }
        }
        if (rules.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rules.forEach { rule ->
                    InputChip(
                        selected = rule.enabled,
                        onClick = { vm.setRuleEnabled(rule.id, !rule.enabled) },
                        label = { Text(rule.value) },
                        trailingIcon = {
                            Icon(
                                Icons.Outlined.Close,
                                stringResource(R.string.action_delete),
                                modifier = Modifier.size(18.dp).clickable { vm.deleteRule(rule.id) },
                            )
                        },
                    )
                }
            }
        }

        SectionHeader(stringResource(R.string.capture_apps))
        InfoCard(stringResource(R.string.capture_apps_desc))
        Spacer(Modifier.height(8.dp))
        if (apps.isEmpty()) {
            Text(stringResource(R.string.apps_empty_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            SettingsCard {
                apps.forEach { app ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(app.packageName, app.appLabel, size = 34.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.appLabel, style = MaterialTheme.typography.bodyLarge)
                            Text(stringResource(R.string.apps_count, app.total), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = app.captureEnabled, onCheckedChange = { vm.setAppCapture(app.packageName, it) })
                    }
                }
            }
        }

        SectionHeader(stringResource(R.string.capture_diagnostics))
        SettingsCard {
            DiagRow(stringResource(R.string.diag_access), stringResource(if (granted) R.string.yes else R.string.no))
            DiagRow(stringResource(R.string.diag_connected), stringResource(if (connected) R.string.yes else R.string.no))
            DiagRow(stringResource(R.string.diag_last_capture), lastCapture?.let { Formatters.dateTime(it) } ?: stringResource(R.string.diag_never))
            DiagRow(stringResource(R.string.diag_device), "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}")
        }
        Spacer(Modifier.height(8.dp))
        SettingsCard {
            SettingsRow(
                stringResource(R.string.diag_battery),
                stringResource(R.string.diag_battery_desc),
                Icons.Outlined.BatteryAlert,
                onClick = { ListenerStatus.openBatterySettings(context) },
            )
        }
    }
}

@Composable
private fun DiagRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

// ------------------------------------------------------------------------------------------ storage

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StorageSettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val total by vm.total.collectAsStateWithLifecycle()
    val oldest by vm.oldest.collectAsStateWithLifecycle()
    val conversations by vm.conversationCount.collectAsStateWithLifecycle()
    val imageCount by vm.attachmentCount.collectAsStateWithLifecycle()
    val imageBytes by vm.attachmentBytes.collectAsStateWithLifecycle()
    val s = settings ?: return
    val scope = rememberCoroutineScope()
    var olderDays by remember { mutableIntStateOf(30) }
    var olderCount by remember { mutableStateOf<Int?>(null) }
    var confirmAll by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf("") }
    val olderLabel = retentionLabel(olderDays)

    SettingsScaffold(stringResource(R.string.settings_storage), onBack, vm) {
        SettingsCard {
            DiagRow(stringResource(R.string.storage_records), "%,d".format(total))
            DiagRow(stringResource(R.string.storage_conversations), "%,d".format(conversations))
            DiagRow(stringResource(R.string.storage_images), "%,d · %s".format(imageCount, android.text.format.Formatter.formatShortFileSize(LocalContext.current, imageBytes)))
            DiagRow(stringResource(R.string.storage_oldest), oldest?.let { Formatters.date(it) } ?: "—")
        }

        SectionHeader(stringResource(R.string.storage_retention))
        RetentionPicker(selectedDays = s.retentionDays, allowInherit = false, onSelect = { vm.setRetention(it ?: 0) })
        Spacer(Modifier.height(8.dp))
        InfoCard(stringResource(R.string.retention_note))
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.runCleanupNow() }, enabled = s.retentionDays > 0) {
            Text(stringResource(R.string.storage_cleanup_now))
        }

        SectionHeader(stringResource(R.string.storage_bulk))
        Text(stringResource(R.string.storage_delete_older), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(7, 30, 90, 180, 365).forEach { d ->
                AssistChip(
                    onClick = {
                        olderDays = d
                        scope.launch { olderCount = vm.countOlderThan(d) }
                    },
                    label = { Text(retentionLabel(d)) },
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { confirmAll = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Outlined.DeleteSweep, null, tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.storage_delete_all), color = MaterialTheme.colorScheme.error)
        }

        SectionHeader(stringResource(R.string.storage_categories))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newCategory,
                onValueChange = { newCategory = it.take(40) },
                placeholder = { Text(stringResource(R.string.storage_category_hint)) },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { vm.addCategory(newCategory); newCategory = "" }, enabled = newCategory.isNotBlank()) {
                Text(stringResource(R.string.action_add))
            }
        }
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            s.customCategories.sorted().forEach { c ->
                InputChip(
                    selected = false,
                    onClick = {},
                    label = { Text(c) },
                    trailingIcon = {
                        Icon(
                            Icons.Outlined.Close,
                            stringResource(R.string.action_delete),
                            modifier = Modifier.size(18.dp).clickable { vm.removeCategory(c) },
                        )
                    },
                )
            }
        }
    }

    olderCount?.let { count ->
        if (count == 0) {
            AlertDialog(
                onDismissRequest = { olderCount = null },
                title = { Text(stringResource(R.string.storage_bulk)) },
                text = { Text(stringResource(R.string.storage_nothing_to_delete)) },
                confirmButton = { TextButton(onClick = { olderCount = null }) { Text(stringResource(R.string.action_ok)) } },
            )
        } else {
            ConfirmDialog(
                title = stringResource(R.string.confirm_delete_title),
                body = stringResource(R.string.storage_delete_older_confirm, count, olderLabel),
                confirmLabel = stringResource(R.string.action_delete),
                onConfirm = { vm.deleteOlderThan(olderDays) },
                onDismiss = { olderCount = null },
            )
        }
    }
    if (confirmAll) {
        ConfirmDialog(
            title = stringResource(R.string.storage_delete_all),
            body = stringResource(R.string.storage_delete_all_confirm),
            confirmLabel = stringResource(R.string.action_delete),
            onConfirm = { vm.deleteAll() },
            onDismiss = { confirmAll = false },
        )
    }
}

// ------------------------------------------------------------------------------------------ backup

@Composable
fun BackupSettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val history by vm.history.collectAsStateWithLifecycle()
    val total by vm.total.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var showFormat by remember { mutableStateOf(false) }
    var confirmExport by remember { mutableStateOf<ExportFormat?>(null) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var pendingPassword by remember { mutableStateOf<CharArray?>(null) }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var askRestorePassword by remember { mutableStateOf(false) }

    val exportJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.JSON.mime)) { it?.let { u -> vm.exportAll(u, ExportFormat.JSON) } }
    val exportCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.CSV.mime)) { it?.let { u -> vm.exportAll(u, ExportFormat.CSV) } }
    val exportTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.TEXT.mime)) { it?.let { u -> vm.exportAll(u, ExportFormat.TEXT) } }
    val backupPlain = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.backup(uri, null)
    }
    val backupEncrypted = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val pw = pendingPassword
        pendingPassword = null
        if (uri != null && pw != null) vm.backup(uri, pw) else pw?.fill('\u0000')
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                if (vm.isEncrypted(uri)) {
                    restoreUri = uri
                    askRestorePassword = true
                } else {
                    vm.restore(uri, null)
                }
            }
        }
    }

    SettingsScaffold(stringResource(R.string.settings_backup), onBack, vm) {
        SettingsCard {
            SettingsRow(stringResource(R.string.backup_export_all), stringResource(R.string.backup_export_all_desc), Icons.Outlined.FileDownload, onClick = { showFormat = true })
            SettingsRow(stringResource(R.string.backup_create), stringResource(R.string.backup_create_desc), Icons.Outlined.CloudUpload, onClick = { showBackupDialog = true })
            SettingsRow(
                stringResource(R.string.backup_restore),
                stringResource(R.string.backup_restore_desc),
                Icons.Outlined.Restore,
                onClick = { restorePicker.launch(arrayOf("application/json", "application/octet-stream", "text/plain", "*/*")) },
            )
        }
        Spacer(Modifier.height(12.dp))
        InfoCard(stringResource(R.string.backup_password_note))

        SectionHeader(stringResource(R.string.backup_history))
        if (history.isEmpty()) {
            Text(stringResource(R.string.backup_history_empty), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            SettingsCard {
                history.forEach { h ->
                    DiagRow(
                        "${historyTypeLabel(h.type)}${if (h.encrypted) " 🔒" else ""}",
                        "${h.itemCount} · ${Formatters.dateTime(h.createdAt)}",
                    )
                }
            }
        }
    }

    if (showFormat) {
        ExportFormatDialog(onDismiss = { showFormat = false }, onPick = { f -> showFormat = false; confirmExport = f })
    }
    confirmExport?.let { f ->
        ConfirmDialog(
            title = stringResource(R.string.action_export),
            body = stringResource(R.string.backup_confirm_export, total),
            confirmLabel = stringResource(R.string.action_continue),
            destructive = false,
            onConfirm = {
                val name = "notification-vault-${System.currentTimeMillis() / 1000}.${f.extension}"
                when (f) {
                    ExportFormat.JSON -> exportJson.launch(name)
                    ExportFormat.CSV -> exportCsv.launch(name)
                    ExportFormat.TEXT -> exportTxt.launch(name)
                }
            },
            onDismiss = { confirmExport = null },
        )
    }
    if (showBackupDialog) {
        BackupPasswordDialog(
            onDismiss = { showBackupDialog = false },
            onConfirm = { pw ->
                showBackupDialog = false
                val stamp = System.currentTimeMillis() / 1000
                if (pw.isEmpty()) {
                    backupPlain.launch("notification-vault-backup-$stamp.json")
                } else {
                    pendingPassword = pw
                    backupEncrypted.launch("notification-vault-backup-$stamp.nvbak")
                }
            },
        )
    }
    if (askRestorePassword) {
        RestorePasswordDialog(
            onDismiss = { askRestorePassword = false; restoreUri = null },
            onConfirm = { pw ->
                askRestorePassword = false
                restoreUri?.let { vm.restore(it, pw) }
                restoreUri = null
            },
        )
    }
}

@Composable
private fun historyTypeLabel(type: String): String = when {
    type.startsWith("EXPORT") -> stringResource(R.string.action_export) + " " + type.removePrefix("EXPORT_")
    type == "BACKUP" -> stringResource(R.string.backup_create)
    type == "RESTORE" -> stringResource(R.string.backup_restore)
    else -> type
}

@Composable
private fun BackupPasswordDialog(onDismiss: () -> Unit, onConfirm: (CharArray) -> Unit) {
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    val mismatch = pw.isNotEmpty() && pw != pw2
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.backup_create)) },
        text = {
            Column {
                Text(stringResource(R.string.backup_password_note), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it },
                    label = { Text(stringResource(R.string.backup_password)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
                if (pw.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pw2, onValueChange = { pw2 = it },
                        label = { Text(stringResource(R.string.backup_password_confirm)) },
                        singleLine = true,
                        isError = mismatch && pw2.isNotEmpty(),
                        supportingText = if (mismatch && pw2.isNotEmpty()) {
                            { Text(stringResource(R.string.backup_password_mismatch)) }
                        } else null,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(pw.toCharArray()) }, enabled = !mismatch) { Text(stringResource(R.string.action_continue)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

@Composable
private fun RestorePasswordDialog(onDismiss: () -> Unit, onConfirm: (CharArray) -> Unit) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.backup_restore)) },
        text = {
            Column {
                Text(stringResource(R.string.backup_restore_password))
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it },
                    label = { Text(stringResource(R.string.backup_password)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(pw.toCharArray()) }, enabled = pw.isNotEmpty()) { Text(stringResource(R.string.backup_restore)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

// ------------------------------------------------------------------------------------------ about

@Composable
fun AboutScreen(onBack: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    SettingsScaffold(stringResource(R.string.settings_about), onBack, vm) {
        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AppIcon(LocalContext.current.packageName, stringResource(R.string.app_name), size = 72.dp)
            Spacer(Modifier.height(10.dp))
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.about_version, BuildConfig.VERSION_NAME), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.about_tagline), style = MaterialTheme.typography.bodyMedium)
        }
        SectionHeader(stringResource(R.string.about_permissions))
        SettingsCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Bullet(stringResource(R.string.perm_listener))
                Bullet(stringResource(R.string.perm_biometric))
                Bullet(stringResource(R.string.perm_none_internet))
            }
        }
        SectionHeader(stringResource(R.string.about_limitations))
        SettingsCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(R.string.lim_1, R.string.lim_2, R.string.lim_3, R.string.lim_4, R.string.lim_5).forEach { Bullet(stringResource(it)) }
            }
        }
        SectionHeader(stringResource(R.string.about_policy))
        SettingsCard {
            Text(
                stringResource(R.string.privacy_policy_text),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(16.dp),
            )
        }
    }
}

@Composable
private fun Bullet(text: String) {
    Row {
        Text("•  ", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

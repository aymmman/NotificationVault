package com.aymman.notificationvault.domain

/**
 * Recognises the placeholder text messaging apps put in a notification when the sender deletes a
 * message ("This message was deleted"). Only that explicit notice counts as evidence of deletion;
 * nothing is inferred from a notification simply disappearing.
 */
object DeletionDetector {

    /** Lower-case fragments of WhatsApp's deletion notice in common languages. */
    private val PHRASES = listOf(
        "this message was deleted",
        "تم حذف هذه الرسالة",
        "حُذفت هذه الرسالة",
        "this message has been deleted",
        "ce message a été supprimé",
        "este mensaje fue eliminado",
        "se eliminó este mensaje",
        "diese nachricht wurde gelöscht",
        "bu mesaj silindi",
        "questo messaggio è stato eliminato",
        "esta mensagem foi apagada",
        "mensagem apagada",
        "это сообщение удалено",
        "сообщение удалено",
        "این پیام حذف شد",
        "پیغام حذف شد",
        "यह संदेश हटा दिया गया",
        "pesan ini telah dihapus",
        "mesej ini telah dipadam",
        "ข้อความนี้ถูกลบแล้ว",
        "此消息已删除",
        "このメッセージは削除されました",
        "이 메시지는 삭제되었습니다",
    )

    fun isDeletionNotice(text: String?): Boolean {
        if (text.isNullOrBlank() || text.length > 80) return false
        val t = text.lowercase().replace(' ', ' ')
        return PHRASES.any { t.contains(it) }
    }

    /** How far apart the notice's message time and the original's may be to count as the same message. */
    const val MATCH_TOLERANCE_MS = 3_000L
}

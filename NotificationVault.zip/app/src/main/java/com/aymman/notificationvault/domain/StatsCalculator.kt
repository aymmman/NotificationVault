package com.aymman.notificationvault.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Pure aggregation for the statistics screen. */
object StatsCalculator {

    /** Count per local hour of day (index 0..23). */
    fun byHour(timestamps: List<Long>, zone: ZoneId = ZoneId.systemDefault()): IntArray {
        val out = IntArray(24)
        for (t in timestamps) out[Instant.ofEpochMilli(t).atZone(zone).hour]++
        return out
    }

    /** Count per local day for the [days] days ending [today] (oldest first). */
    fun byDay(
        timestamps: List<Long>,
        days: Int,
        today: LocalDate = LocalDate.now(),
        zone: ZoneId = ZoneId.systemDefault(),
    ): List<Pair<LocalDate, Int>> {
        val start = today.minusDays((days - 1).toLong())
        val counts = HashMap<LocalDate, Int>()
        for (t in timestamps) {
            val d = Instant.ofEpochMilli(t).atZone(zone).toLocalDate()
            if (!d.isBefore(start) && !d.isAfter(today)) counts[d] = (counts[d] ?: 0) + 1
        }
        return (0 until days).map { i -> start.plusDays(i.toLong()).let { it to (counts[it] ?: 0) } }
    }

    /** Index of the busiest hour, or -1 when there is no data. */
    fun peakHour(byHour: IntArray): Int {
        var best = -1
        var max = 0
        byHour.forEachIndexed { h, c -> if (c > max) { max = c; best = h } }
        return best
    }
}

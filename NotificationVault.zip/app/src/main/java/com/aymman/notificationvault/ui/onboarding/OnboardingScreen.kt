package com.aymman.notificationvault.ui.onboarding

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.DoNotDisturbOn
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.ToggleOn
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aymman.notificationvault.R
import com.aymman.notificationvault.service.ListenerStatus
import com.aymman.notificationvault.ui.common.AppIcon
import com.aymman.notificationvault.ui.common.OnResume
import com.aymman.notificationvault.ui.theme.LocalVaultExtras
import kotlinx.coroutines.launch

private data class Page(val icon: ImageVector, val title: Int, val body: Int)

private val pages = listOf(
    Page(Icons.Outlined.Shield, R.string.onb_welcome_title, R.string.onb_welcome_body),
    Page(Icons.Outlined.NotificationsActive, R.string.onb_how_title, R.string.onb_how_body),
    Page(Icons.Outlined.DoNotDisturbOn, R.string.onb_limits_title, R.string.onb_limits_body),
    Page(Icons.Outlined.Lock, R.string.onb_privacy_title, R.string.onb_privacy_body),
)

/**
 * Welcome pages followed by the Notification Access setup step.
 * [isAccessGranted] is re-checked every time the user returns from system settings.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(isAccessGranted: () -> Boolean, onFinish: () -> Unit) {
    val total = pages.size + 1
    val pager = rememberPagerState(pageCount = { total })
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var granted by remember { mutableStateOf(isAccessGranted()) }
    OnResume { granted = isAccessGranted() }
    val extras = LocalVaultExtras.current

    Column(
        Modifier
            .fillMaxSize()
            .background(extras.heroBrush)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(context.packageName, stringResource(R.string.app_name), size = 36.dp)
            Spacer(Modifier.width(10.dp))
            Text(stringResource(R.string.app_name), color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (pager.currentPage < total - 1) {
                TextButton(onClick = { scope.launch { pager.animateScrollToPage(total - 1) } }) {
                    Text(stringResource(R.string.action_skip), color = Color.White)
                }
            }
        }

        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { index ->
            if (index < pages.size) {
                InfoPage(pages[index])
            } else {
                AccessPage(granted = granted, onOpen = { ListenerStatus.openAccessSettings(context) })
            }
        }

        // Page indicator
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center) {
            repeat(total) { i ->
                val selected = pager.currentPage == i
                val w by animateDpAsState(if (selected) 22.dp else 8.dp, label = "dot")
                val c by animateColorAsState(if (selected) Color.White else Color.White.copy(alpha = 0.4f), label = "dotColor")
                Box(Modifier.padding(horizontal = 4.dp).height(8.dp).width(w).clip(CircleShape).background(c))
            }
        }

        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp)) {
            val last = pager.currentPage == total - 1
            if (!last) {
                Button(
                    onClick = { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF4C1D95)),
                ) { Text(stringResource(if (pager.currentPage == 0) R.string.action_get_started else R.string.action_next)) }
            } else {
                Column {
                    Button(
                        onClick = { if (granted) onFinish() else ListenerStatus.openAccessSettings(context) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF4C1D95)),
                    ) { Text(stringResource(if (granted) R.string.onb_finish else R.string.action_grant_access)) }
                    if (!granted) {
                        TextButton(onClick = onFinish, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Text(stringResource(R.string.onb_later), color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoPage(page: Page) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(112.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(page.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(56.dp))
        }
        Spacer(Modifier.height(32.dp))
        Text(
            stringResource(page.title),
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            stringResource(page.body),
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.88f),
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 460.dp),
        )
    }
}

@Composable
private fun AccessPage(granted: Boolean, onOpen: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(112.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (granted) Icons.Filled.CheckCircle else Icons.Outlined.ToggleOn,
                contentDescription = null,
                tint = if (granted) Color(0xFF4ADE80) else Color.White,
                modifier = Modifier.size(60.dp),
            )
        }
        Spacer(Modifier.height(32.dp))
        Text(
            stringResource(if (granted) R.string.onb_access_granted else R.string.onb_access_title),
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            stringResource(R.string.onb_access_body),
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.88f),
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 460.dp),
        )
        if (!granted) {
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onOpen) { Text(stringResource(R.string.capture_open_access), color = Color.White) }
        }
    }
}

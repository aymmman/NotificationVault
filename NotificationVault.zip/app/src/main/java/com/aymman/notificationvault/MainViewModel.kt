package com.aymman.notificationvault

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.data.prefs.AppSettings
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.service.ListenerStatus
import com.aymman.notificationvault.data.media.WhatsAppImporter
import com.aymman.notificationvault.data.security.PinManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val settingsRepo: SettingsRepository,
    private val repository: VaultRepository,
    val status: ListenerStatus,
    val pinManager: PinManager,
    private val whatsAppImporter: WhatsAppImporter,
) : ViewModel() {

    /** null until DataStore has been read once (avoids flashing onboarding or unlocked content). */
    val settings: StateFlow<AppSettings?> = settingsRepo.settings
        .map<AppSettings, AppSettings?> { it }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _unlocked = MutableStateFlow(false)
    val unlocked: StateFlow<Boolean> = _unlocked.asStateFlow()

    private var backgroundedAt: Long? = null

    init {
        // Opportunistic retention run (the listener also does this when it connects).
        viewModelScope.launch {
            runCatching {
                val s = settingsRepo.current()
                val now = System.currentTimeMillis()
                if (s.retentionDays > 0 && now - s.lastCleanupAt > TimeUnit.HOURS.toMillis(6)) {
                    repository.applyRetention(s.retentionDays)
                    settingsRepo.setLastCleanupAt(now)
                }
            }
        }
        // Catch up on WhatsApp photos that arrived while the listener couldn't check the folder.
        viewModelScope.launch { runCatching { whatsAppImporter.importRecent(TimeUnit.HOURS.toMillis(24)) } }
    }

    fun onUnlocked() {
        _unlocked.value = true
    }

    fun onBackground() {
        backgroundedAt = SystemClock.elapsedRealtime()
    }

    /** Re-lock if the app was in the background longer than the grace period. */
    fun onForeground() {
        val at = backgroundedAt ?: return
        backgroundedAt = null
        val graceMs = (settings.value?.autoLockSeconds ?: 30) * 1000L
        if (SystemClock.elapsedRealtime() - at >= graceMs) _unlocked.value = false
    }

    fun completeOnboarding() = viewModelScope.launch { settingsRepo.setOnboardingDone(true) }

}

package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.model.CaptureOptions
import com.aymman.notificationvault.domain.model.CapturedRecord
import com.aymman.notificationvault.domain.model.NotificationKind
import com.aymman.notificationvault.domain.model.RawNotification
import java.security.MessageDigest

/**
 * Turns a [RawNotification] into zero or more archive records.
 *
 * Rules:
 *  - MessagingStyle notifications (WhatsApp, Telegram, Signal, SMS…) usually re-post the whole visible
 *    conversation on every new message. Each message becomes its own record whose dedup key is built
 *    from (package, conversation, sender, message time, text), so re-posts never create duplicates
 *    while genuinely new messages are archived.
 *  - Other notifications become a single record keyed by (package, notification key, content), so an
 *    update with identical content is ignored but changed content is kept as a new entry.
 *  - Ongoing/progress notifications and content-less group summaries are skipped (configurable).
 */
object NotificationParser {

    const val MAX_TEXT_LENGTH = 20_000
    const val MAX_TITLE_LENGTH = 500

    fun parse(raw: RawNotification, options: CaptureOptions = CaptureOptions()): List<CapturedRecord> {
        if (raw.packageName.isBlank()) return emptyList()
        if (options.filterSystemNoise && raw.packageName in SYSTEM_NOISE_PACKAGES) return emptyList()
        if (options.skipOngoing && (raw.isOngoing || raw.hasProgress)) return emptyList()

        val kind = KindClassifier.classify(raw.packageName, raw.category, raw.messages.isNotEmpty())
        val records = if (raw.messages.isNotEmpty()) {
            parseMessages(raw, kind)
        } else {
            if (raw.isGroupSummary && options.skipGroupSummaries) return emptyList()
            listOfNotNull(parseSingle(raw, kind))
        }
        return records.filterNot { CaptureFilter.isExcluded(it, options.excludedKeywords) }
    }

    private fun parseMessages(raw: RawNotification, kind: NotificationKind): List<CapturedRecord> {
        val convTitle = raw.conversationTitle.clean(MAX_TITLE_LENGTH)
        val title = raw.title.clean(MAX_TITLE_LENGTH)
        val conversationId = raw.shortcutId.clean(MAX_TITLE_LENGTH) ?: convTitle ?: title
        val seen = HashSet<String>()
        return raw.messages.mapNotNull { msg ->
            val text = msg.text.clean(MAX_TEXT_LENGTH) ?: return@mapNotNull null
            val sender = msg.senderName.clean(MAX_TITLE_LENGTH)
                ?: if (!raw.isGroupConversation) (convTitle ?: title) else null
            val timestamp = if (msg.timestamp > 0) msg.timestamp else raw.postTime
            val key = sha256(
                "m", raw.packageName, conversationId.orEmpty(), sender.orEmpty(), timestamp.toString(), text,
            )
            if (!seen.add(key)) return@mapNotNull null
            CapturedRecord(
                dedupKey = key,
                packageName = raw.packageName,
                notificationKey = raw.key,
                title = convTitle ?: title ?: sender,
                text = text,
                bigText = null,
                subText = raw.subText.clean(MAX_TITLE_LENGTH),
                senderName = sender,
                conversationId = conversationId,
                conversationTitle = convTitle ?: if (!raw.isGroupConversation) sender else title,
                category = raw.category,
                kind = kind,
                originalTimestamp = timestamp,
                isFromMessagingStyle = true,
            )
        }
    }

    private fun parseSingle(raw: RawNotification, kind: NotificationKind): CapturedRecord? {
        val title = raw.title.clean(MAX_TITLE_LENGTH)
        val text = raw.text.clean(MAX_TEXT_LENGTH)
        val lines = raw.textLines.mapNotNull { it.clean(MAX_TEXT_LENGTH) }
        val big = raw.bigText.clean(MAX_TEXT_LENGTH)
            ?: lines.takeIf { it.isNotEmpty() }?.joinToString("\n")?.take(MAX_TEXT_LENGTH)
        val expanded = big?.takeIf { it != text }
        if (title == null && text == null && expanded == null) return null

        val originalTs = if (raw.whenTime > 0) raw.whenTime else raw.postTime
        val key = sha256("n", raw.packageName, raw.key, title.orEmpty(), text.orEmpty(), expanded.orEmpty())
        val looksLikeConversation = kind == NotificationKind.MESSAGE || kind == NotificationKind.EMAIL
        return CapturedRecord(
            dedupKey = key,
            packageName = raw.packageName,
            notificationKey = raw.key,
            title = title,
            text = text ?: expanded,
            bigText = expanded.takeIf { text != null },
            subText = raw.subText.clean(MAX_TITLE_LENGTH),
            senderName = if (looksLikeConversation) title else null,
            conversationId = raw.shortcutId.clean(MAX_TITLE_LENGTH),
            conversationTitle = raw.conversationTitle.clean(MAX_TITLE_LENGTH),
            category = raw.category,
            kind = kind,
            originalTimestamp = originalTs,
            isFromMessagingStyle = false,
        )
    }

    /** Trims, removes control characters (except newlines/tabs) and caps length. Blank -> null. */
    internal fun String?.clean(max: Int): String? {
        if (this == null) return null
        val sb = StringBuilder(minOf(length, max))
        for (ch in this) {
            if (sb.length >= max) break
            if (ch == '\n' || ch == '\t' || !ch.isISOControl()) sb.append(ch)
        }
        val out = sb.toString().trim()
        return out.ifEmpty { null }
    }

    fun sha256(vararg parts: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        parts.forEach {
            md.update(it.toByteArray(Charsets.UTF_8))
            md.update(0x1F.toByte())
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Packages whose notifications are almost always transient system noise. */
    val SYSTEM_NOISE_PACKAGES = setOf(
        "android",
        "com.android.systemui",
        "com.android.providers.downloads",
        "com.android.vending",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.lool",
        "com.miui.securitycenter",
    )
}

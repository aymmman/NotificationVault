package com.aymman.notificationvault.ui.lock

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.security.PinManager
import com.aymman.notificationvault.domain.security.PinPolicy
import com.aymman.notificationvault.ui.theme.LocalVaultExtras
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Full-screen PIN pad shown instead of the archive while locked. No archive data is composed behind it.
 * [onBiometric] is non-null when fingerprint unlock is enabled and available.
 */
@Composable
fun PinLockScreen(
    pinManager: PinManager,
    onUnlocked: () -> Unit,
    onBiometric: (() -> Unit)?,
) {
    val extras = LocalVaultExtras.current
    val scope = rememberCoroutineScope()
    var entered by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    var lockedUntil by remember { mutableLongStateOf(pinManager.lockedUntil()) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val shake = remember { Animatable(0f) }
    val wrongText = stringResource(R.string.pin_wrong)
    val attemptsFormat = stringResource(R.string.pin_attempts_left)

    LaunchedEffect(Unit) { onBiometric?.invoke() }
    LaunchedEffect(lockedUntil) {
        while (lockedUntil > System.currentTimeMillis()) {
            now = System.currentTimeMillis()
            delay(500)
        }
        now = System.currentTimeMillis()
    }
    val locked = lockedUntil > now
    val secondsLeft = ((lockedUntil - now) / 1000).coerceAtLeast(0)

    fun submit() {
        if (checking || entered.length < PinPolicy.MIN_LENGTH) return
        checking = true
        val pin = entered
        scope.launch {
            when (val r = pinManager.verify(pin)) {
                PinManager.VerifyResult.Ok -> onUnlocked()
                is PinManager.VerifyResult.Wrong -> {
                    message = if (r.attemptsBeforeLockout in 1..3) attemptsFormat.format(r.attemptsBeforeLockout) else wrongText
                    shake.animateTo(1f); shake.animateTo(-1f); shake.animateTo(0f)
                }
                is PinManager.VerifyResult.LockedOut -> {
                    message = null
                    lockedUntil = r.untilMillis
                }
            }
            entered = ""
            checking = false
        }
    }

    // Digits are always laid out left-to-right, also in Arabic.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(
            Modifier.fillMaxSize().background(extras.heroBrush).systemBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.pin_enter), style = MaterialTheme.typography.titleLarge, color = Color.White)
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.offset(x = (shake.value * 12).dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                val dots = maxOf(PinPolicy.MIN_LENGTH, entered.length)
                repeat(dots) { i ->
                    val filled = i < entered.length
                    Box(
                        Modifier.size(14.dp).clip(CircleShape)
                            .background(if (filled) Color.White else Color.Transparent)
                            .border(2.dp, Color.White, CircleShape),
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                text = when {
                    locked -> stringResource(R.string.pin_locked_out, secondsLeft)
                    message != null -> message!!
                    else -> " "
                },
                color = Color(0xFFFECACA),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.height(40.dp),
            )
            Spacer(Modifier.height(8.dp))

            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    row.forEach { d ->
                        Key(d, enabled = !locked) { if (entered.length < PinPolicy.MAX_LENGTH) { entered += d; message = null } }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onBiometric != null) {
                    IconKey(Icons.Outlined.Fingerprint, stringResource(R.string.pin_use_fingerprint), enabled = !locked) { onBiometric() }
                } else {
                    Spacer(Modifier.size(72.dp))
                }
                Key("0", enabled = !locked) { if (entered.length < PinPolicy.MAX_LENGTH) { entered += "0"; message = null } }
                IconKey(Icons.AutoMirrored.Outlined.Backspace, stringResource(R.string.pin_delete), enabled = entered.isNotEmpty()) {
                    entered = entered.dropLast(1)
                }
            }
            Spacer(Modifier.height(20.dp))
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(if (entered.length >= PinPolicy.MIN_LENGTH && !locked) Color.White else Color.White.copy(alpha = 0.3f))
                    .clickable(enabled = entered.length >= PinPolicy.MIN_LENGTH && !locked) { submit() }
                    .padding(horizontal = 40.dp, vertical = 14.dp),
            ) {
                Text(stringResource(R.string.action_unlock), color = Color(0xFF4C1D95), fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun Key(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(72.dp).clip(CircleShape)
            .background(Color.White.copy(alpha = if (enabled) 0.14f else 0.06f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun IconKey(icon: ImageVector, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(72.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = Color.White.copy(alpha = if (enabled) 1f else 0.4f), modifier = Modifier.size(30.dp))
    }
}

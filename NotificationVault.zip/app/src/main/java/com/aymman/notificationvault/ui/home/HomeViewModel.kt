package com.aymman.notificationvault.ui.home

import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.AppSummary
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.service.ListenerStatus
import com.aymman.notificationvault.ui.common.BaseArchiveViewModel
import com.aymman.notificationvault.ui.common.CaptureState
import com.aymman.notificationvault.ui.common.Formatters
import com.aymman.notificationvault.ui.common.captureState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeStats(
    val total: Int = 0,
    val today: Int = 0,
    val todayApps: Int = 0,
    val unread: Int = 0,
    val monitoredApps: Int = 0,
    val saved: Int = 0,
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HomeViewModel @Inject constructor(
    repository: VaultRepository,
    backupManager: BackupManager,
    private val status: ListenerStatus,
    private val settings: SettingsRepository,
) : BaseArchiveViewModel(repository, backupManager) {

    private val todayStart = MutableStateFlow(Formatters.startOfToday())
    private val accessGranted = MutableStateFlow(status.isAccessGranted())

    val stats: StateFlow<HomeStats> = todayStart.flatMapLatest { since ->
        val counts = combine(
            repository.observeTotal(),
            repository.observeSince(since),
            repository.observeAppsSince(since),
            repository.observeUnread(),
        ) { total, today, todayApps, unread -> HomeStats(total, today, todayApps, unread) }
        combine(counts, repository.observeMonitoredCount(), repository.observeSavedCount()) { s, apps, saved ->
            s.copy(monitoredApps = apps, saved = saved)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeStats())

    val deletedCount: StateFlow<Int> = repository.observeDeletedCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val groupSimilar: StateFlow<Boolean> = settings.settings.map { it.groupSimilar }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    val recent: StateFlow<List<NotificationRow>?> =
        repository.observeRows(SearchFilters(), hideMuted = true, limit = 15)
            .map<List<NotificationRow>, List<NotificationRow>?> { it }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val topApps: StateFlow<List<AppSummary>> = repository.observeAppSummaries()
        .map { list -> list.filter { it.total > 0 && !it.muted }.sortedByDescending { it.total }.take(10) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val captureState: StateFlow<CaptureState> = combine(
        accessGranted,
        status.connected,
        settings.settings.map { it.captureEnabled },
    ) { granted, connected, enabled -> captureState(granted, connected, enabled) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CaptureState.ACTIVE)

    /** Called on every resume: the user may have changed access in system settings, or the day rolled over. */
    fun refresh() {
        accessGranted.value = status.isAccessGranted()
        todayStart.value = Formatters.startOfToday()
    }

    fun resumeCapture() = viewModelScope.launch { settings.setCaptureEnabled(true) }

    fun markAllRead() = viewModelScope.launch { repository.markAllRead() }
}

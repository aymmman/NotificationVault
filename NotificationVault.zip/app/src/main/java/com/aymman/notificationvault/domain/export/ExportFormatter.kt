package com.aymman.notificationvault.domain.export

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class ExportFormat(val mime: String, val extension: String) {
    JSON("application/json", "json"),
    CSV("text/csv", "csv"),
    TEXT("text/plain", "txt"),
}

/** Converts export rows into file content. Pure: no Android dependencies. */
object ExportFormatter {

    val CSV_HEADER = listOf(
        "received_at", "original_time", "app", "package", "sender", "conversation", "title", "text",
        "expanded_text", "category", "kind", "user_category", "pinned", "bookmarked",
    )

    fun csv(records: List<ExportRecord>, tz: TimeZone = TimeZone.getDefault()): String {
        val fmt = isoFormat(tz)
        return CsvWriter.write(
            CSV_HEADER,
            records.map { r ->
                listOf(
                    fmt.format(Date(r.receivedAt)), fmt.format(Date(r.originalTimestamp)), r.app, r.packageName,
                    r.sender, r.conversation, r.title, r.text, r.expandedText, r.category, r.kind, r.userCategory,
                    r.pinned.toString(), r.bookmarked.toString(),
                )
            },
        )
    }

    fun text(records: List<ExportRecord>, tz: TimeZone = TimeZone.getDefault()): String {
        val fmt = isoFormat(tz)
        return buildString {
            append("Notification Vault export — ").append(records.size).append(" record(s)\n")
            append("Content archived from notifications; it may differ from the original message.\n")
            append("========================================\n\n")
            records.forEach { r ->
                append('[').append(fmt.format(Date(r.receivedAt))).append("] ").append(r.app).append('\n')
                val who = r.sender ?: r.title
                if (!who.isNullOrBlank()) append(who).append('\n')
                if (!r.title.isNullOrBlank() && r.title != who) append(r.title).append('\n')
                r.text?.let { append(it).append('\n') }
                r.expandedText?.let { append(it).append('\n') }
                append("----------------------------------------\n")
            }
        }
    }

    private fun isoFormat(tz: TimeZone) = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = tz }
}

package com.aymman.notificationvault.ui.apps

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.ConversationCount
import com.aymman.notificationvault.data.db.MonitoredAppEntity
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.domain.model.SortOrder
import com.aymman.notificationvault.ui.common.AppIcon
import com.aymman.notificationvault.ui.common.ArchiveList
import com.aymman.notificationvault.ui.common.BaseArchiveViewModel
import com.aymman.notificationvault.ui.common.ConfirmDialog
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.SelectionActions
import com.aymman.notificationvault.ui.common.SelectionTopBar
import com.aymman.notificationvault.ui.common.SwitchRow
import com.aymman.notificationvault.ui.common.UiMessage
import com.aymman.notificationvault.ui.common.rememberSelection
import com.aymman.notificationvault.ui.common.resolve
import com.aymman.notificationvault.ui.inbox.SortMenu
import com.aymman.notificationvault.ui.settings.RetentionPicker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class AppArchiveViewModel @Inject constructor(
    repository: VaultRepository,
    backupManager: BackupManager,
    savedState: SavedStateHandle,
) : BaseArchiveViewModel(repository, backupManager) {

    val packageName: String = checkNotNull(savedState.get<String>("pkg"))

    private val _filters = MutableStateFlow(SearchFilters(packageName = packageName))
    val filters: StateFlow<SearchFilters> = _filters.asStateFlow()

    val rows: StateFlow<List<NotificationRow>?> = _filters
        .flatMapLatest { repository.observeRows(it) }
        .map<List<NotificationRow>, List<NotificationRow>?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val app: StateFlow<MonitoredAppEntity?> = repository.observeApp(packageName)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val conversations: StateFlow<List<ConversationCount>> = repository.observeConversations(packageName)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(q: String) = _filters.update { it.copy(query = q) }
    fun setConversation(id: String?) = _filters.update { it.copy(conversationId = id) }
    fun setSort(sort: SortOrder) = _filters.update { it.copy(sort = sort) }

    fun markAllRead() = viewModelScope.launch { repository.markAppRead(packageName) }
    fun setCapture(v: Boolean) = viewModelScope.launch { repository.setAppCaptureEnabled(packageName, v) }
    fun setMuted(v: Boolean) = viewModelScope.launch { repository.setAppMuted(packageName, v) }
    fun setFavorite(v: Boolean) = viewModelScope.launch { repository.setAppFavorite(packageName, v) }
    fun setRetention(days: Int?) = viewModelScope.launch { repository.setAppRetention(packageName, days) }
    fun deleteAll() = viewModelScope.launch {
        val n = repository.deleteForApp(packageName)
        emit(UiMessage(R.string.deleted_count, listOf(n)))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppArchiveScreen(
    onBack: () -> Unit,
    onOpenDetail: (Long) -> Unit,
    onOpenChat: (pkg: String, conversationId: String) -> Unit = { _, _ -> },
    vm: AppArchiveViewModel = hiltViewModel(),
) {
    val rows by vm.rows.collectAsStateWithLifecycle()
    val filters by vm.filters.collectAsStateWithLifecycle()
    val app by vm.app.collectAsStateWithLifecycle()
    val conversations by vm.conversations.collectAsStateWithLifecycle()
    val selection = rememberSelection()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it.resolve(context)) } }
    LaunchedEffect(rows) { rows?.let { list -> selection.retain(list.map { it.n.id }.toSet()) } }

    val label = app?.appLabel ?: vm.packageName

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selection.active) {
                SelectionTopBar(selection.selected.size, onClear = selection::clear) {
                    SelectionActions(rows.orEmpty(), selection, vm)
                }
            } else {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.action_back))
                        }
                    },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(vm.packageName, label, size = 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    },
                    actions = {
                        filters.conversationId?.let { conv ->
                            IconButton(onClick = { onOpenChat(vm.packageName, conv) }) {
                                Icon(Icons.AutoMirrored.Outlined.Chat, stringResource(R.string.chat_open))
                            }
                        }
                        IconButton(onClick = { showSearch = !showSearch; if (!showSearch) vm.setQuery("") }) {
                            Icon(Icons.Outlined.Search, stringResource(R.string.action_search))
                        }
                        IconButton(onClick = { vm.markAllRead() }) {
                            Icon(Icons.Filled.DoneAll, stringResource(R.string.action_mark_all_read))
                        }
                        SortMenu(filters.sort, vm::setSort)
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Outlined.Tune, stringResource(R.string.app_settings))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (showSearch) {
                OutlinedTextField(
                    value = filters.query,
                    onValueChange = vm::setQuery,
                    placeholder = { Text(stringResource(R.string.search_in_app, label)) },
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    singleLine = true,
                    shape = CircleShape,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
            if (conversations.size > 1) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = filters.conversationId == null,
                        onClick = { vm.setConversation(null) },
                        label = { Text(stringResource(R.string.all_conversations)) },
                    )
                    conversations.forEach { c ->
                        FilterChip(
                            selected = filters.conversationId == c.conversationId,
                            onClick = { vm.setConversation(if (filters.conversationId == c.conversationId) null else c.conversationId) },
                            label = { Text("${c.title ?: c.conversationId} · ${c.count}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        )
                    }
                }
            }
            val list = rows
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                ArchiveList(
                    rows = list,
                    selection = selection,
                    showApp = false,
                    byDay = filters.sort == SortOrder.NEWEST || filters.sort == SortOrder.OLDEST,
                    onOpen = onOpenDetail,
                    empty = { EmptyState(stringResource(R.string.inbox_empty_title), stringResource(R.string.inbox_empty_body)) },
                )
            }
        }
    }

    if (showSettings) {
        AppSettingsSheet(
            app = app,
            label = label,
            onDismiss = { showSettings = false },
            vm = vm,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppSettingsSheet(app: MonitoredAppEntity?, label: String, onDismiss: () -> Unit, vm: AppArchiveViewModel) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var confirmDelete by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = 16.dp)) {
            Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(vm.packageName, label, size = 40.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(label, style = MaterialTheme.typography.titleMedium)
                    Text(vm.packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (app != null) {
                SwitchRow(stringResource(R.string.app_capture_toggle), stringResource(R.string.app_capture_toggle_desc), app.captureEnabled) { vm.setCapture(it) }
                SwitchRow(stringResource(R.string.app_mute_toggle), stringResource(R.string.app_mute_toggle_desc), app.muted) { vm.setMuted(it) }
                SwitchRow(stringResource(R.string.app_favorite_toggle), null, app.favorite) { vm.setFavorite(it) }
                Text(
                    stringResource(R.string.app_retention),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
                )
                RetentionPicker(selectedDays = app.retentionDays, allowInherit = true, onSelect = { vm.setRetention(it) }, modifier = Modifier.padding(horizontal = 12.dp))
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = { confirmDelete = true },
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            ) {
                Text(stringResource(R.string.app_delete_all), color = MaterialTheme.colorScheme.error)
            }
        }
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            body = stringResource(R.string.app_delete_all_confirm, label),
            confirmLabel = stringResource(R.string.action_delete),
            onConfirm = { vm.deleteAll(); onDismiss() },
            onDismiss = { confirmDelete = false },
        )
    }
}

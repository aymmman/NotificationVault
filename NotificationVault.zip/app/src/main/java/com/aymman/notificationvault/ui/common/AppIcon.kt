package com.aymman.notificationvault.ui.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aymman.notificationvault.util.AppInfoResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

val LocalAppInfo = staticCompositionLocalOf<AppInfoResolver?> { null }

private val fallbackPalette = listOf(
    Color(0xFF7C3AED), Color(0xFF2563EB), Color(0xFF059669), Color(0xFFDB2777),
    Color(0xFFD97706), Color(0xFF0891B2), Color(0xFF4F46E5), Color(0xFFDC2626),
)

/** The real launcher icon of [packageName], or a coloured monogram when it isn't available. */
@Composable
fun AppIcon(packageName: String, label: String?, modifier: Modifier = Modifier, size: Dp = 40.dp) {
    val resolver = LocalAppInfo.current
    val px = with(LocalDensity.current) { size.roundToPx() }
    val icon by produceState<ImageBitmap?>(initialValue = null, packageName, px) {
        value = resolver?.let { r -> withContext(Dispatchers.IO) { r.icon(packageName, px) } }
    }
    val bmp = icon
    if (bmp != null) {
        Image(
            bitmap = bmp,
            contentDescription = label,
            modifier = modifier.size(size).clip(RoundedCornerShape(size * 0.28f)),
        )
    } else {
        Monogram(text = label ?: packageName, seed = packageName, modifier = modifier, size = size)
    }
}

@Composable
fun Monogram(text: String, seed: String, modifier: Modifier = Modifier, size: Dp = 40.dp) {
    val color = remember(seed) { fallbackPalette[abs(seed.hashCode()) % fallbackPalette.size] }
    val letter = text.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    Box(
        modifier = modifier.size(size).clip(CircleShape).background(color.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = letter,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp,
            style = MaterialTheme.typography.titleMedium,
        )
    }
}

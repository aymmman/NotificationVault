package com.aymman.notificationvault.ui.detail

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.OpenInNew
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.automirrored.outlined.Label
import androidx.compose.material.icons.outlined.MarkEmailRead
import androidx.compose.material.icons.outlined.MarkEmailUnread
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.db.AttachmentEntity
import com.aymman.notificationvault.data.media.AttachmentStore
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.ui.common.AppIcon
import com.aymman.notificationvault.ui.common.BackTopBar
import com.aymman.notificationvault.ui.common.ConfirmDialog
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.Formatters
import com.aymman.notificationvault.ui.common.InfoCard
import com.aymman.notificationvault.ui.common.LocalAppInfo
import com.aymman.notificationvault.ui.common.Pill
import com.aymman.notificationvault.ui.common.body
import com.aymman.notificationvault.ui.common.headline
import com.aymman.notificationvault.ui.common.kind
import com.aymman.notificationvault.ui.common.kindLabel
import com.aymman.notificationvault.ui.common.shareRows
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.abs

sealed interface DetailState {
    data object Loading : DetailState
    data object Missing : DetailState
    data class Loaded(val row: NotificationRow) : DetailState
}

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val repository: VaultRepository,
    private val store: AttachmentStore,
    @ApplicationContext private val appContext: Context,
    settings: SettingsRepository,
    savedState: SavedStateHandle,
) : ViewModel() {
    val id: Long = checkNotNull(savedState.get<Long>("id"))
    private var markedRead = false

    val state: StateFlow<DetailState> = repository.observeRow(id)
        .map { row -> if (row == null) DetailState.Missing else DetailState.Loaded(row) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DetailState.Loading)

    val categories: StateFlow<List<String>> = settings.settings.map { it.customCategories.sorted() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Opening a record marks it read once; the user can mark it unread again. */
    fun onShown(row: NotificationRow) {
        if (!markedRead && !row.n.isRead) {
            markedRead = true
            viewModelScope.launch { repository.setRead(listOf(id), true) }
        } else {
            markedRead = true
        }
    }

    fun setRead(v: Boolean) = viewModelScope.launch { repository.setRead(listOf(id), v) }
    fun setPinned(v: Boolean) = viewModelScope.launch { repository.setPinned(listOf(id), v) }
    fun setBookmarked(v: Boolean) = viewModelScope.launch { repository.setBookmarked(listOf(id), v) }
    fun setCategory(c: String?) = viewModelScope.launch { repository.setUserCategory(listOf(id), c) }
    fun delete(after: () -> Unit) = viewModelScope.launch { repository.delete(listOf(id)); after() }

    val attachments: StateFlow<List<AttachmentEntity>> = repository.observeAttachments(id)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    suspend fun loadBitmap(a: AttachmentEntity, maxPx: Int): Bitmap? =
        withContext(Dispatchers.IO) { runCatching { store.loadBitmap(a.fileName, maxPx) }.getOrNull() }

    /** Writes the decrypted file to a location the user chose. */
    fun saveImage(a: AttachmentEntity, uri: Uri, onResult: (Boolean) -> Unit) = viewModelScope.launch {
        val ok = withContext(Dispatchers.IO) {
            runCatching {
                appContext.contentResolver.openOutputStream(uri, "wt")?.use { store.decryptTo(a.fileName, it) } ?: false
            }.getOrDefault(false)
        }
        onResult(ok)
    }

    /** Decrypts a voice note / video to private cache for playback (deleted when the player closes). */
    suspend fun prepareMedia(a: AttachmentEntity): java.io.File? =
        withContext(Dispatchers.IO) { store.decryptToCache(a.fileName, AttachmentStore.extensionFor(a.mimeType)) }
}

@Composable
fun DetailScreen(
    onBack: () -> Unit,
    onOpenChat: (pkg: String, conversationId: String) -> Unit = { _, _ -> },
    vm: DetailViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val attachments by vm.attachments.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var pendingSave by remember { mutableStateOf<AttachmentEntity?>(null) }
    val savedMsg = stringResource(R.string.image_saved_to_file)
    val failedMsg = stringResource(R.string.operation_failed)
    val onPicked: (Uri?) -> Unit = { uri ->
        val a = pendingSave
        pendingSave = null
        if (uri != null && a != null) {
            vm.saveImage(a, uri) { ok -> Toast.makeText(context, if (ok) savedMsg else failedMsg, Toast.LENGTH_SHORT).show() }
        }
    }
    val saveJpeg = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg"), onPicked)
    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png"), onPicked)
    val saveWebp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/webp"), onPicked)
    val saveVideo = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4"), onPicked)
    val saveAudio = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/ogg"), onPicked)
    val requestSave: (AttachmentEntity) -> Unit = { a ->
        pendingSave = a
        val stamp = System.currentTimeMillis() / 1000
        when (a.mimeType) {
            "image/png" -> savePng.launch("vault-image-$stamp.png")
            "image/webp" -> saveWebp.launch("vault-image-$stamp.webp")
            else -> when {
                a.mimeType.startsWith("video/") -> saveVideo.launch("vault-video-$stamp.mp4")
                a.mimeType.startsWith("audio/") || a.mimeType == "application/ogg" ->
                    saveAudio.launch("vault-voice-$stamp." + AttachmentStore.extensionFor(a.mimeType))
                else -> saveJpeg.launch("vault-image-$stamp.jpg")
            }
        }
    }
    var confirmDelete by remember { mutableStateOf(false) }
    var pickCategory by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            BackTopBar(stringResource(R.string.detail_title), onBack) {
                val s = state
                if (s is DetailState.Loaded) {
                    val n = s.row.n
                    IconButton(onClick = { vm.setPinned(!n.isPinned) }) {
                        Icon(
                            if (n.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            stringResource(if (n.isPinned) R.string.action_unpin else R.string.action_pin),
                            tint = if (n.isPinned) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { vm.setBookmarked(!n.isBookmarked) }) {
                        Icon(
                            if (n.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            stringResource(if (n.isBookmarked) R.string.action_remove_bookmark else R.string.action_bookmark),
                            tint = if (n.isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Outlined.Delete, stringResource(R.string.action_delete))
                    }
                }
            }
        },
    ) { padding ->
        when (val s = state) {
            DetailState.Loading -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            DetailState.Missing -> EmptyState(
                stringResource(R.string.detail_title),
                stringResource(R.string.detail_not_found),
                modifier = Modifier.padding(padding),
            )
            is DetailState.Loaded -> {
                LaunchedEffect(s.row.n.id) { vm.onShown(s.row) }
                DetailContent(
                    row = s.row,
                    modifier = Modifier.padding(padding),
                    onCopy = { copy(context, s.row) },
                    onShare = { shareRows(context, listOf(s.row)) },
                    onToggleRead = { vm.setRead(!s.row.n.isRead) },
                    onCategory = { pickCategory = true },
                    onOpenChat = s.row.n.conversationId?.let { conv -> { onOpenChat(s.row.n.packageName, conv) } },
                    images = {
                        if (attachments.isNotEmpty()) {
                            AttachmentGallery(attachments, load = vm::loadBitmap, prepare = vm::prepareMedia, onSave = requestSave)
                        }
                    },
                )
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            body = stringResource(R.string.confirm_delete_body, 1),
            confirmLabel = stringResource(R.string.action_delete),
            onConfirm = { vm.delete(onBack) },
            onDismiss = { confirmDelete = false },
        )
    }
    if (pickCategory) {
        val current = (state as? DetailState.Loaded)?.row?.n?.userCategory
        AlertDialog(
            onDismissRequest = { pickCategory = false },
            title = { Text(stringResource(R.string.detail_assign_category)) },
            text = {
                Column {
                    if (categories.isEmpty()) {
                        Text(stringResource(R.string.detail_no_categories_yet), style = MaterialTheme.typography.bodyMedium)
                    }
                    (listOf<String?>(null) + categories).forEach { c ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            RadioButton(selected = c == current, onClick = { vm.setCategory(c); pickCategory = false })
                            Text(c ?: stringResource(R.string.detail_no_category))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickCategory = false }) { Text(stringResource(R.string.action_close)) } },
        )
    }
}

@Composable
private fun DetailContent(
    row: NotificationRow,
    modifier: Modifier,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onToggleRead: () -> Unit,
    onCategory: () -> Unit,
    onOpenChat: (() -> Unit)? = null,
    images: @Composable () -> Unit = {},
) {
    val n = row.n
    val appInfo = LocalAppInfo.current
    val context = LocalContext.current
    val appLabel = row.appLabel ?: n.packageName
    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        // Header: app + sender
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(n.packageName, appLabel, size = 52.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(row.headline(), style = MaterialTheme.typography.titleLarge)
                Text(
                    "$appLabel · ${Formatters.dateTime(n.receivedAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill(stringResource(R.string.label_archived_from_notification), MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
            Pill(kindLabel(row.kind()))
            n.userCategory?.let { Pill(it, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer) }
        }
        Spacer(Modifier.height(14.dp))

        n.deletedAt?.let { at ->
            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        "🗑️ " + stringResource(R.string.detail_deleted_title),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    Text(
                        stringResource(R.string.detail_deleted_body, Formatters.dateTime(at)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        images()

        // The archived text itself (selectable)
        Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
            SelectionContainer {
                Column(Modifier.padding(18.dp)) {
                    if (n.title != null && n.title != row.headline()) {
                        Text(n.title, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                    }
                    Text(row.body(), style = MaterialTheme.typography.bodyLarge)
                    n.bigText?.let { big ->
                        Spacer(Modifier.height(10.dp))
                        Text(big, style = MaterialTheme.typography.bodyLarge)
                    }
                    n.subText?.let { sub ->
                        Spacer(Modifier.height(10.dp))
                        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            FilledTonalButton(onClick = onCopy, modifier = Modifier.weight(1f)) {
                Icon(Icons.Outlined.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.action_copy))
            }
            FilledTonalButton(onClick = onShare, modifier = Modifier.weight(1f)) {
                Icon(Icons.Outlined.Share, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.action_share))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = onToggleRead, modifier = Modifier.weight(1f)) {
                Icon(if (n.isRead) Icons.Outlined.MarkEmailUnread else Icons.Outlined.MarkEmailRead, null)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(if (n.isRead) R.string.action_mark_unread else R.string.action_mark_read))
            }
            OutlinedButton(onClick = onCategory, modifier = Modifier.weight(1f)) {
                Icon(Icons.AutoMirrored.Outlined.Label, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.detail_assign_category))
            }
        }

        if (onOpenChat != null) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenChat, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.AutoMirrored.Outlined.Chat, null)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.chat_open))
            }
        }

        Spacer(Modifier.height(16.dp))
        Surface(color = MaterialTheme.colorScheme.surfaceContainerLowest, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 6.dp)) {
                MetaRow(stringResource(R.string.detail_app), appLabel)
                n.senderName?.let { MetaRow(stringResource(R.string.detail_sender), it) }
                n.conversationTitle?.let { if (it != n.senderName) MetaRow(stringResource(R.string.detail_conversation), it) }
                MetaRow(stringResource(R.string.detail_received), Formatters.dateTime(n.receivedAt))
                if (abs(n.originalTimestamp - n.receivedAt) > 60_000) {
                    MetaRow(stringResource(R.string.detail_original_time), Formatters.dateTime(n.originalTimestamp))
                }
                MetaRow(
                    stringResource(R.string.detail_shade_status),
                    n.removedAt?.let { stringResource(R.string.detail_removed_at, Formatters.dateTime(it)) }
                        ?: stringResource(R.string.detail_unknown_removed),
                )
                n.category?.let { MetaRow(stringResource(R.string.detail_category), it) }
                MetaRow(stringResource(R.string.detail_kind), kindLabel(row.kind()))
                MetaRow(stringResource(R.string.detail_user_category), n.userCategory ?: stringResource(R.string.detail_no_category))
            }
        }

        Spacer(Modifier.height(12.dp))
        InfoCard(stringResource(R.string.detail_limitations), icon = Icons.Outlined.Info)

        val canOpen = appInfo?.launchIntent(n.packageName) != null
        if (canOpen) {
            Spacer(Modifier.height(12.dp))
            TextButton(
                onClick = {
                    appInfo?.launchIntent(n.packageName)?.let {
                        try { context.startActivity(it) } catch (e: Exception) { /* app gone */ }
                    }
                },
            ) {
                Icon(Icons.AutoMirrored.Outlined.OpenInNew, null)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.action_open_app_named, appLabel))
            }
            Text(
                stringResource(R.string.detail_open_app_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun MetaRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.4f),
        )
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(0.6f))
    }
    HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
}

private fun copy(context: Context, row: NotificationRow) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val text = listOfNotNull(row.n.text ?: row.n.title, row.n.bigText).joinToString("\n")
    val clip = ClipData.newPlainText("notification", text)
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
        // Mark as sensitive so Android 13+ doesn't preview it in the clipboard overlay.
        clip.description.extras = android.os.PersistableBundle().apply {
            putBoolean("android.content.extra.IS_SENSITIVE", true)
        }
    }
    cm.setPrimaryClip(clip)
    if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.TIRAMISU) {
        Toast.makeText(context, R.string.copied, Toast.LENGTH_SHORT).show()
    }
}

package com.aymman.notificationvault.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val onboardingDone: Boolean = false,
    val captureEnabled: Boolean = true,
    val skipOngoing: Boolean = true,
    val skipGroupSummaries: Boolean = true,
    val filterSystemNoise: Boolean = true,
    val retentionDays: Int = 0,
    val biometricLock: Boolean = false,
    val privateMode: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = false,
    val customCategories: Set<String> = emptySet(),
    val lastCleanupAt: Long = 0L,
    /** Save pictures that notifications carry (previews). */
    val saveImages: Boolean = true,
    /** SAF tree URI of the WhatsApp images folder the user granted, or null. */
    val whatsAppFolderUri: String? = null,
    /** Re-lock after the app has been in the background this long (0 = immediately). */
    val autoLockSeconds: Int = 30,
    /** Post an alert when a sender deletes a message. */
    val deletionAlerts: Boolean = true,
    /** Include the deleted message's text in that alert (hidden on the lock screen either way). */
    val alertShowText: Boolean = true,
    /** Evening summary notification. */
    val dailySummary: Boolean = true,
    /** Local hour (0-23) for the summary. */
    val summaryHour: Int = 21,
    /** Collapse runs of similar non-message notifications in lists. */
    val groupSimilar: Boolean = true,
    /** Also copy WhatsApp voice notes and videos when the folder is linked. */
    val saveWhatsAppMedia: Boolean = true,
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** User preferences stored with Jetpack DataStore (app-private, never contains notification content). */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val CAPTURE = booleanPreferencesKey("capture_enabled")
        val SKIP_ONGOING = booleanPreferencesKey("skip_ongoing")
        val SKIP_SUMMARIES = booleanPreferencesKey("skip_group_summaries")
        val FILTER_SYSTEM = booleanPreferencesKey("filter_system_noise")
        val RETENTION = intPreferencesKey("retention_days")
        val BIOMETRIC = booleanPreferencesKey("biometric_lock")
        val PRIVATE = booleanPreferencesKey("private_mode")
        val THEME = stringPreferencesKey("theme_mode")
        val DYNAMIC = booleanPreferencesKey("dynamic_color")
        val CATEGORIES = stringSetPreferencesKey("custom_categories")
        val LAST_CLEANUP = longPreferencesKey("last_cleanup_at")
        val SAVE_IMAGES = booleanPreferencesKey("save_images")
        val WA_FOLDER = stringPreferencesKey("whatsapp_folder_uri")
        val AUTO_LOCK = intPreferencesKey("auto_lock_seconds")
        val DELETION_ALERTS = booleanPreferencesKey("deletion_alerts")
        val ALERT_TEXT = booleanPreferencesKey("alert_show_text")
        val DAILY_SUMMARY = booleanPreferencesKey("daily_summary")
        val SUMMARY_HOUR = intPreferencesKey("summary_hour")
        val GROUP_SIMILAR = booleanPreferencesKey("group_similar")
        val WA_MEDIA = booleanPreferencesKey("save_whatsapp_media")
        val NOTIF_PERMISSION_ASKED = booleanPreferencesKey("notif_permission_asked")
    }

    val settings: Flow<AppSettings> = context.dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            AppSettings(
                onboardingDone = p[Keys.ONBOARDING] ?: false,
                captureEnabled = p[Keys.CAPTURE] ?: true,
                skipOngoing = p[Keys.SKIP_ONGOING] ?: true,
                skipGroupSummaries = p[Keys.SKIP_SUMMARIES] ?: true,
                filterSystemNoise = p[Keys.FILTER_SYSTEM] ?: true,
                retentionDays = p[Keys.RETENTION] ?: 0,
                biometricLock = p[Keys.BIOMETRIC] ?: false,
                privateMode = p[Keys.PRIVATE] ?: false,
                themeMode = p[Keys.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
                dynamicColor = p[Keys.DYNAMIC] ?: false,
                customCategories = p[Keys.CATEGORIES] ?: emptySet(),
                lastCleanupAt = p[Keys.LAST_CLEANUP] ?: 0L,
                saveImages = p[Keys.SAVE_IMAGES] ?: true,
                whatsAppFolderUri = p[Keys.WA_FOLDER],
                autoLockSeconds = p[Keys.AUTO_LOCK] ?: 30,
                deletionAlerts = p[Keys.DELETION_ALERTS] ?: true,
                alertShowText = p[Keys.ALERT_TEXT] ?: true,
                dailySummary = p[Keys.DAILY_SUMMARY] ?: true,
                summaryHour = p[Keys.SUMMARY_HOUR] ?: 21,
                groupSimilar = p[Keys.GROUP_SIMILAR] ?: true,
                saveWhatsAppMedia = p[Keys.WA_MEDIA] ?: true,
            )
        }

    suspend fun current(): AppSettings = settings.first()

    suspend fun setOnboardingDone(v: Boolean) = put(Keys.ONBOARDING, v)
    suspend fun setCaptureEnabled(v: Boolean) = put(Keys.CAPTURE, v)
    suspend fun setSkipOngoing(v: Boolean) = put(Keys.SKIP_ONGOING, v)
    suspend fun setSkipGroupSummaries(v: Boolean) = put(Keys.SKIP_SUMMARIES, v)
    suspend fun setFilterSystemNoise(v: Boolean) = put(Keys.FILTER_SYSTEM, v)
    suspend fun setRetentionDays(v: Int) = put(Keys.RETENTION, v.coerceAtLeast(0))
    suspend fun setBiometricLock(v: Boolean) = put(Keys.BIOMETRIC, v)
    suspend fun setPrivateMode(v: Boolean) = put(Keys.PRIVATE, v)
    suspend fun setThemeMode(v: ThemeMode) = put(Keys.THEME, v.name)
    suspend fun setDynamicColor(v: Boolean) = put(Keys.DYNAMIC, v)
    suspend fun setLastCleanupAt(v: Long) = put(Keys.LAST_CLEANUP, v)
    suspend fun setSaveImages(v: Boolean) = put(Keys.SAVE_IMAGES, v)
    suspend fun setAutoLockSeconds(v: Int) = put(Keys.AUTO_LOCK, v.coerceAtLeast(0))
    suspend fun setDeletionAlerts(v: Boolean) = put(Keys.DELETION_ALERTS, v)
    suspend fun setAlertShowText(v: Boolean) = put(Keys.ALERT_TEXT, v)
    suspend fun setDailySummary(v: Boolean) = put(Keys.DAILY_SUMMARY, v)
    suspend fun setSummaryHour(v: Int) = put(Keys.SUMMARY_HOUR, v.coerceIn(0, 23))
    suspend fun setGroupSimilar(v: Boolean) = put(Keys.GROUP_SIMILAR, v)
    suspend fun setSaveWhatsAppMedia(v: Boolean) = put(Keys.WA_MEDIA, v)

    /** True the first time it's called; used to ask for the notification permission only once. */
    suspend fun markNotificationPermissionAsked(): Boolean {
        var first = false
        context.dataStore.edit {
            first = it[Keys.NOTIF_PERMISSION_ASKED] != true
            it[Keys.NOTIF_PERMISSION_ASKED] = true
        }
        return first
    }

    suspend fun setWhatsAppFolderUri(uri: String?) {
        context.dataStore.edit { if (uri == null) it.remove(Keys.WA_FOLDER) else it[Keys.WA_FOLDER] = uri }
    }

    suspend fun addCategory(name: String) {
        val clean = name.trim().take(40)
        if (clean.isEmpty()) return
        context.dataStore.edit { it[Keys.CATEGORIES] = (it[Keys.CATEGORIES] ?: emptySet()) + clean }
    }

    suspend fun removeCategory(name: String) {
        context.dataStore.edit { it[Keys.CATEGORIES] = (it[Keys.CATEGORIES] ?: emptySet()) - name }
    }

    private suspend fun <T> put(key: Preferences.Key<T>, value: T) {
        context.dataStore.edit { it[key] = value }
    }
}

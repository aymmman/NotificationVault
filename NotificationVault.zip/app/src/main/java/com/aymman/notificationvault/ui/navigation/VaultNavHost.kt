package com.aymman.notificationvault.ui.navigation

import android.net.Uri
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aymman.notificationvault.R
import com.aymman.notificationvault.domain.model.NotificationKind
import com.aymman.notificationvault.service.ListenerStatus
import com.aymman.notificationvault.ui.common.NotificationPermissionRequest
import com.aymman.notificationvault.ui.apps.AppArchiveScreen
import com.aymman.notificationvault.ui.apps.AppsScreen
import com.aymman.notificationvault.ui.detail.DetailScreen
import com.aymman.notificationvault.ui.chat.ChatScreen
import com.aymman.notificationvault.ui.gallery.GalleryScreen
import com.aymman.notificationvault.ui.stats.StatsScreen
import com.aymman.notificationvault.ui.home.HomeScreen
import com.aymman.notificationvault.ui.inbox.InboxScreen
import com.aymman.notificationvault.ui.saved.SavedScreen
import com.aymman.notificationvault.ui.search.SearchScreen
import com.aymman.notificationvault.ui.settings.AboutScreen
import com.aymman.notificationvault.ui.settings.BackupSettingsScreen
import com.aymman.notificationvault.ui.settings.CaptureSettingsScreen
import com.aymman.notificationvault.ui.settings.PrivacySettingsScreen
import com.aymman.notificationvault.ui.settings.SettingsHomeScreen
import com.aymman.notificationvault.ui.settings.StorageSettingsScreen

object Routes {
    const val HOME = "home"
    const val INBOX = "inbox?kind={kind}&unread={unread}&deleted={deleted}"
    const val CHAT = "chat/{pkg}/{conv}"
    const val GALLERY = "gallery"
    const val STATS = "stats"
    const val APPS = "apps"
    const val APP = "app/{pkg}"
    const val DETAIL = "detail/{id}"
    const val SEARCH = "search?q={q}"
    const val SAVED = "saved"
    const val SETTINGS = "settings"
    const val SETTINGS_PRIVACY = "settings/privacy"
    const val SETTINGS_CAPTURE = "settings/capture"
    const val SETTINGS_STORAGE = "settings/storage"
    const val SETTINGS_BACKUP = "settings/backup"
    const val SETTINGS_ABOUT = "settings/about"

    fun inbox(kind: NotificationKind? = null, unread: Boolean = false, deleted: Boolean = false) =
        "inbox?kind=${kind?.name ?: ""}&unread=$unread&deleted=$deleted"
    fun chat(pkg: String, conversationId: String) = "chat/${Uri.encode(pkg)}/${Uri.encode(conversationId)}"
    fun app(pkg: String) = "app/${Uri.encode(pkg)}"
    fun detail(id: Long) = "detail/$id"
    fun search(q: String = "") = "search?q=${Uri.encode(q)}"
}

private data class Tab(val route: String, val navRoute: String, val label: Int, val icon: ImageVector, val selectedIcon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, Routes.HOME, R.string.nav_home, Icons.Outlined.Home, Icons.Filled.Home),
    Tab(Routes.INBOX, "inbox", R.string.nav_inbox, Icons.Outlined.Inbox, Icons.Filled.Inbox),
    Tab(Routes.APPS, Routes.APPS, R.string.nav_apps, Icons.Outlined.Apps, Icons.Filled.Apps),
    Tab(Routes.SAVED, Routes.SAVED, R.string.nav_saved, Icons.Outlined.Bookmarks, Icons.Filled.Bookmarks),
    Tab(Routes.SETTINGS, Routes.SETTINGS, R.string.nav_settings, Icons.Outlined.Settings, Icons.Filled.Settings),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VaultNavHost(
    openRecordId: Long? = null,
    onOpenConsumed: () -> Unit = {},
    navController: NavHostController = rememberNavController(),
) {
    LaunchedEffect(openRecordId) {
        if (openRecordId != null) {
            navController.navigate(Routes.detail(openRecordId))
            onOpenConsumed()
        }
    }
    NotificationPermissionRequest()
    val backStack by navController.currentBackStackEntryAsState()
    val current = backStack?.destination
    val showBar = tabs.any { t -> current?.route == t.route }
    val context = LocalContext.current

    fun goTab(tab: Tab) {
        navController.navigate(tab.navRoute) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                    tabs.forEach { tab ->
                        val selected = current?.hierarchy?.any { it.route == tab.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = { goTab(tab) },
                            icon = { Icon(if (selected) tab.selectedIcon else tab.icon, contentDescription = null) },
                            label = { Text(stringResource(tab.label), maxLines = 1) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).consumeWindowInsets(padding)) {
            NavHost(
                navController = navController,
                startDestination = Routes.HOME,
                enterTransition = { fadeIn() },
                exitTransition = { fadeOut() },
            ) {
                composable(Routes.HOME) {
                    HomeScreen(
                        onOpenSearch = { navController.navigate(Routes.search()) },
                        onOpenInbox = { kind, unread -> navController.navigate(Routes.inbox(kind, unread)) { launchSingleTop = true } },
                        onOpenApp = { navController.navigate(Routes.app(it)) },
                        onOpenApps = { goTab(tabs[2]) },
                        onOpenSaved = { goTab(tabs[3]) },
                        onOpenDeleted = { navController.navigate(Routes.inbox(deleted = true)) { launchSingleTop = true } },
                        onOpenGallery = { navController.navigate(Routes.GALLERY) },
                        onOpenStats = { navController.navigate(Routes.STATS) },
                        onOpenDetail = { navController.navigate(Routes.detail(it)) },
                        onOpenAccess = { ListenerStatus.openAccessSettings(context) },
                    )
                }
                composable(
                    Routes.INBOX,
                    arguments = listOf(
                        navArgument("kind") { type = NavType.StringType; nullable = true; defaultValue = null },
                        navArgument("unread") { type = NavType.BoolType; defaultValue = false },
                        navArgument("deleted") { type = NavType.BoolType; defaultValue = false },
                    ),
                ) {
                    InboxScreen(
                        onOpenDetail = { navController.navigate(Routes.detail(it)) },
                        onOpenSearch = { navController.navigate(Routes.search()) },
                    )
                }
                composable(Routes.APPS) {
                    AppsScreen(onOpenApp = { navController.navigate(Routes.app(it)) })
                }
                composable(Routes.APP, arguments = listOf(navArgument("pkg") { type = NavType.StringType })) {
                    AppArchiveScreen(
                        onOpenChat = { pkg, conv -> navController.navigate(Routes.chat(pkg, conv)) },
                        onBack = { navController.popBackStack() },
                        onOpenDetail = { navController.navigate(Routes.detail(it)) },
                    )
                }
                composable(Routes.DETAIL, arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                    DetailScreen(
                        onBack = { navController.popBackStack() },
                        onOpenChat = { pkg, conv -> navController.navigate(Routes.chat(pkg, conv)) },
                    )
                }
                composable(
                    Routes.SEARCH,
                    arguments = listOf(navArgument("q") { type = NavType.StringType; defaultValue = "" }),
                ) {
                    SearchScreen(
                        onBack = { navController.popBackStack() },
                        onOpenDetail = { navController.navigate(Routes.detail(it)) },
                    )
                }
                composable(
                    Routes.CHAT,
                    arguments = listOf(
                        navArgument("pkg") { type = NavType.StringType },
                        navArgument("conv") { type = NavType.StringType },
                    ),
                ) {
                    ChatScreen(
                        onBack = { navController.popBackStack() },
                        onOpenDetail = { navController.navigate(Routes.detail(it)) },
                    )
                }
                composable(Routes.GALLERY) {
                    GalleryScreen(
                        onBack = { navController.popBackStack() },
                        onOpenDetail = { navController.navigate(Routes.detail(it)) },
                    )
                }
                composable(Routes.STATS) {
                    StatsScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.SAVED) {
                    SavedScreen(onOpenDetail = { navController.navigate(Routes.detail(it)) })
                }
                composable(Routes.SETTINGS) {
                    SettingsHomeScreen(
                        onPrivacy = { navController.navigate(Routes.SETTINGS_PRIVACY) },
                        onCapture = { navController.navigate(Routes.SETTINGS_CAPTURE) },
                        onStorage = { navController.navigate(Routes.SETTINGS_STORAGE) },
                        onBackup = { navController.navigate(Routes.SETTINGS_BACKUP) },
                        onAbout = { navController.navigate(Routes.SETTINGS_ABOUT) },
                    )
                }
                composable(Routes.SETTINGS_PRIVACY) { PrivacySettingsScreen(onBack = { navController.popBackStack() }) }
                composable(Routes.SETTINGS_CAPTURE) { CaptureSettingsScreen(onBack = { navController.popBackStack() }) }
                composable(Routes.SETTINGS_STORAGE) { StorageSettingsScreen(onBack = { navController.popBackStack() }) }
                composable(Routes.SETTINGS_BACKUP) { BackupSettingsScreen(onBack = { navController.popBackStack() }) }
                composable(Routes.SETTINGS_ABOUT) { AboutScreen(onBack = { navController.popBackStack() }) }
            }
        }
    }
}

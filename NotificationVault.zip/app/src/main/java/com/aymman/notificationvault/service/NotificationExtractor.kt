package com.aymman.notificationvault.service

import android.app.Notification
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.aymman.notificationvault.domain.model.RawMessage
import com.aymman.notificationvault.domain.model.RawNotification

/** A picture a notification carries. Resolved to bytes later, off the binder thread. */
sealed interface ImageRef {
    /** BigPictureStyle bitmap. */
    data class FromBitmap(val bitmap: Bitmap) : ImageRef

    /** BigPictureStyle icon (Android 12+). */
    data class FromIcon(val icon: Icon) : ImageRef

    /** MessagingStyle message image; [messageIndex] points into RawNotification.messages. */
    data class FromUri(val uri: Uri, val mimeType: String?, val messageIndex: Int) : ImageRef
}

data class ExtractedNotification(val raw: RawNotification, val images: List<ImageRef>)

/**
 * Reads only the user-visible parts of a notification: its text and, separately, references to
 * pictures it displays. No PendingIntents, RemoteViews or raw Bundles leave this function.
 */
object NotificationExtractor {

    fun extract(sbn: StatusBarNotification): ExtractedNotification {
        val n: Notification = sbn.notification
        val extras: Bundle = n.extras ?: Bundle.EMPTY
        val images = ArrayList<ImageRef>()

        fun cs(key: String): String? = try {
            extras.getCharSequence(key)?.toString()
        } catch (e: Exception) {
            null
        }

        val lines = try {
            extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.mapNotNull { it?.toString() }.orEmpty()
        } catch (e: Exception) {
            emptyList()
        }

        val style = try {
            NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        } catch (e: Exception) {
            null
        }
        val selfName = try { style?.user?.name?.toString() } catch (e: Exception) { null }
        val messages = try {
            style?.messages?.mapIndexed { index, m ->
                val mime = m.dataMimeType
                val uri = m.dataUri
                val isImage = uri != null && mime != null && mime.startsWith("image/")
                if (isImage) images += ImageRef.FromUri(uri!!, mime, index)
                RawMessage(
                    text = m.text?.toString(),
                    timestamp = m.timestamp,
                    // A null person means the message was sent by the device owner.
                    senderName = m.person?.name?.toString() ?: selfName,
                    hasImage = isImage,
                )
            }.orEmpty()
        } catch (e: Exception) {
            emptyList()
        }

        // BigPictureStyle picture (e.g. photo previews from many messaging and social apps).
        try {
            val picture: Bitmap? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                extras.getParcelable(Notification.EXTRA_PICTURE, Bitmap::class.java)
            } else {
                @Suppress("DEPRECATION")
                extras.getParcelable(Notification.EXTRA_PICTURE)
            }
            if (picture != null) {
                images += ImageRef.FromBitmap(picture)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                extras.getParcelable(Notification.EXTRA_PICTURE_ICON, Icon::class.java)?.let { images += ImageRef.FromIcon(it) }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                @Suppress("DEPRECATION")
                (extras.getParcelable(Notification.EXTRA_PICTURE_ICON) as? Icon)?.let { images += ImageRef.FromIcon(it) }
            }
        } catch (e: Exception) {
            // Unreadable picture: keep the text anyway.
        }

        val flags = n.flags
        val progressMax = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        val indeterminate = extras.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)

        val raw = RawNotification(
            packageName = sbn.packageName.orEmpty(),
            key = sbn.key.orEmpty(),
            postTime = sbn.postTime,
            whenTime = n.`when`,
            title = cs(Notification.EXTRA_TITLE_BIG) ?: cs(Notification.EXTRA_TITLE),
            text = cs(Notification.EXTRA_TEXT),
            bigText = cs(Notification.EXTRA_BIG_TEXT),
            subText = cs(Notification.EXTRA_SUB_TEXT) ?: cs(Notification.EXTRA_SUMMARY_TEXT),
            textLines = lines,
            conversationTitle = try { style?.conversationTitle?.toString() } catch (e: Exception) { null }
                ?: cs(Notification.EXTRA_CONVERSATION_TITLE),
            isGroupConversation = try { style?.isGroupConversation ?: false } catch (e: Exception) { false },
            shortcutId = n.shortcutId,
            category = n.category,
            isGroupSummary = (flags and Notification.FLAG_GROUP_SUMMARY) != 0,
            isOngoing = (flags and Notification.FLAG_ONGOING_EVENT) != 0 ||
                (flags and Notification.FLAG_FOREGROUND_SERVICE) != 0,
            hasProgress = progressMax > 0 || indeterminate,
            messages = messages,
        )
        return ExtractedNotification(raw, images)
    }
}

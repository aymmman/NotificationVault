package com.aymman.notificationvault.service

import android.app.Notification
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.aymman.notificationvault.domain.model.RawMessage
import com.aymman.notificationvault.domain.model.RawNotification

/**
 * Reads only the textual, user-visible parts of a notification. No PendingIntents, bitmaps,
 * RemoteViews or raw Bundles leave this function.
 */
object NotificationExtractor {

    fun extract(sbn: StatusBarNotification): RawNotification {
        val n: Notification = sbn.notification
        val extras: Bundle = n.extras ?: Bundle.EMPTY

        fun cs(key: String): String? = try {
            extras.getCharSequence(key)?.toString()
        } catch (e: Exception) {
            null
        }

        val lines = try {
            extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.mapNotNull { it?.toString() }.orEmpty()
        } catch (e: Exception) {
            emptyList()
        }

        val style = try {
            NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        } catch (e: Exception) {
            null
        }
        val selfName = try { style?.user?.name?.toString() } catch (e: Exception) { null }
        val messages = try {
            style?.messages?.map { m ->
                RawMessage(
                    text = m.text?.toString(),
                    timestamp = m.timestamp,
                    // A null person means the message was sent by the device owner.
                    senderName = m.person?.name?.toString() ?: selfName,
                )
            }.orEmpty()
        } catch (e: Exception) {
            emptyList()
        }

        val flags = n.flags
        val progressMax = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        val indeterminate = extras.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)

        return RawNotification(
            packageName = sbn.packageName.orEmpty(),
            key = sbn.key.orEmpty(),
            postTime = sbn.postTime,
            whenTime = n.`when`,
            title = cs(Notification.EXTRA_TITLE_BIG) ?: cs(Notification.EXTRA_TITLE),
            text = cs(Notification.EXTRA_TEXT),
            bigText = cs(Notification.EXTRA_BIG_TEXT),
            subText = cs(Notification.EXTRA_SUB_TEXT) ?: cs(Notification.EXTRA_SUMMARY_TEXT),
            textLines = lines,
            conversationTitle = try { style?.conversationTitle?.toString() } catch (e: Exception) { null }
                ?: cs(Notification.EXTRA_CONVERSATION_TITLE),
            isGroupConversation = try { style?.isGroupConversation ?: false } catch (e: Exception) { false },
            shortcutId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) n.shortcutId else null,
            category = n.category,
            isGroupSummary = (flags and Notification.FLAG_GROUP_SUMMARY) != 0,
            isOngoing = (flags and Notification.FLAG_ONGOING_EVENT) != 0 ||
                (flags and Notification.FLAG_FOREGROUND_SERVICE) != 0,
            hasProgress = progressMax > 0 || indeterminate,
            messages = messages,
        )
    }
}

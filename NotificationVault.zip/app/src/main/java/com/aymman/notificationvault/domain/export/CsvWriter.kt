package com.aymman.notificationvault.domain.export

/** Minimal RFC 4180 CSV writer. Fields are always quoted; formula-leading cells are neutralised. */
object CsvWriter {

    fun write(header: List<String>, rows: List<List<String?>>): String = buildString {
        append('﻿') // BOM so spreadsheet apps detect UTF-8 (Arabic text renders correctly)
        appendRow(header)
        rows.forEach { appendRow(it) }
    }

    private fun StringBuilder.appendRow(cells: List<String?>) {
        cells.forEachIndexed { i, cell ->
            if (i > 0) append(',')
            append(escape(cell))
        }
        append("\r\n")
    }

    fun escape(value: String?): String {
        var v = value ?: ""
        // Prevent CSV/formula injection when opened in spreadsheet software.
        if (v.isNotEmpty() && v[0] in "=+-@\t\r") v = "'$v"
        return "\"" + v.replace("\"", "\"\"") + "\""
    }
}

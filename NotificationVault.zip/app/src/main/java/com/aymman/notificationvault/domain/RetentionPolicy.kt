package com.aymman.notificationvault.domain

import java.util.concurrent.TimeUnit

/** Pure helpers for retention maths. 0 days means "keep forever". */
object RetentionPolicy {

    val PRESET_DAYS = listOf(0, 7, 30, 90, 180, 365)

    fun cutoffMillis(now: Long, days: Int): Long? =
        if (days <= 0) null else now - TimeUnit.DAYS.toMillis(days.toLong())

    /** A record is expired when older than the cutoff and not protected by pin/bookmark. */
    fun isExpired(receivedAt: Long, pinned: Boolean, bookmarked: Boolean, now: Long, days: Int): Boolean {
        val cutoff = cutoffMillis(now, days) ?: return false
        return !pinned && !bookmarked && receivedAt < cutoff
    }

    /** Per-app override wins when set; otherwise the global value applies. */
    fun effectiveDays(globalDays: Int, appOverride: Int?): Int = appOverride ?: globalDays
}

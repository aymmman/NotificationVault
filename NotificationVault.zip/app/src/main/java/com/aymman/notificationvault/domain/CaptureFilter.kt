package com.aymman.notificationvault.domain

import com.aymman.notificationvault.domain.model.CapturedRecord

/**
 * User-defined exclusion rules. These only prevent NEW records from being captured;
 * they never delete anything already in the archive.
 */
object CaptureFilter {

    fun isExcluded(record: CapturedRecord, keywords: List<String>): Boolean {
        if (keywords.isEmpty()) return false
        val haystack = buildString {
            record.title?.let { append(it).append('\n') }
            record.text?.let { append(it).append('\n') }
            record.bigText?.let { append(it) }
        }
        return keywords.any { kw ->
            val k = kw.trim()
            k.isNotEmpty() && haystack.contains(k, ignoreCase = true)
        }
    }

    /** Parses the comma/newline separated keyword field from settings. */
    fun parseKeywords(raw: String): List<String> =
        raw.split(',', '\n', '؛', '،').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
}

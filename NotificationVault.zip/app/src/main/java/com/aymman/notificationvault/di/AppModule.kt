package com.aymman.notificationvault.di

import android.content.Context
import androidx.room.Room
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.AppDatabase
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.data.media.AttachmentStore
import com.aymman.notificationvault.data.media.ImageCapture
import com.aymman.notificationvault.data.media.WhatsAppImporter
import com.aymman.notificationvault.data.security.PinManager
import com.aymman.notificationvault.data.security.DatabaseKeyManager
import com.aymman.notificationvault.service.ListenerStatus
import com.aymman.notificationvault.util.AppInfoResolver
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideKeyManager(@ApplicationContext context: Context): DatabaseKeyManager = DatabaseKeyManager(context)

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context, keys: DatabaseKeyManager): AppDatabase {
        System.loadLibrary("sqlcipher")
        val factory = SupportOpenHelperFactory(keys.getPassphrase())
        return Room.databaseBuilder(context, AppDatabase::class.java, AppDatabase.NAME)
            .openHelperFactory(factory)
            .addMigrations(*AppDatabase.MIGRATIONS)
            .build()
    }

    @Provides
    @Singleton
    fun provideSettings(@ApplicationContext context: Context): SettingsRepository = SettingsRepository(context)

    @Provides
    @Singleton
    fun provideRepository(@ApplicationContext context: Context, db: AppDatabase, store: AttachmentStore): VaultRepository =
        VaultRepository(db, context.packageName, store)

    @Provides
    @Singleton
    fun provideAttachmentStore(@ApplicationContext context: Context): AttachmentStore = AttachmentStore(context)

    @Provides
    @Singleton
    fun provideImageCapture(@ApplicationContext context: Context, repo: VaultRepository, store: AttachmentStore): ImageCapture =
        ImageCapture(context, repo, store)

    @Provides
    @Singleton
    fun provideWhatsAppImporter(
        @ApplicationContext context: Context,
        repo: VaultRepository,
        store: AttachmentStore,
        settings: SettingsRepository,
    ): WhatsAppImporter = WhatsAppImporter(context, repo, store, settings)

    @Provides
    @Singleton
    fun providePinManager(@ApplicationContext context: Context): PinManager = PinManager(context)

    @Provides
    @Singleton
    fun provideBackupManager(@ApplicationContext context: Context, db: AppDatabase): BackupManager = BackupManager(context, db)

    @Provides
    @Singleton
    fun provideAppInfo(@ApplicationContext context: Context): AppInfoResolver = AppInfoResolver(context)

    @Provides
    @Singleton
    fun provideListenerStatus(@ApplicationContext context: Context): ListenerStatus = ListenerStatus(context)
}

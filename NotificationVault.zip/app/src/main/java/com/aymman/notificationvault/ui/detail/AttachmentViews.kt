package com.aymman.notificationvault.ui.detail

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.AttachmentEntity

/** Saved images of a record, each with its origin and a "Save" action. Tap to view full screen. */
@Composable
fun AttachmentGallery(
    attachments: List<AttachmentEntity>,
    load: suspend (AttachmentEntity, Int) -> Bitmap?,
    onSave: (AttachmentEntity) -> Unit,
) {
    var viewing by remember { mutableStateOf<AttachmentEntity?>(null) }
    Column {
        attachments.forEach { a ->
            val bmp by produceState<Bitmap?>(initialValue = null, a.id) { value = load(a, 1080) }
            val ratio = if (a.width > 0 && a.height > 0) (a.width.toFloat() / a.height).coerceIn(0.4f, 2.5f) else 1f
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(ratio)
                    .clip(MaterialTheme.shapes.large)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .clickable { viewing = a },
                contentAlignment = Alignment.Center,
            ) {
                val b = bmp
                if (b != null) {
                    Image(
                        bitmap = b.asImageBitmap(),
                        contentDescription = stringResource(R.string.image_saved),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    CircularProgressIndicator(Modifier.size(28.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(
                        if (a.source == AttachmentEntity.SOURCE_WHATSAPP_FOLDER) R.string.image_from_whatsapp else R.string.image_from_notification,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { onSave(a) }) {
                    Icon(Icons.Outlined.FileDownload, null)
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.image_save))
                }
            }
        }
    }
    viewing?.let { a -> FullScreenImage(a, load, onClose = { viewing = null }) }
}

@Composable
private fun FullScreenImage(a: AttachmentEntity, load: suspend (AttachmentEntity, Int) -> Bitmap?, onClose: () -> Unit) {
    // null = still loading; Loaded(null) = couldn't be decoded.
    val result by produceState<Loaded?>(initialValue = null, a.id) { value = Loaded(load(a, 2048)) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 6f)
        offset = if (scale == 1f) Offset.Zero else offset + pan
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val r = result
            val b = r?.bitmap
            if (b != null) {
                Image(
                    bitmap = b.asImageBitmap(),
                    contentDescription = stringResource(R.string.image_saved),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; offset = Offset.Zero })
                        }
                        .transformable(state)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        },
                )
            } else if (r != null) {
                Icon(Icons.Outlined.BrokenImage, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(48.dp))
            } else {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            }
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)) {
                Icon(Icons.Filled.Close, stringResource(R.string.action_close), tint = Color.White)
            }
        }
    }
}

private class Loaded(val bitmap: Bitmap?)

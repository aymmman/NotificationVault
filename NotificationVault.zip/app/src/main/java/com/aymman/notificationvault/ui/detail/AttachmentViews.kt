package com.aymman.notificationvault.ui.detail

import android.graphics.Bitmap
import android.media.MediaPlayer
import android.text.format.Formatter
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.viewinterop.AndroidView
import com.aymman.notificationvault.domain.media.MediaKind
import kotlinx.coroutines.delay
import java.io.File
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.AttachmentEntity

/**
 * Saved files of a record: photos (tap to view full screen), voice notes and videos (tap to play),
 * each with its origin and a "Save" action.
 */
@Composable
fun AttachmentGallery(
    attachments: List<AttachmentEntity>,
    load: suspend (AttachmentEntity, Int) -> Bitmap?,
    prepare: suspend (AttachmentEntity) -> File?,
    onSave: (AttachmentEntity) -> Unit,
) {
    var viewing by remember { mutableStateOf<AttachmentEntity?>(null) }
    var playing by remember { mutableStateOf<AttachmentEntity?>(null) }
    Column {
        attachments.forEach { a ->
            val kind = MediaKind.ofMime(a.mimeType)
            if (kind == MediaKind.IMAGE) {
                val bmp by produceState<Bitmap?>(initialValue = null, a.id) { value = load(a, 1080) }
                val ratio = if (a.width > 0 && a.height > 0) (a.width.toFloat() / a.height).coerceIn(0.4f, 2.5f) else 1f
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(ratio)
                        .clip(MaterialTheme.shapes.large)
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .clickable { viewing = a },
                    contentAlignment = Alignment.Center,
                ) {
                    val b = bmp
                    if (b != null) {
                        Image(
                            bitmap = b.asImageBitmap(),
                            contentDescription = stringResource(R.string.image_saved),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        CircularProgressIndicator(Modifier.size(28.dp))
                    }
                }
            } else {
                MediaCard(a, kind, onPlay = { playing = a })
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(
                        if (a.source == AttachmentEntity.SOURCE_WHATSAPP_FOLDER) R.string.image_from_whatsapp else R.string.image_from_notification,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { onSave(a) }) {
                    Icon(Icons.Outlined.FileDownload, null)
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.image_save))
                }
            }
        }
    }
    viewing?.let { a -> FullScreenImage(a, load, onClose = { viewing = null }) }
    playing?.let { a -> MediaPlayerDialog(a, prepare, onClose = { playing = null }) }
}

@Composable
private fun MediaCard(a: AttachmentEntity, kind: MediaKind?, onPlay: () -> Unit) {
    val context = LocalContext.current
    Surface(
        onClick = onPlay,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = MaterialTheme.shapes.large,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = stringResource(R.string.media_play), tint = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    stringResource(if (kind == MediaKind.VIDEO) R.string.media_video else R.string.media_voice),
                    style = MaterialTheme.typography.titleSmall,
                )
                Text(
                    Formatter.formatShortFileSize(context, a.sizeBytes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** Decrypts the file to private cache, plays it, and deletes the decrypted copy when closed. */
@Composable
private fun MediaPlayerDialog(a: AttachmentEntity, prepare: suspend (AttachmentEntity) -> File?, onClose: () -> Unit) {
    val result by produceState<PreparedFile?>(initialValue = null, a.id) { value = PreparedFile(prepare(a)) }
    DisposableEffect(a.id) {
        onDispose { result?.file?.delete() }
    }
    val isVideo = MediaKind.ofMime(a.mimeType) == MediaKind.VIDEO
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = !isVideo)) {
        Surface(
            color = if (isVideo) Color.Black else MaterialTheme.colorScheme.surface,
            shape = if (isVideo) MaterialTheme.shapes.extraSmall else MaterialTheme.shapes.extraLarge,
            modifier = if (isVideo) Modifier.fillMaxSize() else Modifier.fillMaxWidth(),
        ) {
            Box(Modifier.padding(if (isVideo) 0.dp else 20.dp)) {
                val r = result
                val file = r?.file
                when {
                    r == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    file == null -> Text(stringResource(R.string.media_cannot_play), modifier = Modifier.align(Alignment.Center))
                    isVideo -> VideoPlayer(file)
                    else -> AudioPlayer(file)
                }
                IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd)) {
                    Icon(Icons.Filled.Close, stringResource(R.string.action_close), tint = if (isVideo) Color.White else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

private class PreparedFile(val file: File?)

@Composable
private fun VideoPlayer(file: File) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            VideoView(ctx).apply {
                val controller = MediaController(ctx)
                controller.setAnchorView(this)
                setMediaController(controller)
                setVideoPath(file.absolutePath)
                setOnPreparedListener { start() }
            }
        },
        onRelease = { it.stopPlayback() },
    )
}

@Composable
private fun AudioPlayer(file: File) {
    var error by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(0) }
    val player = remember(file) {
        try {
            MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
            }
        } catch (e: Exception) {
            null
        }
    }
    DisposableEffect(player) {
        if (player == null) error = true else {
            duration = player.duration
            player.setOnCompletionListener { playing = false; position = 0 }
        }
        onDispose { player?.release() }
    }
    LaunchedEffect(playing) {
        while (playing && player != null) {
            position = player.currentPosition
            delay(200)
        }
    }
    Column(Modifier.fillMaxWidth().padding(top = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (error || player == null) {
            Text(stringResource(R.string.media_cannot_play), textAlign = TextAlign.Center)
        } else {
        Text(stringResource(R.string.media_voice), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        Slider(
            value = if (duration > 0) position.toFloat() / duration else 0f,
            onValueChange = { f ->
                position = (f * duration).toInt()
                player.seekTo(position)
            },
        )
        Text("${mmss(position)} / ${mmss(duration)}", style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(8.dp))
        IconButton(
            onClick = {
                if (player.isPlaying) { player.pause(); playing = false } else { player.start(); playing = true }
            },
            modifier = Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
        ) {
            Icon(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = stringResource(if (playing) R.string.media_pause else R.string.media_play),
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(36.dp),
            )
        }
        }
    }
}

private fun mmss(ms: Int): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
fun FullScreenImage(
    a: AttachmentEntity,
    load: suspend (AttachmentEntity, Int) -> Bitmap?,
    onClose: () -> Unit,
    onOpenMessage: (() -> Unit)? = null,
) {
    // null = still loading; Loaded(null) = couldn't be decoded.
    val result by produceState<Loaded?>(initialValue = null, a.id) { value = Loaded(load(a, 2048)) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 6f)
        offset = if (scale == 1f) Offset.Zero else offset + pan
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val r = result
            val b = r?.bitmap
            if (b != null) {
                Image(
                    bitmap = b.asImageBitmap(),
                    contentDescription = stringResource(R.string.image_saved),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; offset = Offset.Zero })
                        }
                        .transformable(state)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        },
                )
            } else if (r != null) {
                Icon(Icons.Outlined.BrokenImage, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(48.dp))
            } else {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            }
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)) {
                Icon(Icons.Filled.Close, stringResource(R.string.action_close), tint = Color.White)
            }
            if (onOpenMessage != null) {
                TextButton(
                    onClick = onOpenMessage,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                ) { Text(stringResource(R.string.gallery_open_message), color = Color.White) }
            }
        }
    }
}

private class Loaded(val bitmap: Bitmap?)

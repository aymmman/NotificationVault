package com.aymman.notificationvault.domain.media

/**
 * Pairs WhatsApp "📷 Photo" records with image files from the WhatsApp media folder by time.
 * WhatsApp file names carry no sender, so the closest file saved around the time the notification
 * arrived is used. Each record and each file is used at most once; pairs further apart than
 * [TOLERANCE_MS] are never made.
 */
object PhotoMatcher {

    const val TOLERANCE_MS = 10 * 60 * 1000L

    data class Photo(val recordId: Long, val time: Long)
    data class File(val id: String, val modified: Long)

    /** Returns recordId → fileId pairs. */
    fun match(photos: List<Photo>, files: List<File>): List<Pair<Long, String>> {
        val candidates = ArrayList<Triple<Long, Photo, File>>()
        for (p in photos) {
            for (f in files) {
                // A downloaded file is normally written shortly after the message arrives.
                // Files written well before the message are penalised so they don't steal matches.
                val delta = f.modified - p.time
                if (delta < -TOLERANCE_MS || delta > TOLERANCE_MS) continue
                val cost = if (delta >= -60_000L) kotlin.math.abs(delta) else kotlin.math.abs(delta) * 3
                candidates += Triple(cost, p, f)
            }
        }
        candidates.sortWith(compareBy<Triple<Long, Photo, File>> { it.first }.thenBy { it.second.time })
        val usedPhotos = HashSet<Long>()
        val usedFiles = HashSet<String>()
        val out = ArrayList<Pair<Long, String>>()
        for ((_, p, f) in candidates) {
            if (p.recordId in usedPhotos || f.id in usedFiles) continue
            usedPhotos += p.recordId
            usedFiles += f.id
            out += p.recordId to f.id
        }
        return out.sortedBy { it.first }
    }
}

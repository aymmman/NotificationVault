package com.aymman.notificationvault.ui.saved

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.ui.common.ArchiveList
import com.aymman.notificationvault.ui.common.BaseArchiveViewModel
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.SelectionActions
import com.aymman.notificationvault.ui.common.SelectionTopBar
import com.aymman.notificationvault.ui.common.rememberSelection
import com.aymman.notificationvault.ui.common.resolve
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

enum class SavedTab { ALL, PINNED, BOOKMARKED }

data class SavedSelection(val tab: SavedTab = SavedTab.ALL, val category: String? = null)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class SavedViewModel @Inject constructor(
    repository: VaultRepository,
    backupManager: BackupManager,
    settings: SettingsRepository,
) : BaseArchiveViewModel(repository, backupManager) {

    private val _selection = MutableStateFlow(SavedSelection())
    val selection: StateFlow<SavedSelection> = _selection.asStateFlow()

    val categories: StateFlow<List<String>> = settings.settings.map { it.customCategories.sorted() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val rows: StateFlow<List<NotificationRow>?> = _selection.flatMapLatest { s ->
        val filters = when {
            s.category != null -> SearchFilters(userCategory = s.category)
            s.tab == SavedTab.PINNED -> SearchFilters(pinnedOnly = true)
            s.tab == SavedTab.BOOKMARKED -> SearchFilters(bookmarkedOnly = true)
            else -> SearchFilters(pinnedOnly = true, bookmarkedOnly = true) // pinned OR bookmarked
        }
        repository.observeRows(filters)
    }.map<List<NotificationRow>, List<NotificationRow>?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setTab(tab: SavedTab) {
        _selection.value = SavedSelection(tab = tab)
    }

    fun setCategory(c: String?) {
        _selection.value = SavedSelection(tab = SavedTab.ALL, category = c)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedScreen(onOpenDetail: (Long) -> Unit, vm: SavedViewModel = hiltViewModel()) {
    val rows by vm.rows.collectAsStateWithLifecycle()
    val sel by vm.selection.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val selection = rememberSelection()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it.resolve(context)) } }
    LaunchedEffect(rows) { rows?.let { list -> selection.retain(list.map { it.n.id }.toSet()) } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selection.active) {
                SelectionTopBar(selection.selected.size, onClear = selection::clear) { SelectionActions(rows.orEmpty(), selection, vm) }
            } else {
                TopAppBar(
                    title = { Text(stringResource(R.string.saved_title)) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            val tabs = listOf(SavedTab.ALL to R.string.read_all, SavedTab.PINNED to R.string.saved_pinned, SavedTab.BOOKMARKED to R.string.saved_bookmarks)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                tabs.forEachIndexed { i, (tab, label) ->
                    SegmentedButton(
                        selected = sel.category == null && sel.tab == tab,
                        onClick = { vm.setTab(tab) },
                        shape = SegmentedButtonDefaults.itemShape(index = i, count = tabs.size),
                    ) { Text(stringResource(label)) }
                }
            }
            if (categories.isNotEmpty()) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    categories.forEach { c ->
                        FilterChip(
                            selected = sel.category == c,
                            onClick = { vm.setCategory(if (sel.category == c) null else c) },
                            label = { Text(c) },
                        )
                    }
                }
            }
            val list = rows
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                ArchiveList(
                    rows = list,
                    selection = selection,
                    showApp = true,
                    byDay = false,
                    onOpen = onOpenDetail,
                    empty = {
                        EmptyState(
                            stringResource(R.string.saved_empty_title),
                            stringResource(R.string.saved_empty_body),
                            icon = Icons.Outlined.BookmarkBorder,
                        )
                    },
                )
            }
        }
    }
}

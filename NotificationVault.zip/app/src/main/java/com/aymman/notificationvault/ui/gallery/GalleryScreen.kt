package com.aymman.notificationvault.ui.gallery

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.db.AttachmentEntity
import com.aymman.notificationvault.data.media.AttachmentStore
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.ui.common.BackTopBar
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.detail.FullScreenImage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class GalleryViewModel @Inject constructor(
    repository: VaultRepository,
    private val store: AttachmentStore,
) : ViewModel() {
    val images: StateFlow<List<AttachmentEntity>?> = repository.observeImages()
        .map<List<AttachmentEntity>, List<AttachmentEntity>?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    suspend fun loadBitmap(a: AttachmentEntity, maxPx: Int): Bitmap? =
        withContext(Dispatchers.IO) { runCatching { store.loadBitmap(a.fileName, maxPx) }.getOrNull() }
}

/** Every saved photo in one grid, newest first. Tap to view; from there jump to the message. */
@Composable
fun GalleryScreen(onBack: () -> Unit, onOpenDetail: (Long) -> Unit, vm: GalleryViewModel = hiltViewModel()) {
    val images by vm.images.collectAsStateWithLifecycle()
    var viewing by remember { mutableStateOf<AttachmentEntity?>(null) }

    Scaffold(topBar = { BackTopBar(stringResource(R.string.gallery_title), onBack) }) { padding ->
        val list = images
        when {
            list == null -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyState(
                stringResource(R.string.gallery_empty_title),
                stringResource(R.string.gallery_empty_body),
                modifier = Modifier.padding(padding),
                icon = Icons.Outlined.PhotoLibrary,
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(110.dp),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(padding).fillMaxSize(),
            ) {
                items(list, key = { it.id }) { a ->
                    val bmp by produceState<Bitmap?>(initialValue = null, a.id) { value = vm.loadBitmap(a, 360) }
                    Box(
                        Modifier
                            .aspectRatio(1f)
                            .clip(MaterialTheme.shapes.medium)
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                            .clickable { viewing = a },
                        contentAlignment = Alignment.Center,
                    ) {
                        val b = bmp
                        if (b != null) {
                            Image(
                                bitmap = b.asImageBitmap(),
                                contentDescription = stringResource(R.string.image_saved),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    }
                }
            }
        }
    }
    viewing?.let { a ->
        FullScreenImage(
            a = a,
            load = vm::loadBitmap,
            onClose = { viewing = null },
            onOpenMessage = { viewing = null; onOpenDetail(a.notificationId) },
        )
    }
}

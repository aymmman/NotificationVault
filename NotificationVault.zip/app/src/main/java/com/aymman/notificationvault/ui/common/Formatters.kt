package com.aymman.notificationvault.ui.common

import android.text.format.DateUtils
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.aymman.notificationvault.R
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

object Formatters {
    private val timeFmt: DateTimeFormatter get() = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)
    private val dateFmt: DateTimeFormatter get() = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
    private val dateTimeFmt: DateTimeFormatter get() = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)

    private fun zoned(ts: Long) = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault())

    fun time(ts: Long): String = timeFmt.format(zoned(ts))
    fun date(ts: Long): String = dateFmt.format(zoned(ts))
    fun dateTime(ts: Long): String = dateTimeFmt.format(zoned(ts))

    fun localDate(ts: Long): LocalDate = zoned(ts).toLocalDate()

    fun startOfToday(): Long =
        LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

    /** "5 min. ago", "Yesterday", … using the platform's localized relative formatting. */
    fun relative(ts: Long, now: Long = System.currentTimeMillis()): CharSequence =
        DateUtils.getRelativeTimeSpanString(ts, now, DateUtils.MINUTE_IN_MILLIS, DateUtils.FORMAT_ABBREV_RELATIVE)

    /** Short stamp for list rows: time if today, otherwise date. */
    fun short(ts: Long): String =
        if (localDate(ts) == LocalDate.now()) time(ts) else DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT).format(zoned(ts))
}

@Composable
fun dayHeader(day: LocalDate): String {
    val today = LocalDate.now()
    return when (day) {
        today -> stringResource(R.string.today)
        today.minusDays(1) -> stringResource(R.string.yesterday)
        else -> DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).format(day)
    }
}

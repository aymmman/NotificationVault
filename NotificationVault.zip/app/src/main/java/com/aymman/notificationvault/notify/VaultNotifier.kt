package com.aymman.notificationvault.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.aymman.notificationvault.MainActivity
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.repo.DeletionEvent

/**
 * The app's own notifications: deletion alerts and the daily summary. Content is always marked
 * private, so the lock screen only shows a generic line. These notifications are never archived.
 */
class VaultNotifier(private val context: Context) {

    fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_DELETIONS, context.getString(R.string.channel_deletions), NotificationManager.IMPORTANCE_HIGH).apply {
                description = context.getString(R.string.channel_deletions_desc)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SUMMARY, context.getString(R.string.channel_summary), NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = context.getString(R.string.channel_summary_desc)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            },
        )
    }

    fun canPost(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun deletionAlert(event: DeletionEvent, appLabel: String, showText: Boolean) {
        if (!canPost()) return
        val who = event.sender ?: event.conversationTitle ?: appLabel
        val title = context.getString(R.string.alert_deleted_title, who)
        val original = event.original
        val body = when {
            original == null -> context.getString(R.string.alert_deleted_not_captured)
            !showText -> context.getString(R.string.alert_deleted_tap)
            else -> context.getString(R.string.alert_deleted_text, original.text ?: original.title ?: "")
        }
        val publicVersion = NotificationCompat.Builder(context, CH_DELETIONS)
            .setSmallIcon(R.drawable.ic_stat_vault)
            .setContentTitle(context.getString(R.string.alert_deleted_public))
            .build()
        val n = NotificationCompat.Builder(context, CH_DELETIONS)
            .setSmallIcon(R.drawable.ic_stat_vault)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSubText(appLabel)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setAutoCancel(true)
            .setContentIntent(openIntent(original?.id, REQ_DELETION + (original?.id ?: 0L).toInt()))
            .build()
        post(ID_DELETION_BASE + ((original?.id ?: System.currentTimeMillis()) % 100_000).toInt(), n)
    }

    fun dailySummary(total: Int, deleted: Int, topApps: List<String>) {
        if (!canPost()) return
        val title = context.getString(R.string.summary_title, total)
        val body = buildString {
            append(context.getString(R.string.summary_deleted, deleted))
            if (topApps.isNotEmpty()) {
                append('\n')
                append(context.getString(R.string.summary_top, topApps.joinToString(", ")))
            }
        }
        val n = NotificationCompat.Builder(context, CH_SUMMARY)
            .setSmallIcon(R.drawable.ic_stat_vault)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .setContentIntent(openIntent(null, REQ_SUMMARY))
            .build()
        post(ID_SUMMARY, n)
    }

    private fun post(id: Int, n: android.app.Notification) {
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (e: SecurityException) {
            // Permission revoked between the check and the post.
        }
    }

    private fun openIntent(recordId: Long?, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (recordId != null) intent.putExtra(MainActivity.EXTRA_OPEN_RECORD, recordId)
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        const val CH_DELETIONS = "deletions"
        const val CH_SUMMARY = "daily_summary"
        private const val ID_SUMMARY = 7001
        private const val ID_DELETION_BASE = 8000
        private const val REQ_SUMMARY = 1
        private const val REQ_DELETION = 1000
    }
}

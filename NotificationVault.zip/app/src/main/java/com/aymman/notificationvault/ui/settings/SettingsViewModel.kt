package com.aymman.notificationvault.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.AppSummary
import com.aymman.notificationvault.data.db.BackupRecordEntity
import com.aymman.notificationvault.data.db.CaptureRuleEntity
import com.aymman.notificationvault.data.prefs.AppSettings
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.prefs.ThemeMode
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.RetentionPolicy
import com.aymman.notificationvault.domain.export.BackupCrypto
import com.aymman.notificationvault.domain.export.ExportFormat
import com.aymman.notificationvault.service.ListenerStatus
import com.aymman.notificationvault.notify.SummaryScheduler
import com.aymman.notificationvault.notify.VaultNotifier
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import com.aymman.notificationvault.data.media.WhatsAppImporter
import com.aymman.notificationvault.data.security.PinManager
import com.aymman.notificationvault.ui.common.UiMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepo: SettingsRepository,
    private val repository: VaultRepository,
    private val backupManager: BackupManager,
    private val status: ListenerStatus,
    private val pinManager: PinManager,
    private val whatsAppImporter: WhatsAppImporter,
    private val notifier: VaultNotifier,
    @ApplicationContext private val appContext: Context,
) : ViewModel() {

    val pinState: StateFlow<PinManager.State> = pinManager.state

    val settings: StateFlow<AppSettings?> = settingsRepo.settings
        .map<AppSettings, AppSettings?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val rules: StateFlow<List<CaptureRuleEntity>> = repository.observeRules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val apps: StateFlow<List<AppSummary>> = repository.observeAppSummaries()
        .map { list -> list.sortedBy { it.appLabel.lowercase() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val total: StateFlow<Int> = repository.observeTotal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val oldest: StateFlow<Long?> = repository.observeOldest().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val conversationCount: StateFlow<Int> = repository.observeConversationCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val history: StateFlow<List<BackupRecordEntity>> = repository.observeBackupHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val attachmentCount: StateFlow<Int> = repository.observeAttachmentCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val attachmentBytes: StateFlow<Long> = repository.observeAttachmentBytes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    val connected: StateFlow<Boolean> = status.connected
    val lastCaptureAt: StateFlow<Long?> = status.lastCaptureAt

    private val _accessGranted = MutableStateFlow(status.isAccessGranted())
    val accessGranted: StateFlow<Boolean> = _accessGranted.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 4)
    val messages: SharedFlow<UiMessage> = _messages.asSharedFlow()

    fun refreshAccess() {
        _accessGranted.value = status.isAccessGranted()
    }

    // ---- general / appearance
    fun setTheme(mode: ThemeMode) = viewModelScope.launch { settingsRepo.setThemeMode(mode) }
    fun setDynamicColor(v: Boolean) = viewModelScope.launch { settingsRepo.setDynamicColor(v) }

    // ---- privacy
    fun setBiometric(v: Boolean) = viewModelScope.launch { settingsRepo.setBiometricLock(v) }
    fun setPrivateMode(v: Boolean) = viewModelScope.launch { settingsRepo.setPrivateMode(v) }

    // ---- app PIN
    fun setPin(pin: String) = viewModelScope.launch {
        pinManager.setPin(pin)
        _messages.tryEmit(UiMessage(R.string.pin_set_done))
    }

    suspend fun verifyPin(pin: String): PinManager.VerifyResult = pinManager.verify(pin)

    fun disablePin() {
        pinManager.disable()
        _messages.tryEmit(UiMessage(R.string.pin_disabled_done))
    }

    fun setPinBiometric(v: Boolean) = pinManager.setBiometric(v)
    fun setAutoLock(seconds: Int) = viewModelScope.launch { settingsRepo.setAutoLockSeconds(seconds) }

    // ---- alerts & summary
    fun canPostNotifications(): Boolean = notifier.canPost()
    fun setDeletionAlerts(v: Boolean) = viewModelScope.launch { settingsRepo.setDeletionAlerts(v) }
    fun setAlertShowText(v: Boolean) = viewModelScope.launch { settingsRepo.setAlertShowText(v) }
    fun setGroupSimilar(v: Boolean) = viewModelScope.launch { settingsRepo.setGroupSimilar(v) }
    fun setSaveWhatsAppMedia(v: Boolean) = viewModelScope.launch { settingsRepo.setSaveWhatsAppMedia(v) }

    fun setDailySummary(enabled: Boolean, hour: Int) = viewModelScope.launch {
        settingsRepo.setDailySummary(enabled)
        settingsRepo.setSummaryHour(hour)
        SummaryScheduler.schedule(appContext, enabled, hour)
    }

    // ---- images
    fun setSaveImages(v: Boolean) = viewModelScope.launch { settingsRepo.setSaveImages(v) }

    fun isWhatsAppFolderAccessible(uri: String?): Boolean = whatsAppImporter.isFolderAccessible(uri)

    fun setWhatsAppFolder(uri: String?) = viewModelScope.launch {
        settingsRepo.setWhatsAppFolderUri(uri)
        if (uri != null) importWhatsAppNow()
    }

    fun importWhatsAppNow() = runBusy {
        val r = whatsAppImporter.importRecent(java.util.concurrent.TimeUnit.DAYS.toMillis(7))
        _messages.tryEmit(
            if (r.folderReadable) UiMessage(R.string.wa_import_done, listOf(r.imported)) else UiMessage(R.string.wa_folder_unreadable),
        )
    }

    // ---- capture
    fun setCapture(v: Boolean) = viewModelScope.launch { settingsRepo.setCaptureEnabled(v) }
    fun setSkipOngoing(v: Boolean) = viewModelScope.launch { settingsRepo.setSkipOngoing(v) }
    fun setSkipSummaries(v: Boolean) = viewModelScope.launch { settingsRepo.setSkipGroupSummaries(v) }
    fun setFilterSystem(v: Boolean) = viewModelScope.launch { settingsRepo.setFilterSystemNoise(v) }
    fun addKeyword(k: String) = viewModelScope.launch { repository.addKeywordRule(k) }
    fun deleteRule(id: Long) = viewModelScope.launch { repository.deleteRule(id) }
    fun setRuleEnabled(id: Long, v: Boolean) = viewModelScope.launch { repository.setRuleEnabled(id, v) }
    fun setAppCapture(pkg: String, v: Boolean) = viewModelScope.launch { repository.setAppCaptureEnabled(pkg, v) }

    // ---- storage
    fun setRetention(days: Int) = viewModelScope.launch { settingsRepo.setRetentionDays(days) }

    fun runCleanupNow() = viewModelScope.launch {
        val days = settingsRepo.current().retentionDays
        val n = repository.applyRetention(days)
        settingsRepo.setLastCleanupAt(System.currentTimeMillis())
        _messages.tryEmit(UiMessage(R.string.storage_cleanup_done, listOf(n)))
    }

    suspend fun countOlderThan(days: Int): Int {
        val cutoff = RetentionPolicy.cutoffMillis(System.currentTimeMillis(), days) ?: return 0
        return repository.countOlderThan(cutoff)
    }

    fun deleteOlderThan(days: Int) = viewModelScope.launch {
        val cutoff = RetentionPolicy.cutoffMillis(System.currentTimeMillis(), days) ?: return@launch
        val n = repository.deleteOlderThan(cutoff)
        _messages.tryEmit(UiMessage(R.string.deleted_count, listOf(n)))
    }

    fun deleteAll() = viewModelScope.launch {
        val n = repository.deleteAll()
        _messages.tryEmit(UiMessage(R.string.deleted_count, listOf(n)))
    }

    fun addCategory(name: String) = viewModelScope.launch { settingsRepo.addCategory(name) }
    fun removeCategory(name: String) = viewModelScope.launch {
        settingsRepo.removeCategory(name)
        repository.clearUserCategory(name)
    }

    // ---- export / backup
    fun exportAll(uri: Uri, format: ExportFormat) = runBusy {
        val n = backupManager.export(uri, format, null)
        _messages.tryEmit(UiMessage(R.string.export_done, listOf(n)))
    }

    fun backup(uri: Uri, password: CharArray?) = runBusy {
        try {
            val n = backupManager.backup(uri, password)
            _messages.tryEmit(UiMessage(R.string.backup_done, listOf(n)))
        } finally {
            password?.fill('\u0000')
        }
    }

    suspend fun isEncrypted(uri: Uri): Boolean = runCatching { backupManager.isEncrypted(uri) }.getOrDefault(false)

    fun restore(uri: Uri, password: CharArray?) = runBusy {
        try {
            val r = backupManager.restore(uri, password)
            _messages.tryEmit(UiMessage(R.string.backup_restore_done, listOf(r.inserted, r.skipped)))
        } catch (e: BackupCrypto.WrongPasswordException) {
            _messages.tryEmit(UiMessage(R.string.backup_wrong_password))
        } catch (e: IllegalArgumentException) {
            _messages.tryEmit(UiMessage(R.string.backup_invalid, listOf(e.message ?: "")))
        } finally {
            password?.fill('\u0000')
        }
    }

    private fun runBusy(block: suspend () -> Unit) = viewModelScope.launch {
        _busy.value = true
        try {
            block()
        } catch (e: Exception) {
            _messages.tryEmit(UiMessage(R.string.operation_failed))
        } finally {
            _busy.value = false
        }
    }
}

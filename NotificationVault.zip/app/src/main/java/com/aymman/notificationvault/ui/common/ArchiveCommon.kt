package com.aymman.notificationvault.ui.common

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Surface
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import com.aymman.notificationvault.domain.Grouping
import com.aymman.notificationvault.domain.Run
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.export.ExportFormat
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/** A one-shot message for the snackbar. */
data class UiMessage(@StringRes val res: Int, val args: List<Any> = emptyList())

@Composable
fun UiMessage.text(): String = stringResource(res, *args.toTypedArray())

fun UiMessage.resolve(context: Context): String = context.getString(res, *args.toTypedArray())

/** Shared actions for every screen that lists archived notifications. */
abstract class BaseArchiveViewModel(
    protected val repository: VaultRepository,
    private val backupManager: BackupManager,
) : ViewModel() {

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 4)
    val messages: SharedFlow<UiMessage> = _messages.asSharedFlow()

    protected fun emit(msg: UiMessage) {
        _messages.tryEmit(msg)
    }

    fun setRead(ids: List<Long>, read: Boolean) = viewModelScope.launch { repository.setRead(ids, read) }
    fun setPinned(ids: List<Long>, pinned: Boolean) = viewModelScope.launch { repository.setPinned(ids, pinned) }
    fun setBookmarked(ids: List<Long>, value: Boolean) = viewModelScope.launch { repository.setBookmarked(ids, value) }

    fun delete(ids: List<Long>) = viewModelScope.launch {
        val n = repository.delete(ids)
        emit(UiMessage(R.string.deleted_count, listOf(n)))
    }

    fun export(uri: Uri, format: ExportFormat, ids: List<Long>?) = viewModelScope.launch {
        try {
            val n = backupManager.export(uri, format, ids)
            emit(UiMessage(R.string.export_done, listOf(n)))
        } catch (e: Exception) {
            emit(UiMessage(R.string.export_failed))
        }
    }
}

@Stable
class SelectionState(initial: Set<Long> = emptySet()) {
    var selected by mutableStateOf(initial)
        private set
    val active: Boolean get() = selected.isNotEmpty()

    fun toggle(id: Long) {
        selected = if (id in selected) selected - id else selected + id
    }

    fun set(ids: Collection<Long>) {
        selected = ids.toSet()
    }

    fun clear() {
        selected = emptySet()
    }

    /** Drops ids that are no longer present (e.g. after deletion). */
    fun retain(existing: Set<Long>) {
        if (selected.any { it !in existing }) selected = selected.intersect(existing)
    }

    companion object {
        val Saver: Saver<SelectionState, LongArray> = Saver(
            save = { it.selected.toLongArray() },
            restore = { SelectionState(it.toSet()) },
        )
    }
}

@Composable
fun rememberSelection(): SelectionState = rememberSaveable(saver = SelectionState.Saver) { SelectionState() }

/** Groups rows under day headers (when [byDay]) and renders them with selection support. */
@Composable
fun ArchiveList(
    rows: List<NotificationRow>,
    selection: SelectionState,
    showApp: Boolean,
    byDay: Boolean,
    onOpen: (Long) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyListState = rememberLazyListState(),
    contentPadding: PaddingValues = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
    header: (LazyListScope.() -> Unit)? = null,
    groupSimilar: Boolean = false,
    empty: @Composable () -> Unit = {},
) {
    // Expanded groups are remembered by key while the screen is shown.
    val expanded = remember { mutableStateMapOf<String, Boolean>() }
    LazyColumn(modifier = modifier.fillMaxSize(), state = state, contentPadding = contentPadding) {
        header?.invoke(this)
        if (rows.isEmpty()) {
            item(key = "empty") { empty() }
            return@LazyColumn
        }
        val sections: List<Pair<java.time.LocalDate?, List<NotificationRow>>> =
            if (byDay) rows.groupBy { Formatters.localDate(it.n.receivedAt) }.map { (d, r) -> d to r } else listOf(null to rows)
        sections.forEach { (day, sectionRows) ->
            if (day != null) {
                item(key = "h_$day", contentType = "header") { SectionHeader(dayHeader(day)) }
            }
            val runs = if (groupSimilar) Grouping.runs(sectionRows, keyOf = ::groupKey) else sectionRows.map { Run.Single(it) }
            runs.forEach { run ->
                when (run) {
                    is Run.Single -> item(key = run.item.n.id, contentType = "row") {
                        RowWithSpacing(run.item, selection, showApp, onOpen)
                    }
                    is Run.Group -> {
                        val gk = "g_${day}_${run.key}"
                        val open = expanded[gk] == true
                        item(key = gk, contentType = "group") {
                            GroupHeaderRow(
                                rows = run.items,
                                expanded = open,
                                selection = selection,
                                onToggle = { expanded[gk] = !open },
                            )
                        }
                        if (open) {
                            items(run.items, key = { it.n.id }, contentType = { "row" }) { row ->
                                Box(Modifier.padding(start = 20.dp)) { RowWithSpacing(row, selection, showApp, onOpen) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Repetitive app notifications (likes, promotions, updates) group by app; personal messages never group. */
private fun groupKey(row: NotificationRow): String? =
    if (row.n.isFromMessagingStyle || row.kind() == com.aymman.notificationvault.domain.model.NotificationKind.MESSAGE ||
        row.n.deletedAt != null || row.n.isPinned
    ) null else row.n.packageName

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun GroupHeaderRow(
    rows: List<NotificationRow>,
    expanded: Boolean,
    selection: SelectionState,
    onToggle: () -> Unit,
) {
    val first = rows.first()
    val unread = rows.count { !it.n.isRead }
    val allSelected = rows.all { it.n.id in selection.selected }
    Surface(
        color = if (allSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(MaterialTheme.shapes.medium)
            .combinedClickable(
                onClick = {
                    if (selection.active) {
                        val ids = rows.map { it.n.id }
                        selection.set(if (allSelected) selection.selected - ids.toSet() else selection.selected + ids)
                    } else onToggle()
                },
                onLongClick = { selection.set(selection.selected + rows.map { it.n.id }) },
            ),
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                AppIcon(first.n.packageName, first.appLabel, size = 42.dp)
                Box(
                    Modifier.align(Alignment.BottomEnd).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondary)
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                ) {
                    Text(
                        if (rows.size > 99) "99+" else rows.size.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondary,
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.group_title, first.appLabel ?: first.n.packageName, rows.size),
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    first.body(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (unread > 0) {
                    Text(
                        stringResource(R.string.group_unread, unread),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            Icon(
                if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                contentDescription = stringResource(if (expanded) R.string.group_collapse else R.string.group_expand),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun RowWithSpacing(row: NotificationRow, selection: SelectionState, showApp: Boolean, onOpen: (Long) -> Unit) {
    NotificationListItem(
        row = row,
        selected = row.n.id in selection.selected,
        selectionMode = selection.active,
        showApp = showApp,
        onClick = { if (selection.active) selection.toggle(row.n.id) else onOpen(row.n.id) },
        onLongClick = { selection.toggle(row.n.id) },
    )
    Spacer(Modifier.height(8.dp))
}

/**
 * Action icons for the selection top bar: read/unread, pin, bookmark, and an overflow menu with
 * share, export, select-all and delete. Destructive and bulk actions ask for confirmation.
 */
@Composable
fun SelectionActions(
    rows: List<NotificationRow>,
    selection: SelectionState,
    vm: BaseArchiveViewModel,
) {
    val context = LocalContext.current
    val selectedRows = rows.filter { it.n.id in selection.selected }
    val ids = selectedRows.map { it.n.id }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmShare by remember { mutableStateOf(false) }
    val exporter = rememberExporter(vm)

    val anyUnread = selectedRows.any { !it.n.isRead }
    IconButton(onClick = { vm.setRead(ids, anyUnread); selection.clear() }) {
        Icon(
            if (anyUnread) Icons.Filled.DoneAll else Icons.Filled.MarkEmailUnread,
            contentDescription = stringResource(if (anyUnread) R.string.action_mark_read else R.string.action_mark_unread),
        )
    }
    val allPinned = selectedRows.isNotEmpty() && selectedRows.all { it.n.isPinned }
    IconButton(onClick = { vm.setPinned(ids, !allPinned); selection.clear() }) {
        Icon(Icons.Filled.PushPin, contentDescription = stringResource(if (allPinned) R.string.action_unpin else R.string.action_pin))
    }
    val allBookmarked = selectedRows.isNotEmpty() && selectedRows.all { it.n.isBookmarked }
    IconButton(onClick = { vm.setBookmarked(ids, !allBookmarked); selection.clear() }) {
        Icon(
            Icons.Filled.Bookmark,
            contentDescription = stringResource(if (allBookmarked) R.string.action_remove_bookmark else R.string.action_bookmark),
        )
    }
    androidx.compose.foundation.layout.Box {
    IconButton(onClick = { menu = true }) {
        Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.action_more))
    }
    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
        DropdownMenuItem(
            text = { Text(stringResource(R.string.action_select_all)) },
            leadingIcon = { Icon(Icons.Outlined.SelectAll, null) },
            onClick = { menu = false; selection.set(rows.map { it.n.id }) },
        )
        DropdownMenuItem(
            text = { Text(stringResource(R.string.action_share)) },
            leadingIcon = { Icon(Icons.Outlined.Share, null) },
            onClick = {
                menu = false
                if (selectedRows.size > SHARE_CONFIRM_THRESHOLD) confirmShare = true else shareRows(context, selectedRows)
            },
        )
        DropdownMenuItem(
            text = { Text(stringResource(R.string.action_export)) },
            leadingIcon = { Icon(Icons.Outlined.FileDownload, null) },
            onClick = { menu = false; exporter(ids) },
        )
        DropdownMenuItem(
            text = { Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error) },
            leadingIcon = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
            onClick = { menu = false; confirmDelete = true },
        )
    }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            body = stringResource(R.string.confirm_delete_body, ids.size),
            confirmLabel = stringResource(R.string.action_delete),
            onConfirm = { vm.delete(ids); selection.clear() },
            onDismiss = { confirmDelete = false },
        )
    }
    if (confirmShare) {
        ConfirmDialog(
            title = stringResource(R.string.action_share),
            body = stringResource(R.string.confirm_share_many, selectedRows.size),
            confirmLabel = stringResource(R.string.action_continue),
            destructive = false,
            onConfirm = { shareRows(context, selectedRows) },
            onDismiss = { confirmShare = false },
        )
    }
}

private const val SHARE_CONFIRM_THRESHOLD = 10

/** Opens the Android Sharesheet with the archived text. Only ever called from an explicit user action. */
fun shareRows(context: Context, rows: List<NotificationRow>) {
    if (rows.isEmpty()) return
    val text = rows.joinToString("\n\n") { r ->
        buildString {
            append(r.appLabel ?: r.n.packageName).append(" · ").append(Formatters.dateTime(r.n.receivedAt)).append('\n')
            append(r.headline()).append('\n')
            append(r.body())
        }
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, null))
}

/**
 * Returns a function that asks for a format, then lets the user choose where to save (SAF).
 * Passing null exports the entire archive.
 */
@Composable
fun rememberExporter(vm: BaseArchiveViewModel): (List<Long>?) -> Unit {
    var pendingIds by remember { mutableStateOf<List<Long>?>(null) }
    var pendingAll by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }

    fun onResult(format: ExportFormat): (Uri?) -> Unit = { uri ->
        if (uri != null) vm.export(uri, format, if (pendingAll) null else pendingIds)
        pendingIds = null
        pendingAll = false
    }

    val json = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.JSON.mime), onResult(ExportFormat.JSON))
    val csv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.CSV.mime), onResult(ExportFormat.CSV))
    val txt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.TEXT.mime), onResult(ExportFormat.TEXT))

    if (showDialog) {
        ExportFormatDialog(
            onDismiss = { showDialog = false },
            onPick = { format ->
                showDialog = false
                val name = "notification-vault-${System.currentTimeMillis() / 1000}.${format.extension}"
                when (format) {
                    ExportFormat.JSON -> json.launch(name)
                    ExportFormat.CSV -> csv.launch(name)
                    ExportFormat.TEXT -> txt.launch(name)
                }
            },
        )
    }
    return { ids ->
        pendingIds = ids
        pendingAll = ids == null
        showDialog = true
    }
}

@Composable
fun ExportFormatDialog(onDismiss: () -> Unit, onPick: (ExportFormat) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.export_title)) },
        text = {
            androidx.compose.foundation.layout.Column {
                listOf(
                    ExportFormat.JSON to R.string.export_json,
                    ExportFormat.CSV to R.string.export_csv,
                    ExportFormat.TEXT to R.string.export_txt,
                ).forEach { (f, label) ->
                    TextButton(onClick = { onPick(f) }, modifier = Modifier.padding(vertical = 2.dp)) {
                        Text(stringResource(label))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

package com.aymman.notificationvault.domain.export

import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Password-based encryption for backup files.
 *
 * File layout: MAGIC (6 bytes "NVENC1") | salt (16) | iv (12) | AES-256-GCM ciphertext+tag.
 * Key: PBKDF2-HMAC-SHA256, [ITERATIONS] iterations.
 *
 * Recovery: the password is the ONLY way to open the file. It is never stored by the app.
 */
object BackupCrypto {

    private val MAGIC = "NVENC1".toByteArray(Charsets.US_ASCII)
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val KEY_BITS = 256
    private const val TAG_BITS = 128
    const val ITERATIONS = 210_000

    class WrongPasswordException : Exception("Wrong password or corrupted backup")

    fun isEncrypted(bytes: ByteArray): Boolean =
        bytes.size > MAGIC.size && bytes.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)

    fun encrypt(plain: ByteArray, password: CharArray, iterations: Int = ITERATIONS): ByteArray {
        require(password.isNotEmpty()) { "Password required" }
        val rnd = SecureRandom()
        val salt = ByteArray(SALT_LEN).also { rnd.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { rnd.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(password, salt, iterations), GCMParameterSpec(TAG_BITS, iv))
        cipher.updateAAD(MAGIC)
        val ct = cipher.doFinal(plain)
        return MAGIC + salt + iv + ct
    }

    fun decrypt(data: ByteArray, password: CharArray, iterations: Int = ITERATIONS): ByteArray {
        if (!isEncrypted(data) || data.size < MAGIC.size + SALT_LEN + IV_LEN + TAG_BITS / 8) {
            throw IllegalArgumentException("Not an encrypted Notification Vault backup")
        }
        var off = MAGIC.size
        val salt = data.copyOfRange(off, off + SALT_LEN); off += SALT_LEN
        val iv = data.copyOfRange(off, off + IV_LEN); off += IV_LEN
        val ct = data.copyOfRange(off, data.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, deriveKey(password, salt, iterations), GCMParameterSpec(TAG_BITS, iv))
        cipher.updateAAD(MAGIC)
        return try {
            cipher.doFinal(ct)
        } catch (e: AEADBadTagException) {
            throw WrongPasswordException()
        }
    }

    private fun deriveKey(password: CharArray, salt: ByteArray, iterations: Int): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, iterations, KEY_BITS)
        try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            return SecretKeySpec(bytes, "AES")
        } finally {
            spec.clearPassword()
        }
    }
}

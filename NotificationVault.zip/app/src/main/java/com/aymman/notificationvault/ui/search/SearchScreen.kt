package com.aymman.notificationvault.ui.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.automirrored.outlined.ManageSearch
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.aymman.notificationvault.R
import com.aymman.notificationvault.data.backup.BackupManager
import com.aymman.notificationvault.data.db.AppSummary
import com.aymman.notificationvault.data.db.NotificationRow
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.NotificationKind
import com.aymman.notificationvault.domain.model.ReadFilter
import com.aymman.notificationvault.domain.model.SearchFilters
import com.aymman.notificationvault.domain.model.SortOrder
import com.aymman.notificationvault.ui.common.ArchiveList
import com.aymman.notificationvault.ui.common.BaseArchiveViewModel
import com.aymman.notificationvault.ui.common.EmptyState
import com.aymman.notificationvault.ui.common.Formatters
import com.aymman.notificationvault.ui.common.SelectionActions
import com.aymman.notificationvault.ui.common.SelectionTopBar
import com.aymman.notificationvault.ui.common.kindLabel
import com.aymman.notificationvault.ui.common.rememberSelection
import com.aymman.notificationvault.ui.common.resolve
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import javax.inject.Inject

enum class DatePreset { ANY, TODAY, WEEK, MONTH, CUSTOM }

sealed interface SearchResult {
    data object Idle : SearchResult
    data object Loading : SearchResult
    data class Results(val rows: List<NotificationRow>) : SearchResult
}

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    repository: VaultRepository,
    backupManager: BackupManager,
    settings: SettingsRepository,
    savedState: SavedStateHandle,
) : BaseArchiveViewModel(repository, backupManager) {

    private val _query = MutableStateFlow(savedState.get<String>("q").orEmpty())
    val query: StateFlow<String> = _query.asStateFlow()

    private val _filters = MutableStateFlow(SearchFilters())
    val filters: StateFlow<SearchFilters> = _filters.asStateFlow()

    private val _datePreset = MutableStateFlow(DatePreset.ANY)
    val datePreset: StateFlow<DatePreset> = _datePreset.asStateFlow()

    val results: StateFlow<SearchResult> = combine(
        _query.debounce(250).map { it.trim() }.distinctUntilChanged(),
        _filters,
    ) { q, f -> f.copy(query = q) }
        .flatMapLatest { f ->
            if (f.isEmptySearch()) flowOf<SearchResult>(SearchResult.Idle)
            else repository.observeRows(f).map<List<NotificationRow>, SearchResult> { SearchResult.Results(it) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchResult.Loading)

    val apps: StateFlow<List<AppSummary>> = repository.observeAppSummaries()
        .map { list -> list.sortedBy { it.appLabel.lowercase() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val categories: StateFlow<List<String>> = repository.observeCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val userCategories: StateFlow<List<String>> = settings.settings.map { it.customCategories.sorted() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val senders: StateFlow<List<String>> = _filters.map { it.packageName }.distinctUntilChanged()
        .flatMapLatest { repository.observeSenders(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(q: String) {
        _query.value = q
    }

    fun update(transform: (SearchFilters) -> SearchFilters) = _filters.update(transform)

    fun setDatePreset(preset: DatePreset, customFrom: Long? = null, customTo: Long? = null) {
        _datePreset.value = preset
        val now = System.currentTimeMillis()
        val start = Formatters.startOfToday()
        val (from, to) = when (preset) {
            DatePreset.ANY -> null to null
            DatePreset.TODAY -> start to null
            DatePreset.WEEK -> (start - 6 * DAY) to null
            DatePreset.MONTH -> (start - 29 * DAY) to null
            DatePreset.CUSTOM -> customFrom to customTo
        }
        _filters.update { it.copy(fromMillis = from, toMillis = to?.coerceAtMost(now + DAY)) }
    }

    fun reset() {
        _filters.value = SearchFilters()
        _datePreset.value = DatePreset.ANY
    }

    companion object {
        private const val DAY = 24L * 60 * 60 * 1000

        fun SearchFilters.isEmptySearch(): Boolean = copy(sort = SortOrder.NEWEST) == SearchFilters()

        fun SearchFilters.activeCount(): Int = listOf(
            packageName != null, kind != null, category != null, userCategory != null,
            fromMillis != null || toMillis != null, read != ReadFilter.ALL, pinnedOnly, bookmarkedOnly, sender != null, deletedOnly,
        ).count { it }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(onBack: () -> Unit, onOpenDetail: (Long) -> Unit, vm: SearchViewModel = hiltViewModel()) {
    val query by vm.query.collectAsStateWithLifecycle()
    val filters by vm.filters.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val selection = rememberSelection()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    var showFilters by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (query.isEmpty()) runCatching { focus.requestFocus() } }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it.resolve(context)) } }
    val rows = (results as? SearchResult.Results)?.rows.orEmpty()
    LaunchedEffect(rows) { selection.retain(rows.map { it.n.id }.toSet()) }
    val active = with(SearchViewModel) { filters.activeCount() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selection.active) {
                SelectionTopBar(selection.selected.size, onClear = selection::clear) { SelectionActions(rows, selection, vm) }
            } else {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.action_back)) }
                    TextField(
                        value = query,
                        onValueChange = vm::setQuery,
                        placeholder = { Text(stringResource(R.string.search_hint), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        singleLine = true,
                        shape = CircleShape,
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                        ),
                        trailingIcon = if (query.isNotEmpty()) {
                            { IconButton(onClick = { vm.setQuery("") }) { Icon(Icons.Filled.Close, stringResource(R.string.action_clear)) } }
                        } else null,
                        modifier = Modifier.weight(1f).focusRequester(focus),
                    )
                    IconButton(onClick = { showFilters = true }) {
                        BadgedBox(badge = { if (active > 0) Badge { Text(active.toString()) } }) {
                            Icon(Icons.Outlined.FilterList, stringResource(R.string.search_filters))
                        }
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (val r = results) {
                SearchResult.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                SearchResult.Idle -> EmptyState(
                    title = stringResource(R.string.action_search),
                    body = stringResource(R.string.search_start),
                    icon = Icons.AutoMirrored.Outlined.ManageSearch,
                )
                is SearchResult.Results -> ArchiveList(
                    rows = r.rows,
                    selection = selection,
                    showApp = true,
                    byDay = false,
                    onOpen = onOpenDetail,
                    header = {
                        item(key = "count") {
                            Text(
                                stringResource(R.string.search_results, r.rows.size),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 8.dp),
                            )
                        }
                    },
                    empty = {
                        EmptyState(
                            stringResource(R.string.search_empty_title),
                            stringResource(R.string.search_empty_body),
                            icon = Icons.Outlined.SearchOff,
                        )
                    },
                )
            }
        }
    }

    if (showFilters) FilterSheet(vm = vm, onDismiss = { showFilters = false })
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun FilterSheet(vm: SearchViewModel, onDismiss: () -> Unit) {
    val filters by vm.filters.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val userCategories by vm.userCategories.collectAsStateWithLifecycle()
    val senders by vm.senders.collectAsStateWithLifecycle()
    val preset by vm.datePreset.collectAsStateWithLifecycle()
    var showRangePicker by remember { mutableStateOf(false) }
    var showAllApps by remember { mutableStateOf(false) }
    var showAllSenders by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding(),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.search_filters), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::reset) { Text(stringResource(R.string.filter_reset)) }
            }

            FilterGroup(stringResource(R.string.filter_app)) {
                ChipOption(stringResource(R.string.filter_any_app), filters.packageName == null) { vm.update { it.copy(packageName = null, sender = null) } }
                val shown = if (showAllApps) apps else apps.take(12)
                shown.forEach { a ->
                    ChipOption(a.appLabel, filters.packageName == a.packageName) {
                        vm.update { it.copy(packageName = if (it.packageName == a.packageName) null else a.packageName, sender = null) }
                    }
                }
                if (!showAllApps && apps.size > 12) ChipOption("+${apps.size - 12}", false) { showAllApps = true }
            }

            FilterGroup(stringResource(R.string.filter_type)) {
                (listOf<NotificationKind?>(null) + NotificationKind.entries).forEach { k ->
                    ChipOption(kindLabel(k), filters.kind == k) { vm.update { it.copy(kind = k) } }
                }
            }

            FilterGroup(stringResource(R.string.filter_date)) {
                listOf(
                    DatePreset.ANY to R.string.date_any,
                    DatePreset.TODAY to R.string.date_today,
                    DatePreset.WEEK to R.string.date_7,
                    DatePreset.MONTH to R.string.date_30,
                ).forEach { (p, label) -> ChipOption(stringResource(label), preset == p) { vm.setDatePreset(p) } }
                val customLabel = if (preset == DatePreset.CUSTOM && filters.fromMillis != null) {
                    "${Formatters.date(filters.fromMillis!!)} – ${filters.toMillis?.let { Formatters.date(it) } ?: "…"}"
                } else stringResource(R.string.date_custom)
                ChipOption(customLabel, preset == DatePreset.CUSTOM) { showRangePicker = true }
            }

            FilterGroup(stringResource(R.string.filter_status)) {
                listOf(ReadFilter.ALL to R.string.read_all, ReadFilter.UNREAD to R.string.read_unread, ReadFilter.READ to R.string.read_read)
                    .forEach { (rf, label) -> ChipOption(stringResource(label), filters.read == rf) { vm.update { it.copy(read = rf) } } }
                ChipOption(stringResource(R.string.filter_pinned_only), filters.pinnedOnly) { vm.update { it.copy(pinnedOnly = !it.pinnedOnly) } }
                ChipOption(stringResource(R.string.filter_bookmarked_only), filters.bookmarkedOnly) { vm.update { it.copy(bookmarkedOnly = !it.bookmarkedOnly) } }
                ChipOption("🗑️ " + stringResource(R.string.filter_deleted), filters.deletedOnly) { vm.update { it.copy(deletedOnly = !it.deletedOnly) } }
            }

            if (senders.isNotEmpty()) {
                FilterGroup(stringResource(R.string.filter_sender)) {
                    ChipOption(stringResource(R.string.filter_any_sender), filters.sender == null) { vm.update { it.copy(sender = null) } }
                    val shown = if (showAllSenders) senders else senders.take(15)
                    shown.forEach { s ->
                        ChipOption(s, filters.sender == s) { vm.update { it.copy(sender = if (it.sender == s) null else s) } }
                    }
                    if (!showAllSenders && senders.size > 15) ChipOption("+${senders.size - 15}", false) { showAllSenders = true }
                }
            }

            if (categories.isNotEmpty()) {
                FilterGroup(stringResource(R.string.filter_category)) {
                    ChipOption(stringResource(R.string.filter_any), filters.category == null) { vm.update { it.copy(category = null) } }
                    categories.forEach { c -> ChipOption(c, filters.category == c) { vm.update { it.copy(category = if (it.category == c) null else c) } } }
                }
            }

            if (userCategories.isNotEmpty()) {
                FilterGroup(stringResource(R.string.filter_user_category)) {
                    ChipOption(stringResource(R.string.filter_any), filters.userCategory == null) { vm.update { it.copy(userCategory = null) } }
                    userCategories.forEach { c ->
                        ChipOption(c, filters.userCategory == c) { vm.update { it.copy(userCategory = if (it.userCategory == c) null else c) } }
                    }
                }
            }

            FilterGroup(stringResource(R.string.action_sort)) {
                listOf(
                    SortOrder.NEWEST to R.string.sort_newest,
                    SortOrder.OLDEST to R.string.sort_oldest,
                    SortOrder.APP to R.string.sort_app,
                    SortOrder.SENDER to R.string.sort_sender,
                ).forEach { (s, label) -> ChipOption(stringResource(label), filters.sort == s) { vm.update { it.copy(sort = s) } } }
            }

            Spacer(Modifier.height(16.dp))
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.filter_apply)) }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (showRangePicker) {
        val state = rememberDateRangePickerState()
        DatePickerDialog(
            onDismissRequest = { showRangePicker = false },
            confirmButton = {
                TextButton(
                    enabled = state.selectedStartDateMillis != null,
                    onClick = {
                        // Picker returns UTC midnight; convert to local day bounds.
                        val from = state.selectedStartDateMillis?.let { utcDayToLocalStart(it) }
                        val to = (state.selectedEndDateMillis ?: state.selectedStartDateMillis)?.let { utcDayToLocalStart(it) + DAY_MS - 1 }
                        vm.setDatePreset(DatePreset.CUSTOM, from, to)
                        showRangePicker = false
                    },
                ) { Text(stringResource(R.string.action_ok)) }
            },
            dismissButton = { TextButton(onClick = { showRangePicker = false }) { Text(stringResource(R.string.action_cancel)) } },
        ) {
            DateRangePicker(state = state, modifier = Modifier.weight(1f))
        }
    }
}

private const val DAY_MS = 24L * 60 * 60 * 1000

private fun utcDayToLocalStart(utcMillis: Long): Long {
    val date = Instant.ofEpochMilli(utcMillis).atZone(ZoneOffset.UTC).toLocalDate()
    return date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FilterGroup(title: String, content: @Composable () -> Unit) {
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
}

@Composable
private fun ChipOption(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
    )
}

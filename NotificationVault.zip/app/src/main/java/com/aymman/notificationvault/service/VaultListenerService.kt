package com.aymman.notificationvault.service

import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.aymman.notificationvault.data.prefs.AppSettings
import com.aymman.notificationvault.data.prefs.SettingsRepository
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.RawNotification
import com.aymman.notificationvault.util.AppInfoResolver
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * Receives notifications from the system once the user grants Notification Access.
 * Records are archived immediately; removal events only annotate records, never delete them.
 */
@AndroidEntryPoint
class VaultListenerService : NotificationListenerService() {

    @Inject lateinit var repository: VaultRepository
    @Inject lateinit var settingsRepository: SettingsRepository
    @Inject lateinit var appInfo: AppInfoResolver
    @Inject lateinit var status: ListenerStatus

    private val errorHandler = CoroutineExceptionHandler { _, e ->
        // Never log notification content — only the error type.
        Log.w(TAG, "Capture error: ${e.javaClass.simpleName}")
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO + errorHandler)
    private val writeLock = Mutex()

    @Volatile private var settings: AppSettings = AppSettings()

    override fun onCreate() {
        super.onCreate()
        scope.launch { settingsRepository.settings.collect { settings = it } }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        status.setConnected(true)
        scope.launch {
            settings = settingsRepository.current()
            // Archive what is already visible in the shade (it is accessible content right now).
            val active = try {
                activeNotifications?.toList().orEmpty()
            } catch (e: SecurityException) {
                emptyList()
            } catch (e: RuntimeException) {
                emptyList()
            }
            active.forEach { sbn -> safeExtract(sbn)?.let { archive(it) } }
            maybeRunRetention()
        }
    }

    override fun onListenerDisconnected() {
        status.setConnected(false)
        // Ask the system to bind us again (e.g. after a crash or update). Requires access to still be granted.
        try {
            NotificationListenerService.requestRebind(ComponentName(this, VaultListenerService::class.java))
        } catch (e: RuntimeException) {
            Log.w(TAG, "requestRebind failed: ${e.javaClass.simpleName}")
        }
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!settings.captureEnabled) return
        if (sbn.packageName == packageName) return
        // Extract on the binder thread (cheap) so we don't hold a reference to the live notification.
        val raw = safeExtract(sbn) ?: return
        scope.launch { archive(raw) }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val key = sbn?.key ?: return
        if (sbn.packageName == packageName) return
        scope.launch { writeLock.withLock { repository.onRemoved(key) } }
    }

    override fun onDestroy() {
        status.setConnected(false)
        scope.cancel()
        super.onDestroy()
    }

    private fun safeExtract(sbn: StatusBarNotification): RawNotification? = try {
        NotificationExtractor.extract(sbn)
    } catch (e: Exception) {
        Log.w(TAG, "Unreadable notification from ${sbn.packageName}: ${e.javaClass.simpleName}")
        null
    }

    private suspend fun archive(raw: RawNotification) {
        val label = appInfo.label(raw.packageName)
        writeLock.withLock {
            val added = repository.capture(raw, label, settings)
            if (added > 0) status.onCaptured()
        }
    }

    private suspend fun maybeRunRetention() {
        val s = settingsRepository.current()
        val now = System.currentTimeMillis()
        if (now - s.lastCleanupAt < TimeUnit.HOURS.toMillis(6)) return
        writeLock.withLock { repository.applyRetention(s.retentionDays) }
        settingsRepository.setLastCleanupAt(now)
    }

    companion object {
        private const val TAG = "NV.Listener"

        fun componentName(context: Context) = ComponentName(context, VaultListenerService::class.java)
    }
}

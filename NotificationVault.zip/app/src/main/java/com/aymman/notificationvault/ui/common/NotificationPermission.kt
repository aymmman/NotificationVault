package com.aymman.notificationvault.ui.common

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.aymman.notificationvault.data.prefs.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class PermissionViewModel @Inject constructor(private val settings: SettingsRepository) : ViewModel() {
    suspend fun shouldAsk(): Boolean = settings.markNotificationPermissionAsked()
}

/**
 * Asks once (Android 13+) for permission to post the app's own alerts. Declining is fine: capture
 * still works, only deletion alerts and the daily summary are not shown.
 */
@Composable
fun NotificationPermissionRequest(vm: PermissionViewModel = hiltViewModel()) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted && vm.shouldAsk()) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}

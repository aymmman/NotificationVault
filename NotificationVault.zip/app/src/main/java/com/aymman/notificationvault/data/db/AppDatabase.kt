package com.aymman.notificationvault.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        MonitoredAppEntity::class,
        ArchivedNotificationEntity::class,
        ConversationEntity::class,
        CaptureRuleEntity::class,
        BackupRecordEntity::class,
        AttachmentEntity::class,
    ],
    version = AppDatabase.VERSION,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun notificationDao(): NotificationDao
    abstract fun appDao(): AppDao
    abstract fun conversationDao(): ConversationDao
    abstract fun captureRuleDao(): CaptureRuleDao
    abstract fun backupDao(): BackupDao
    abstract fun attachmentDao(): AttachmentDao

    companion object {
        const val VERSION = 3
        const val NAME = "notification_vault.db"

        /** v1 → v2: saved images (attachments table). Existing archives are kept intact. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `attachments` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`notificationId` INTEGER NOT NULL, " +
                        "`mimeType` TEXT NOT NULL, " +
                        "`fileName` TEXT NOT NULL, " +
                        "`width` INTEGER NOT NULL, " +
                        "`height` INTEGER NOT NULL, " +
                        "`sizeBytes` INTEGER NOT NULL, " +
                        "`source` TEXT NOT NULL, " +
                        "`originalName` TEXT, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`notificationId`) REFERENCES `notifications`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_attachments_notificationId` ON `attachments` (`notificationId`)")
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_attachments_source_originalName` ON `attachments` (`source`, `originalName`)",
                )
            }
        }

        /** v2 → v3: deletion tracking. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `notifications` ADD COLUMN `deletedAt` INTEGER")
                db.execSQL("ALTER TABLE `notifications` ADD COLUMN `isDeletionNotice` INTEGER NOT NULL DEFAULT 0")
            }
        }

        /**
         * Explicit migrations only. Destructive fallback is intentionally NOT enabled:
         * losing a user's archive on upgrade is never acceptable.
         */
        val MIGRATIONS: Array<Migration> = arrayOf(MIGRATION_1_2, MIGRATION_2_3)
    }
}

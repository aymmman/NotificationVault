package com.aymman.notificationvault.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(
    entities = [
        MonitoredAppEntity::class,
        ArchivedNotificationEntity::class,
        ConversationEntity::class,
        CaptureRuleEntity::class,
        BackupRecordEntity::class,
    ],
    version = AppDatabase.VERSION,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun notificationDao(): NotificationDao
    abstract fun appDao(): AppDao
    abstract fun conversationDao(): ConversationDao
    abstract fun captureRuleDao(): CaptureRuleDao
    abstract fun backupDao(): BackupDao

    companion object {
        const val VERSION = 1
        const val NAME = "notification_vault.db"

        /**
         * Explicit migrations are registered here as the schema evolves. Destructive fallback is
         * intentionally NOT enabled: losing a user's archive on upgrade is never acceptable.
         * Example for a future version 2:
         *   val MIGRATION_1_2 = object : Migration(1, 2) { override fun migrate(db: SupportSQLiteDatabase) { … } }
         */
        val MIGRATIONS: Array<Migration> = emptyArray()
    }
}

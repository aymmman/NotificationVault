package com.aymman.notificationvault.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RawQuery
import androidx.room.Upsert
import androidx.sqlite.db.SupportSQLiteQuery
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {

    /** Returns -1 when the dedup key already exists (duplicate). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: ArchivedNotificationEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(entities: List<ArchivedNotificationEntity>): List<Long>

    @Query("SELECT * FROM notifications WHERE id = :id")
    fun observe(id: Long): Flow<ArchivedNotificationEntity?>

    @Query("SELECT * FROM notifications WHERE id = :id")
    suspend fun get(id: Long): ArchivedNotificationEntity?

    @Query("SELECT * FROM notifications WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<ArchivedNotificationEntity>

    @Query("SELECT * FROM notifications ORDER BY receivedAt DESC")
    suspend fun getAll(): List<ArchivedNotificationEntity>

    @RawQuery(observedEntities = [ArchivedNotificationEntity::class, MonitoredAppEntity::class])
    fun observeRows(query: SupportSQLiteQuery): Flow<List<NotificationRow>>

    @Query(
        """SELECT n.*, a.appLabel AS appLabel FROM notifications n
           LEFT JOIN apps a ON a.packageName = n.packageName
           WHERE n.id = :id""",
    )
    fun observeRow(id: Long): Flow<NotificationRow?>

    @Query(
        """UPDATE notifications SET removedAt = :at
           WHERE notificationKey = :key AND removedAt IS NULL""",
    )
    suspend fun markRemoved(key: String, at: Long): Int

    @Query("UPDATE notifications SET isRead = :read WHERE id IN (:ids)")
    suspend fun setRead(ids: List<Long>, read: Boolean)

    @Query("UPDATE notifications SET isRead = 1 WHERE packageName = :pkg AND isRead = 0")
    suspend fun markAppRead(pkg: String)

    @Query("UPDATE notifications SET isRead = 1 WHERE isRead = 0")
    suspend fun markAllRead()

    @Query("UPDATE notifications SET isPinned = :pinned WHERE id IN (:ids)")
    suspend fun setPinned(ids: List<Long>, pinned: Boolean)

    @Query("UPDATE notifications SET isBookmarked = :value WHERE id IN (:ids)")
    suspend fun setBookmarked(ids: List<Long>, value: Boolean)

    @Query("UPDATE notifications SET userCategory = :category WHERE id IN (:ids)")
    suspend fun setUserCategory(ids: List<Long>, category: String?)

    @Query("UPDATE notifications SET userCategory = NULL WHERE userCategory = :category")
    suspend fun clearUserCategory(category: String)

    @Query("DELETE FROM notifications WHERE id IN (:ids)")
    suspend fun delete(ids: List<Long>): Int

    @Query("DELETE FROM notifications WHERE packageName = :pkg")
    suspend fun deleteForApp(pkg: String): Int

    @Query("DELETE FROM notifications")
    suspend fun deleteAll(): Int

    @Query(
        """DELETE FROM notifications WHERE receivedAt < :cutoff
           AND isPinned = 0 AND isBookmarked = 0 AND packageName = :pkg""",
    )
    suspend fun deleteExpiredForApp(pkg: String, cutoff: Long): Int

    @Query(
        """DELETE FROM notifications WHERE receivedAt < :cutoff AND isPinned = 0 AND isBookmarked = 0
           AND packageName NOT IN (:excludedPackages)""",
    )
    suspend fun deleteExpiredGlobal(cutoff: Long, excludedPackages: List<String>): Int

    @Query("DELETE FROM notifications WHERE receivedAt < :cutoff AND isPinned = 0 AND isBookmarked = 0")
    suspend fun deleteOlderThan(cutoff: Long): Int

    @Query("SELECT COUNT(*) FROM notifications WHERE receivedAt < :cutoff AND isPinned = 0 AND isBookmarked = 0")
    suspend fun countOlderThan(cutoff: Long): Int

    // ---- statistics ----
    @Query("SELECT COUNT(*) FROM notifications")
    fun observeTotal(): Flow<Int>

    @Query("SELECT COUNT(*) FROM notifications WHERE receivedAt >= :since")
    fun observeSince(since: Long): Flow<Int>

    @Query("SELECT COUNT(DISTINCT packageName) FROM notifications WHERE receivedAt >= :since")
    fun observeAppsSince(since: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM notifications WHERE isRead = 0")
    fun observeUnread(): Flow<Int>

    @Query("SELECT COUNT(*) FROM notifications WHERE isPinned = 1 OR isBookmarked = 1")
    fun observeSavedCount(): Flow<Int>

    @Query("SELECT kind, COUNT(*) AS count FROM notifications GROUP BY kind")
    fun observeKindCounts(): Flow<List<KindCount>>

    @Query("SELECT COUNT(*) FROM notifications WHERE receivedAt >= :since AND packageName = :pkg")
    suspend fun countSinceForApp(pkg: String, since: Long): Int

    @Query("SELECT MIN(receivedAt) FROM notifications")
    fun observeOldest(): Flow<Long?>

    @Query(
        """SELECT conversationId, MAX(conversationTitle) AS title, COUNT(*) AS count, MAX(receivedAt) AS lastAt
           FROM notifications WHERE packageName = :pkg AND conversationId IS NOT NULL
           GROUP BY conversationId ORDER BY lastAt DESC LIMIT 50""",
    )
    fun observeConversations(pkg: String): Flow<List<ConversationCount>>

    @Query(
        """SELECT DISTINCT senderName FROM notifications
           WHERE senderName IS NOT NULL AND (:pkg IS NULL OR packageName = :pkg)
           ORDER BY senderName COLLATE NOCASE LIMIT 300""",
    )
    fun observeSenders(pkg: String?): Flow<List<String>>

    @Query("SELECT DISTINCT category FROM notifications WHERE category IS NOT NULL ORDER BY category")
    fun observeCategories(): Flow<List<String>>
}

@Dao
interface AppDao {

    @Query("SELECT * FROM apps WHERE packageName = :pkg")
    suspend fun get(pkg: String): MonitoredAppEntity?

    @Query("SELECT * FROM apps WHERE packageName = :pkg")
    fun observe(pkg: String): Flow<MonitoredAppEntity?>

    @Query("SELECT * FROM apps ORDER BY appLabel COLLATE NOCASE")
    fun observeAll(): Flow<List<MonitoredAppEntity>>

    @Query("SELECT * FROM apps")
    suspend fun getAll(): List<MonitoredAppEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(app: MonitoredAppEntity): Long

    @Upsert
    suspend fun upsert(app: MonitoredAppEntity)

    @Query("UPDATE apps SET lastSeenAt = :at, appLabel = :label WHERE packageName = :pkg")
    suspend fun touch(pkg: String, label: String, at: Long)

    @Query("UPDATE apps SET captureEnabled = :enabled WHERE packageName = :pkg")
    suspend fun setCaptureEnabled(pkg: String, enabled: Boolean)

    @Query("UPDATE apps SET favorite = :fav WHERE packageName = :pkg")
    suspend fun setFavorite(pkg: String, fav: Boolean)

    @Query("UPDATE apps SET muted = :muted WHERE packageName = :pkg")
    suspend fun setMuted(pkg: String, muted: Boolean)

    @Query("UPDATE apps SET retentionDays = :days WHERE packageName = :pkg")
    suspend fun setRetention(pkg: String, days: Int?)

    @Query("SELECT * FROM apps WHERE retentionDays IS NOT NULL")
    suspend fun getWithRetentionOverride(): List<MonitoredAppEntity>

    @Query("SELECT COUNT(*) FROM apps WHERE captureEnabled = 1")
    fun observeMonitoredCount(): Flow<Int>

    @Query(
        """SELECT a.packageName, a.appLabel, a.favorite, a.muted, a.captureEnabled, a.retentionDays,
                  COUNT(n.id) AS total,
                  SUM(CASE WHEN n.id IS NOT NULL AND n.isRead = 0 THEN 1 ELSE 0 END) AS unread,
                  MAX(n.receivedAt) AS lastAt,
                  (SELECT COALESCE(n2.text, n2.title) FROM notifications n2
                     WHERE n2.packageName = a.packageName ORDER BY n2.receivedAt DESC LIMIT 1) AS preview
           FROM apps a LEFT JOIN notifications n ON n.packageName = a.packageName
           GROUP BY a.packageName""",
    )
    fun observeSummaries(): Flow<List<AppSummary>>
}

@Dao
interface ConversationDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(c: ConversationEntity): Long

    @Query(
        """UPDATE conversations SET lastMessageAt = MAX(lastMessageAt, :at), title = COALESCE(:title, title)
           WHERE packageName = :pkg AND conversationKey = :key""",
    )
    suspend fun touch(pkg: String, key: String, title: String?, at: Long)

    @Query("SELECT COUNT(*) FROM conversations")
    fun observeCount(): Flow<Int>
}

@Dao
interface CaptureRuleDao {
    @Query("SELECT * FROM capture_rules ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<CaptureRuleEntity>>

    @Query("SELECT * FROM capture_rules WHERE enabled = 1")
    suspend fun getEnabled(): List<CaptureRuleEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(rule: CaptureRuleEntity): Long

    @Query("DELETE FROM capture_rules WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE capture_rules SET enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)
}

@Dao
interface BackupDao {
    @Insert
    suspend fun insert(record: BackupRecordEntity): Long

    @Query("SELECT * FROM backup_history ORDER BY createdAt DESC LIMIT 30")
    fun observeRecent(): Flow<List<BackupRecordEntity>>
}

package com.aymman.notificationvault.domain

/** A run of list items: either a single item or several similar consecutive ones collapsed together. */
sealed interface Run<T> {
    data class Single<T>(val item: T) : Run<T>
    data class Group<T>(val key: String, val items: List<T>) : Run<T>
}

object Grouping {

    /**
     * Collapses consecutive items sharing the same non-null [keyOf] into a [Run.Group] when there are
     * at least [minSize] of them. Items whose key is null (e.g. personal messages) are never grouped.
     * Order is preserved.
     */
    fun <T> runs(items: List<T>, minSize: Int = 3, keyOf: (T) -> String?): List<Run<T>> {
        val out = ArrayList<Run<T>>()
        var i = 0
        while (i < items.size) {
            val key = keyOf(items[i])
            var j = i + 1
            if (key != null) {
                while (j < items.size && keyOf(items[j]) == key) j++
            }
            val count = j - i
            if (key != null && count >= minSize) {
                out += Run.Group("$key#$i", items.subList(i, j).toList())
            } else {
                for (k in i until j) out += Run.Single(items[k])
            }
            i = j
        }
        return out
    }
}

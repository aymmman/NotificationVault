package com.aymman.notificationvault.data.media

import android.content.Context
import android.graphics.drawable.Icon
import android.util.Log
import androidx.core.graphics.drawable.toBitmap
import com.aymman.notificationvault.data.db.AttachmentEntity
import com.aymman.notificationvault.data.repo.CaptureResult
import com.aymman.notificationvault.data.repo.VaultRepository
import com.aymman.notificationvault.domain.model.CapturedRecord
import com.aymman.notificationvault.service.ImageRef

/**
 * Saves the pictures a notification carries next to the record it belongs to.
 * Many apps only put a URI to the picture in the notification; Android often doesn't let other
 * apps open that URI, in which case nothing is saved (and the WhatsApp folder import can fill the gap).
 */
class ImageCapture(
    private val context: Context,
    private val repository: VaultRepository,
    private val store: AttachmentStore,
) {

    suspend fun save(result: CaptureResult, images: List<ImageRef>): Int {
        if (result.records.isEmpty() || images.isEmpty()) return 0
        var saved = 0
        for (ref in images) {
            val target: CapturedRecord = when (ref) {
                is ImageRef.FromUri -> result.records.firstOrNull { it.messageIndex == ref.messageIndex }
                // A big picture belongs to the single record, or to the newest message in the conversation.
                else -> result.records.lastOrNull()
            } ?: continue
            val id = repository.idForDedupKey(target.dedupKey) ?: continue
            if (repository.attachmentCount(id) > 0) continue

            val file = try {
                when (ref) {
                    is ImageRef.FromBitmap -> store.saveBitmap(ref.bitmap)
                    is ImageRef.FromIcon -> iconBitmap(ref.icon)?.let { store.saveBitmap(it) }
                    is ImageRef.FromUri -> readUri(ref)?.let { store.saveImage(it, ref.mimeType) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Image not saved: ${e.javaClass.simpleName}")
                null
            } ?: continue

            if (repository.addAttachment(id, file, AttachmentEntity.SOURCE_NOTIFICATION, null)) saved++
        }
        return saved
    }

    private fun iconBitmap(icon: Icon) = try {
        icon.loadDrawable(context)?.toBitmap()
    } catch (e: Exception) {
        null
    }

    private fun readUri(ref: ImageRef.FromUri): ByteArray? {
        return try {
            context.contentResolver.openInputStream(ref.uri)?.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(64 * 1024)
                var total = 0
                var tooLarge = false
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > AttachmentStore.MAX_BYTES) {
                        tooLarge = true
                        break
                    }
                    out.write(buf, 0, n)
                }
                if (tooLarge) null else out.toByteArray()
            }
        } catch (e: SecurityException) {
            // The sending app didn't grant us access to the picture. Expected for some apps.
            null
        } catch (e: Exception) {
            null
        }
    }

    private companion object {
        const val TAG = "NV.Images"
    }
}

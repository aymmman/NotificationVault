package com.aymman.notificationvault.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aymman.notificationvault.data.prefs.ThemeMode
import com.aymman.notificationvault.domain.model.NotificationKind

// Brand palette: deep indigo → violet, with a warm amber accent (the "new notification" dot).
private val Indigo900 = Color(0xFF1E1B4B)
private val Indigo700 = Color(0xFF3730A3)
private val Violet600 = Color(0xFF6D28D9)
private val Violet500 = Color(0xFF7C3AED)
private val Violet300 = Color(0xFFC4B5FD)
private val Violet100 = Color(0xFFEDE9FE)
private val Amber400 = Color(0xFFFBBF24)

private val LightColors = lightColorScheme(
    primary = Violet600,
    onPrimary = Color.White,
    primaryContainer = Violet100,
    onPrimaryContainer = Color(0xFF2E1065),
    secondary = Indigo700,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0E7FF),
    onSecondaryContainer = Indigo900,
    tertiary = Color(0xFFB45309),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFEF3C7),
    onTertiaryContainer = Color(0xFF451A03),
    background = Color(0xFFF7F7FB),
    onBackground = Color(0xFF1B1B23),
    surface = Color(0xFFF7F7FB),
    onSurface = Color(0xFF1B1B23),
    surfaceVariant = Color(0xFFE7E5F0),
    onSurfaceVariant = Color(0xFF4A4858),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF2F1F8),
    surfaceContainer = Color(0xFFECEBF4),
    surfaceContainerHigh = Color(0xFFE6E5EF),
    surfaceContainerHighest = Color(0xFFE0DFEA),
    outline = Color(0xFF7A7889),
    outlineVariant = Color(0xFFCBC8D8),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B),
)

private val DarkColors = darkColorScheme(
    primary = Violet300,
    onPrimary = Color(0xFF2E1065),
    primaryContainer = Color(0xFF4C1D95),
    onPrimaryContainer = Violet100,
    secondary = Color(0xFFA5B4FC),
    onSecondary = Indigo900,
    secondaryContainer = Color(0xFF312E81),
    onSecondaryContainer = Color(0xFFE0E7FF),
    tertiary = Amber400,
    onTertiary = Color(0xFF451A03),
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = Color(0xFFFEF3C7),
    background = Color(0xFF0F0E1A),
    onBackground = Color(0xFFE6E4F0),
    surface = Color(0xFF0F0E1A),
    onSurface = Color(0xFFE6E4F0),
    surfaceVariant = Color(0xFF2B2938),
    onSurfaceVariant = Color(0xFFC9C6D6),
    surfaceContainerLowest = Color(0xFF0A0913),
    surfaceContainerLow = Color(0xFF161522),
    surfaceContainer = Color(0xFF1B1A28),
    surfaceContainerHigh = Color(0xFF242333),
    surfaceContainerHighest = Color(0xFF2E2D3E),
    outline = Color(0xFF938FA3),
    outlineVariant = Color(0xFF3F3D4F),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410),
    errorContainer = Color(0xFF8C1D18),
    onErrorContainer = Color(0xFFF9DEDC),
)

@Immutable
data class VaultExtras(
    val heroBrush: Brush,
    val success: Color,
    val warning: Color,
    val kindColors: Map<NotificationKind, Color>,
)

val LocalVaultExtras = staticCompositionLocalOf {
    VaultExtras(
        heroBrush = Brush.linearGradient(listOf(Indigo900, Violet600)),
        success = Color(0xFF15803D),
        warning = Color(0xFFB45309),
        kindColors = emptyMap(),
    )
}

private val VaultTypography = Typography().let { t ->
    t.copy(
        displaySmall = t.displaySmall.copy(fontWeight = FontWeight.SemiBold),
        headlineMedium = t.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
        headlineSmall = t.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = t.labelLarge.copy(fontWeight = FontWeight.SemiBold),
        bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    )
}

private val VaultShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun NotificationVaultTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val colors: ColorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> DarkColors
        else -> LightColors
    }
    val extras = VaultExtras(
        heroBrush = if (dark) {
            Brush.linearGradient(listOf(Color(0xFF241F5C), Color(0xFF4C1D95)))
        } else {
            Brush.linearGradient(listOf(Indigo900, Violet500))
        },
        success = if (dark) Color(0xFF4ADE80) else Color(0xFF15803D),
        warning = if (dark) Amber400 else Color(0xFFB45309),
        kindColors = mapOf(
            NotificationKind.MESSAGE to if (dark) Color(0xFF6EE7B7) else Color(0xFF059669),
            NotificationKind.SOCIAL to if (dark) Color(0xFFF9A8D4) else Color(0xFFDB2777),
            NotificationKind.EMAIL to if (dark) Color(0xFF93C5FD) else Color(0xFF2563EB),
            NotificationKind.CALL to if (dark) Color(0xFFFCD34D) else Color(0xFFD97706),
            NotificationKind.OTHER to if (dark) Color(0xFFC4B5FD) else Color(0xFF7C3AED),
        ),
    )
    androidx.compose.runtime.CompositionLocalProvider(LocalVaultExtras provides extras) {
        MaterialTheme(colorScheme = colors, typography = VaultTypography, shapes = VaultShapes, content = content)
    }
}
